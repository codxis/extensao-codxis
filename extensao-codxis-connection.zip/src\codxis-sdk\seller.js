"use strict";

const { CodxisMappingError } = require("./errors");

async function getCurrentSeller() {
  throw new CodxisMappingError(
    "O vínculo entre usuário e vendedor ainda não foi identificado."
  );
}

module.exports = { getCurrentSeller };

