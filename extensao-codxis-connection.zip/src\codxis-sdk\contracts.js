"use strict";

const SOURCES = Object.freeze(["API", "JSF", "DOM", "CACHE"]);
const CONFIDENCE = Object.freeze(["confirmed", "partial"]);
const ROLES = Object.freeze(["administrator", "seller", "unknown"]);

/**
 * @typedef {"API"|"JSF"|"DOM"|"CACHE"} CodxisEvidenceSource
 * @typedef {"confirmed"|"partial"} CodxisEvidenceConfidence
 *
 * @typedef {Object} CodxisEvidence
 * @property {CodxisEvidenceSource} source
 * @property {string=} endpoint
 * @property {string=} componentId
 * @property {string=} selector
 * @property {string=} jsonPath
 * @property {string} capturedAt
 * @property {CodxisEvidenceConfidence} confidence
 *
 * @typedef {Object} CodxisIdentity
 * @property {string|null} userId
 * @property {string|null} userName
 * @property {string|null} rawProfileId
 * @property {string|null} rawProfileName
 * @property {"administrator"|"seller"|"unknown"} role
 * @property {string|null} companyId
 * @property {string|null} branchId
 * @property {string|null} sellerId
 * @property {string|null} sellerName
 * @property {string|null} sessionFingerprint
 * @property {CodxisEvidence[]} evidence
 *
 * @typedef {Object} CompanyPerformance
 * @property {string} companyId
 * @property {string|null} branchId
 * @property {string} month
 * @property {number|null} sales
 * @property {number|null} profit
 * @property {string|null} capturedAt
 * @property {string|null} source
 * @property {CodxisEvidence[]} evidence
 *
 * @typedef {Object} SellerPerformance
 * @property {string} sellerId
 * @property {string|null} sellerName
 * @property {string} companyId
 * @property {string|null} branchId
 * @property {string} month
 * @property {number|null} sales
 * @property {number|null} profit
 * @property {string|null} capturedAt
 * @property {string|null} source
 * @property {CodxisEvidence[]} evidence
 */

const optionalString = (value) =>
  typeof value === "string" && value.trim() ? value.trim() : null;

function createEvidence(input) {
  if (!SOURCES.includes(input?.source)) {
    throw new TypeError("CodxisEvidence.source inválido.");
  }
  if (!CONFIDENCE.includes(input?.confidence)) {
    throw new TypeError("CodxisEvidence.confidence inválido.");
  }
  if (!input.capturedAt || Number.isNaN(Date.parse(input.capturedAt))) {
    throw new TypeError("CodxisEvidence.capturedAt inválido.");
  }
  const evidence = {
    source: input.source,
    capturedAt: new Date(input.capturedAt).toISOString(),
    confidence: input.confidence
  };
  for (const key of ["endpoint", "componentId", "selector", "jsonPath"]) {
    const value = optionalString(input[key]);
    if (value) evidence[key] = value;
  }
  return Object.freeze(evidence);
}

function createUnknownIdentity(input = {}) {
  return Object.freeze({
    userId: optionalString(input.userId),
    userName: optionalString(input.userName),
    rawProfileId: optionalString(input.rawProfileId),
    rawProfileName: optionalString(input.rawProfileName),
    role: ROLES.includes(input.role) ? input.role : "unknown",
    companyId: optionalString(input.companyId),
    branchId: optionalString(input.branchId),
    sellerId: optionalString(input.sellerId),
    sellerName: optionalString(input.sellerName),
    sessionFingerprint: optionalString(input.sessionFingerprint),
    evidence: Object.freeze((input.evidence || []).map(createEvidence))
  });
}

function normalizeNullableAmount(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

module.exports = {
  CONFIDENCE,
  ROLES,
  SOURCES,
  createEvidence,
  createUnknownIdentity,
  normalizeNullableAmount,
  optionalString
};

