(function (root) {
  "use strict";

  class CodxisMappingError extends Error {
    constructor(message) {
      super(message);
      this.name = "CodxisMappingError";
      this.code = "CODXIS_MAPPING_ERROR";
    }
  }

  const unavailable = (name) => async () => {
    throw new CodxisMappingError(
      `${name} ainda não possui mapeamento confirmado no CODXIS_MAP.md.`
    );
  };

  const production = Object.freeze({
    mode: "production",
    getCurrentIdentity: unavailable("getCurrentIdentity"),
    getSellerList: unavailable("getSellerList"),
    getCompanyMonthlySales: unavailable("getCompanyMonthlySales"),
    getSellerMonthlySales: unavailable("getSellerMonthlySales")
  });

  const api = Object.freeze({ CodxisMappingError, production });
  root.AvanteCodxisIntegration = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);

