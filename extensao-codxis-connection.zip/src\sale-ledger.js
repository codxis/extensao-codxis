(function (root) {
  "use strict";
  const KEY = "avante.salesLedger";
  let writeQueue = Promise.resolve();
  function validSale(input) {
    const amount = Number(input?.amount);
    return Boolean(input?.id && Number.isFinite(amount) && amount > 0 && input?.companyScopeKey && input?.sellerName);
  }
  async function recordUnlocked(storage, input, options = {}) {
    if (!validSale(input)) return { ok: false, errorCode: "INVALID_SALE" };
    const values = await storage.get([KEY, storage.KEYS.sellerReportSnapshot]);
    const ledger = Array.isArray(values[KEY]) ? values[KEY] : [];
    if (ledger.some((sale) => sale.id === input.id)) return { ok: true, duplicate: true, sale: ledger.find((sale) => sale.id === input.id) };
    const items = Array.isArray(input.items) ? input.items.slice(0, 100).map((item, index) => Object.freeze({ line: Number(item?.line) || index + 1, description: String(item?.description || `Item ${index + 1}`).trim().slice(0, 240), cells: Array.isArray(item?.cells) ? Object.freeze(item.cells.slice(0, 20).map((cell) => String(cell).trim().slice(0, 240))) : Object.freeze([]) })) : [];
    const sale = Object.freeze({ id: String(input.id), companyScopeKey: String(input.companyScopeKey), sellerId: input.sellerId ? String(input.sellerId) : null, sellerName: String(input.sellerName).trim(), sellerKey: root.AvanteSellerReport.createLocalSellerKey(input.sellerName), amount: Number(input.amount), type: String(input.type || "VENDA"), document: input.document ? String(input.document) : null, paymentMethod: input.paymentMethod ? String(input.paymentMethod).trim().slice(0, 120) : null, itemCount: Number.isFinite(Number(input.itemCount)) ? Number(input.itemCount) : items.length || null, items: Object.freeze(items), occurredAt: input.occurredAt || new Date().toISOString(), pageUrl: input.pageUrl ? String(input.pageUrl).slice(0, 500) : null, source: "CODXIS_CONFIRMED_SALE" });
    const period = root.AvanteSellerReport.currentMonthPeriod(new Date(sale.occurredAt));
    const previous = values[storage.KEYS.sellerReportSnapshot];
    const previousMonth = String(previous?.period?.start || "").match(/\d{2}\/(\d{2})\/(\d{4})/);
    const sameScope = previous?.companyScopeKey === sale.companyScopeKey && previousMonth && `${previousMonth[2]}-${previousMonth[1]}` === period.month;
    const sellers = sameScope ? (previous.sellers || []).map((seller) => ({ ...seller })) : [];
    let seller = sellers.find((item) => (sale.sellerId && item.sellerId === sale.sellerId) || item.localSellerKey === sale.sellerKey);
    if (!seller) { seller = { localSellerKey: sale.sellerKey, sellerId: sale.sellerId, sellerName: sale.sellerName, realized: 0, commissionBase: null, commissionValue: null, duplicateName: false, goalEligible: true }; sellers.push(seller); }
    seller.realized = Number(seller.realized || 0) + sale.amount;
    seller.realizedSource = "CODXIS_CONFIRMED_SALE";
    seller.lastSaleAt = sale.occurredAt;
    const previousTotal = sameScope && Number.isFinite(previous?.totalRealized) ? previous.totalRealized : sellers.reduce((sum, item) => sum + (Number(item.realized) || 0), 0) - sale.amount;
    const snapshot = { companyScopeKey: sale.companyScopeKey, period: { start: period.start, end: period.end }, sellers, totalRealized: previousTotal + sale.amount, capturedAt: sale.occurredAt, source: "CODXIS_CONFIRMED_SALE", pagination: { detected: false, complete: true }, lastSale: sale };
    const entries = { [KEY]: [...ledger.slice(-499), sale] };
    if (options.updateSnapshot !== false) entries[storage.KEYS.sellerReportSnapshot] = snapshot;
    await storage.set(entries);
    return { ok: true, duplicate: false, sale, snapshot };
  }
  function record(storage, input, options = {}) {
    const pending = writeQueue.then(() => recordUnlocked(storage, input, options));
    writeQueue = pending.catch(() => {});
    return pending;
  }
  async function restoreCurrentSnapshot(storage, companyScopeKey, date = new Date()) {
    const scope = String(companyScopeKey || "").trim();
    if (!scope) return null;
    const values = await storage.get([KEY, storage.KEYS.sellerReportSnapshot]);
    const previous = values[storage.KEYS.sellerReportSnapshot];
    const period = root.AvanteSellerReport.currentMonthPeriod(date);
    const previousMonth = String(previous?.period?.start || "").match(/\d{2}\/(\d{2})\/(\d{4})/);
    const sameSnapshot = previous?.companyScopeKey === scope && previousMonth && `${previousMonth[2]}-${previousMonth[1]}` === period.month;
    if (sameSnapshot && Number.isFinite(previous?.totalRealized)) return previous;
    const sales = (Array.isArray(values[KEY]) ? values[KEY] : []).filter((sale) => {
      if (sale.companyScopeKey !== scope) return false;
      return root.AvanteSellerReport.currentMonthPeriod(new Date(sale.occurredAt)).month === period.month;
    });
    if (!sales.length) return null;
    const sellersByKey = new Map();
    for (const sale of sales) {
      const sellerKey = sale.sellerKey || root.AvanteSellerReport.createLocalSellerKey(sale.sellerName);
      const seller = sellersByKey.get(sellerKey) || { localSellerKey: sellerKey, sellerId: sale.sellerId || null, sellerName: sale.sellerName, realized: 0, commissionBase: null, commissionValue: null, duplicateName: false, goalEligible: true, realizedSource: "CODXIS_CONFIRMED_SALE" };
      seller.realized += Number(sale.amount) || 0;
      seller.lastSaleAt = sale.occurredAt;
      sellersByKey.set(sellerKey, seller);
    }
    const sellers = [...sellersByKey.values()];
    const lastSale = sales.reduce((latest, sale) => !latest || new Date(sale.occurredAt) > new Date(latest.occurredAt) ? sale : latest, null);
    const snapshot = { companyScopeKey: scope, period: { start: period.start, end: period.end }, sellers, totalRealized: sellers.reduce((sum, seller) => sum + seller.realized, 0), capturedAt: lastSale.occurredAt, source: "CODXIS_CONFIRMED_SALE", pagination: { detected: false, complete: true }, lastSale };
    await storage.set({ [storage.KEYS.sellerReportSnapshot]: snapshot });
    return snapshot;
  }
  root.AvanteSaleLedger = Object.freeze({ KEY, record, restoreCurrentSnapshot, validSale });
  if (typeof module !== "undefined" && module.exports) module.exports = root.AvanteSaleLedger;
})(typeof globalThis !== "undefined" ? globalThis : this);
