(function (root) {
  "use strict";

  const SVG_NS = "http://www.w3.org/2000/svg";
  const DIMENSIONS = Object.freeze({ width: 720, height: 300, left: 72, right: 30, top: 30, bottom: 42 });
  const svgNode = (name, attributes = {}) => {
    const node = document.createElementNS(SVG_NS, name);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, String(value)));
    return node;
  };
  const validRecords = (history) => (Array.isArray(history) ? history : [])
    .filter((item) => typeof item?.date === "string" && Number.isFinite(item.timestamp) && Number.isFinite(item.monthlySales) && item.monthlySales >= 0)
    .sort((a, b) => a.timestamp - b.timestamp);
  const niceMaximum = (value) => {
    if (value <= 0) return 1;
    const rough = value / 4;
    const power = 10 ** Math.floor(Math.log10(rough));
    const normalized = rough / power;
    const step = (normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10) * power;
    return Math.ceil(value / step) * step;
  };

  const calculateChartModel = (history, monthlyGoal, dimensions = DIMENSIONS) => {
    const records = validRecords(history);
    const goal = Number.isFinite(monthlyGoal) && monthlyGoal > 0 ? monthlyGoal : null;
    const peak = Math.max(goal || 0, ...records.map((item) => item.monthlySales), 0);
    const yMaximum = niceMaximum(peak * 1.12);
    const chartWidth = dimensions.width - dimensions.left - dimensions.right;
    const chartHeight = dimensions.height - dimensions.top - dimensions.bottom;
    const reference = records.length ? new Date(records.at(-1).timestamp) : new Date();
    const monthStart = new Date(reference.getFullYear(), reference.getMonth(), 1).getTime();
    const monthEnd = new Date(reference.getFullYear(), reference.getMonth() + 1, 1).getTime();
    const inSameMonth = records.every((item) => item.timestamp >= monthStart && item.timestamp < monthEnd);
    const xAt = (timestamp, index, count) => dimensions.left + (inSameMonth
      ? ((timestamp - monthStart) / (monthEnd - monthStart)) * chartWidth
      : count <= 1 ? chartWidth : (index / (count - 1)) * chartWidth);
    const yAt = (value) => dimensions.top + chartHeight - (value / yMaximum) * chartHeight;
    const points = records.map((item, index) => ({ ...item, x: xAt(item.timestamp, index, records.length), y: yAt(item.monthlySales), synthetic: false }));
    const visualPoints = points.length === 1
      ? [{ date: new Date(monthStart).toISOString().slice(0, 10), timestamp: monthStart, monthlySales: 0, x: dimensions.left, y: yAt(0), synthetic: true }, ...points]
      : points;
    return {
      dimensions, points, visualPoints, goal, yMaximum,
      baselineY: yAt(0), goalY: goal ? yAt(goal) : null,
      ticks: [0, .25, .5, .75, 1].map((ratio) => ({ value: yMaximum * ratio, y: yAt(yMaximum * ratio) })),
      monthStart, monthEnd
    };
  };

  const smoothPath = (points) => {
    if (!points.length) return "";
    if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let index = 0; index < points.length - 1; index += 1) {
      const current = points[index], next = points[index + 1];
      const previous = points[index - 1] || current, after = points[index + 2] || next;
      const cp1x = current.x + (next.x - previous.x) / 6;
      const cp1y = current.y + (next.y - previous.y) / 6;
      const cp2x = next.x - (after.x - current.x) / 6;
      const cp2y = next.y - (after.y - current.y) / 6;
      path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${next.x} ${next.y}`;
    }
    return path;
  };

  class MiniChart {
    constructor(rootElement, options) {
      this.root = rootElement;
      this.money = options.money;
      this.percentage = options.percentage;
      this.locale = options.locale || "pt-BR";
      this.svg = rootElement.querySelector("svg");
      this.empty = rootElement.querySelector("[data-role=chart-empty]");
      this.tooltip = rootElement.querySelector("[data-role=chart-tooltip]");
    }

    render(history, monthlyGoal) {
      const model = calculateChartModel(history, monthlyGoal);
      this.svg.replaceChildren();
      this.svg.setAttribute("viewBox", `0 0 ${model.dimensions.width} ${model.dimensions.height}`);
      this.svg.hidden = model.points.length === 0;
      if (this.empty) this.empty.hidden = model.points.length > 0;
      this.hideTooltip();
      if (!model.points.length) return;

      const defs = svgNode("defs");
      const gradient = svgNode("linearGradient", { id: "avante-chart-area-gradient", x1: 0, y1: 0, x2: 0, y2: 1 });
      gradient.append(svgNode("stop", { offset: "0%", "stop-color": "#3978f6", "stop-opacity": ".18" }), svgNode("stop", { offset: "78%", "stop-color": "#3978f6", "stop-opacity": ".025" }), svgNode("stop", { offset: "100%", "stop-color": "#3978f6", "stop-opacity": "0" }));
      defs.appendChild(gradient);
      if (model.goalY != null) {
        const clip = svgNode("clipPath", { id: "avante-chart-above-goal" });
        clip.appendChild(svgNode("rect", { x: model.dimensions.left - 6, y: 0, width: model.dimensions.width, height: model.goalY + 1 }));
        defs.appendChild(clip);
      }
      this.svg.appendChild(defs);

      model.ticks.forEach((tick) => {
        this.svg.appendChild(svgNode("line", { class: "avante-chart-grid", x1: model.dimensions.left, y1: tick.y, x2: model.dimensions.width - model.dimensions.right, y2: tick.y }));
        const label = svgNode("text", { class: "avante-chart-y-label", x: model.dimensions.left - 14, y: tick.y + 4, "text-anchor": "end" });
        label.textContent = this.compactMoney(tick.value); this.svg.appendChild(label);
      });

      const monthDays = Math.round((model.monthEnd - model.monthStart) / 86400000);
      [1, Math.round(monthDays / 3), Math.round(monthDays * 2 / 3), monthDays].forEach((day) => {
        const x = model.dimensions.left + ((day - 1) / monthDays) * (model.dimensions.width - model.dimensions.left - model.dimensions.right);
        this.svg.appendChild(svgNode("line", { class: "avante-chart-grid avante-chart-grid-vertical", x1: x, y1: model.dimensions.top, x2: x, y2: model.baselineY }));
        const label = svgNode("text", { class: "avante-chart-date", x, y: model.baselineY + 29, "text-anchor": day === 1 ? "start" : day === monthDays ? "end" : "middle" });
        label.textContent = day === 1 ? "01" : day === monthDays ? `${String(day).padStart(2, "0")} dias` : `${String(day).padStart(2, "0")}`; this.svg.appendChild(label);
      });

      if (model.goalY != null) {
        this.svg.appendChild(svgNode("line", { class: "avante-chart-goal", x1: model.dimensions.left, y1: model.goalY, x2: model.dimensions.width - model.dimensions.right, y2: model.goalY }));
        const badgeWidth = 98;
        const badge = svgNode("g", { class: "avante-chart-goal-badge", transform: `translate(${model.dimensions.width - model.dimensions.right - badgeWidth} ${Math.max(7, model.goalY - 27)})` });
        badge.append(svgNode("rect", { width: badgeWidth, height: 22, rx: 7 }));
        const title = svgNode("text", { x: 9, y: 14 }); title.textContent = "META";
        const value = svgNode("text", { class: "avante-chart-goal-value", x: badgeWidth - 9, y: 14, "text-anchor": "end" }); value.textContent = this.compactMoney(model.goal);
        badge.append(title, value); this.svg.appendChild(badge);
      }

      const linePath = smoothPath(model.visualPoints);
      const first = model.visualPoints[0], last = model.visualPoints.at(-1);
      this.svg.appendChild(svgNode("path", { class: "avante-chart-area", d: `${linePath} L ${last.x} ${model.baselineY} L ${first.x} ${model.baselineY} Z` }));
      this.svg.appendChild(svgNode("path", { class: "avante-chart-line avante-chart-line-base", d: linePath, pathLength: 1 }));
      if (model.goalY != null) this.svg.appendChild(svgNode("path", { class: "avante-chart-line avante-chart-line-surplus", d: linePath, pathLength: 1, "clip-path": "url(#avante-chart-above-goal)" }));

      model.points.forEach((point, index) => {
        const circle = svgNode("circle", { class: `avante-chart-point${index === model.points.length - 1 ? " avante-chart-point-current" : ""}`, cx: point.x, cy: point.y, r: index === model.points.length - 1 ? 5 : 4, tabindex: 0, role: "img", "aria-label": this.accessibleLabel(point, monthlyGoal) });
        ["mouseenter", "focus"].forEach((event) => circle.addEventListener(event, () => this.showTooltip(point, monthlyGoal, model)));
        ["mouseleave", "blur"].forEach((event) => circle.addEventListener(event, () => this.hideTooltip()));
        this.svg.appendChild(circle);
      });
    }

    compactMoney(value) {
      const amount = Number(value) || 0;
      if (amount >= 1000000) return `R$ ${(amount / 1000000).toLocaleString(this.locale, { maximumFractionDigits: 1 })} mi`;
      if (amount >= 1000) return `R$ ${(amount / 1000).toLocaleString(this.locale, { maximumFractionDigits: 1 })} mil`;
      return `R$ ${Math.round(amount).toLocaleString(this.locale)}`;
    }
    formatDate(point) { return new Date(point.timestamp).toLocaleDateString(this.locale, { day: "2-digit", month: "long", year: "numeric" }); }
    accessibleLabel(point, goal) {
      const difference = Number.isFinite(goal) && goal > 0 ? point.monthlySales - goal : null;
      return [this.formatDate(point), `Realizado: ${this.money.format(point.monthlySales)}`, difference == null ? null : `Meta: ${this.money.format(goal)}`, difference == null ? null : `Diferença: ${this.money.format(difference)}`].filter(Boolean).join(". ");
    }
    showTooltip(point, goal, model) {
      const difference = Number.isFinite(goal) && goal > 0 ? point.monthlySales - goal : null;
      const percentage = difference == null ? null : (point.monthlySales / goal) * 100;
      this.tooltip.replaceChildren();
      const date = document.createElement("strong"); date.textContent = this.formatDate(point); this.tooltip.appendChild(date);
      [["Realizado", this.money.format(point.monthlySales)], ["Meta", difference == null ? "Não definida" : this.money.format(goal)], ["Diferença", difference == null ? "—" : `${difference >= 0 ? "+" : "−"}${this.money.format(Math.abs(difference))}`], ["Percentual", percentage == null ? "—" : `${this.percentage.format(percentage)}%`]].forEach(([label, value]) => { const row = document.createElement("span"); const key = document.createElement("i"); key.textContent = label; const amount = document.createElement("b"); amount.textContent = value; row.append(key, amount); this.tooltip.appendChild(row); });
      this.tooltip.style.left = `${(point.x / model.dimensions.width) * 100}%`; this.tooltip.style.top = `${(point.y / model.dimensions.height) * 100}%`;
      this.tooltip.style.transform = `translate(${point.x > model.dimensions.width * .72 ? "-100%" : point.x < model.dimensions.width * .25 ? "0" : "-50%"}, -112%)`;
      this.tooltip.hidden = false;
    }
    hideTooltip() { if (this.tooltip) this.tooltip.hidden = true; }
  }

  const api = Object.freeze({ MiniChart, calculateChartModel, smoothPath, DIMENSIONS });
  root.AvanteMiniChart = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
