"use strict";

const { CodxisMappingError } = require("../errors");

class DomAdapter {
  async read(_mapping, _input) {
    throw new CodxisMappingError(
      "Nenhum seletor DOM de identidade ou relatório foi confirmado."
    );
  }
}

module.exports = DomAdapter;

