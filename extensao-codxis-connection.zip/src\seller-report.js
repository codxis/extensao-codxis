(function (root) {
  "use strict";
  const UPDATE_ID = "form:painelGeralRelatorios";
  const SOURCE = "CODXIS_SELLER_REPORT";
  const ORDER_SUMMARY_UPDATE_ID = "form:panelGrafico";
  const ORDER_SUMMARY_SOURCE = "CODXIS_ORDER_SUMMARY";
  const decodeHtml = (text) => String(text || "").replace(/&nbsp;|&#160;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/\s+/g, " ").trim();
  const cellText = (cell) => decodeHtml(String(cell || "").replace(/<[^>]*>/g, " "));
  function parseBrazilianAmount(value) {
    const text = decodeHtml(value).replace(/[^\d,.-]/g, "");
    if (!text) return null;
    const normalized = text.includes(",") ? text.replace(/\./g, "").replace(",", ".") : text;
    const amount = Number(normalized);
    return Number.isFinite(amount) ? amount : null;
  }
  function normalizeSellerName(name) {
    return String(name || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, "-");
  }
  function hashName(name) {
    let hash = 2166136261;
    for (const char of name) { hash ^= char.codePointAt(0); hash = Math.imul(hash, 16777619); }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function createLocalSellerKey(name) {
    const normalized = normalizeSellerName(name);
    return `local:${normalized || "sem-nome"}:${hashName(normalized)}`;
  }
  function parsePartialResponse(xml) {
    if (typeof xml !== "string" || !/<partial-response[\s>]/i.test(xml)) throw new Error("A resposta não é um partial-response JSF válido.");
    const updates = []; let match;
    const pattern = /<update\b[^>]*\bid=(?:"([^"]*)"|'([^']*)')[^>]*>([\s\S]*?)<\/update>/gi;
    while ((match = pattern.exec(xml))) { const raw = match[3].trim(); const cdata = raw.match(/^<!\[CDATA\[([\s\S]*?)\]\]>$/); updates.push({ id: match[1] || match[2] || "", content: cdata ? cdata[1] : raw, hasCdata: Boolean(cdata) }); }
    return updates;
  }
  const reportScore = (update) => {
    const value = `${update.id} ${update.content}`;
    return (/painelGeralRelatorios/i.test(update.id) ? 100 : 0) + (/datatableVendasVendedores|Valor Documento|totalDocumento/i.test(value) ? 50 : 0) + (/<table\b/i.test(update.content) && /<tr\b/i.test(update.content) ? 10 : 0);
  };
  const sanitizeReportHtml = (html) => String(html || "").replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<input\b[^>]*(?:ViewState|JSESSIONID)[^>]*>/gi, "").slice(0, 50000);
  function inspectSellerReportResponse(xml) {
    const updates = parsePartialResponse(xml);
    const ranked = updates.map((update, index) => ({ update, index, score: reportScore(update) })).filter((item) => item.score > 0).sort((a, b) => b.score - a.score || a.index - b.index);
    const chosen = ranked[0]?.update || null;
    if (!chosen) { const error = new Error(`Resposta JSF sem update contendo o relatório. Updates encontrados: ${updates.map((item) => item.id).join(", ") || "nenhum"}.`); error.code = "REPORT_PANEL_NOT_FOUND"; error.diagnostic = { updateIds: updates.map((item) => item.id), chosenUpdateId: null, updates: updates.map((item) => ({ id: item.id, score: reportScore(item), contentPreview: item.content.slice(0, 500) })) }; throw error; }
    const html = chosen.content;
    let tableCount = 0, tbodyCount = 0, rowCount = 0, dataRowCount = 0, cellCount = 0, columns = [];
    if (typeof DOMParser !== "undefined") {
      const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
      tableCount = doc.querySelectorAll("table").length; tbodyCount = doc.querySelectorAll("tbody").length; rowCount = doc.querySelectorAll("tr").length; dataRowCount = doc.querySelectorAll("tbody tr").length; cellCount = doc.querySelectorAll("tbody td").length;
      const table = [...doc.querySelectorAll("table")].find((item) => /datatableVendasVendedores|Valor Documento/i.test(item.outerHTML)) || doc.querySelector("table");
      columns = [...(table?.querySelectorAll("thead th") || [])].map((item, index) => ({ index, name: decodeHtml(item.textContent) })).filter((item) => item.name);
    } else {
      tableCount = (html.match(/<table\b/gi) || []).length; tbodyCount = (html.match(/<tbody\b/gi) || []).length; rowCount = (html.match(/<tr\b/gi) || []).length; dataRowCount = [...html.matchAll(/<tbody\b[^>]*>([\s\S]*?)<\/tbody>/gi)].reduce((sum, body) => sum + (body[1].match(/<tr\b/gi) || []).length, 0); cellCount = (html.match(/<td\b/gi) || []).length;
      const header = html.match(/<thead\b[^>]*>([\s\S]*?)<\/thead>/i)?.[1] || ""; columns = [...header.matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi)].map((item, index) => ({ index, name: cellText(item[1]) })).filter((item) => item.name);
    }
    return Object.freeze({ updates, chosen, html, diagnostic: Object.freeze({ updateIds: Object.freeze(updates.map((item) => item.id)), chosenUpdateId: chosen.id, hasCdata: chosen.hasCdata, tableCount, tbodyCount, rowCount, dataRowCount, cellCount, columns: Object.freeze(columns), sanitizedHtml: sanitizeReportHtml(html) }) });
  }
  function parseSellerReport(xml, context = {}) {
    const inspection = inspectSellerReportResponse(xml);
    const html = inspection.html;
    const rawSellers = [];
    let parsedRows = [];
    if (typeof DOMParser !== "undefined") {
      const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
      const table = [...doc.querySelectorAll("table")].find((item) => /datatableVendasVendedores|Valor Documento/i.test(item.outerHTML)) || doc.querySelector("table");
      const headers = [...(table?.querySelectorAll("thead th") || [])].map((item) => decodeHtml(item.textContent));
      const findColumn = (pattern, fallback) => { const index = headers.findIndex((header) => pattern.test(header)); return index >= 0 ? index : fallback; };
      const sellerIndex = findColumn(/vendedor|colaborador/i, 1); const realizedIndex = findColumn(/valor\s*documento/i, 2); const baseIndex = findColumn(/base/i, 3); const commissionIndex = findColumn(/comiss/i, 4);
      parsedRows = [...(table?.querySelectorAll("tbody tr") || [])].filter((row) => !row.classList.contains("ui-datatable-empty-message")).map((row) => { const cells = [...row.querySelectorAll("td")]; const href = cells[sellerIndex]?.querySelector("a[href]")?.getAttribute("href") || ""; const sellerId = href.match(/[?&](?:idPart|sellerId|id)=([0-9]+)/i)?.[1] || cells[sellerIndex]?.querySelector("[data-seller-id]")?.getAttribute("data-seller-id") || null; return { cells: cells.map((cell) => decodeHtml(cell.textContent)), sellerId, sellerIndex, realizedIndex, baseIndex, commissionIndex }; });
    } else {
      const body = html.match(/<tbody\b[^>]*(?:id=["'][^"']*datatableVendasVendedores[^"']*["'])?[^>]*>([\s\S]*?)<\/tbody>/i);
      parsedRows = [...(body ? body[1].matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi) : [])].filter((row) => !/ui-datatable-empty-message/i.test(row[0])).map((row) => ({ cells: [...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map((match) => cellText(match[1])), sellerIndex: 1, realizedIndex: 2, baseIndex: 3, commissionIndex: 4 }));
    }
    for (const row of parsedRows) {
      const { cells, sellerIndex, realizedIndex, baseIndex, commissionIndex } = row;
      if (cells.length <= Math.max(sellerIndex, realizedIndex) || !cells[sellerIndex]) continue;
      rawSellers.push({ sellerId: row.sellerId || null, sellerName: cells[sellerIndex], realized: parseBrazilianAmount(cells[realizedIndex]), commissionBase: cells.length > baseIndex ? parseBrazilianAmount(cells[baseIndex]) : null, commissionValue: cells.length > commissionIndex ? parseBrazilianAmount(cells[commissionIndex]) : null });
    }
    const counts = new Map();
    for (const seller of rawSellers) { const key = createLocalSellerKey(seller.sellerName); counts.set(key, (counts.get(key) || 0) + 1); }
    const sellers = rawSellers.map((seller) => { const localSellerKey = createLocalSellerKey(seller.sellerName); return Object.freeze({ localSellerKey, sellerId: seller.sellerId, sellerName: seller.sellerName, realized: seller.realized, commissionBase: seller.commissionBase, commissionValue: seller.commissionValue, duplicateName: counts.get(localSellerKey) > 1, goalEligible: counts.get(localSellerKey) === 1 }); });
    const totalMatch = html.match(/<[^>]+\bid=["']form:totalDocumento["'][^>]*>([\s\S]*?)<\/[^>]+>/i);
    const script = html.match(/PrimeFaces\.cw\("DataTable","widget_form_datatableVendasVendedores",\{([\s\S]*?)\}\);/i)?.[1] || "";
    const paginator = /paginator\s*:\s*true/i.test(script) || /ui-paginator/i.test(html);
    const liveScroll = /liveScroll\s*:\s*true/i.test(script);
    const scrollLimit = Number(script.match(/scrollLimit\s*:\s*(\d+)/i)?.[1] || 0) || null;
    return Object.freeze({ period: Object.freeze({ start: String(context.start || ""), end: String(context.end || "") }), sellers: Object.freeze(sellers), totalRealized: totalMatch ? parseBrazilianAmount(cellText(totalMatch[1])) : sellers.reduce((sum, seller) => sum + (Number(seller.realized) || 0), 0), capturedAt: context.capturedAt || new Date().toISOString(), source: SOURCE, parserDiagnostic: inspection.diagnostic, pagination: Object.freeze({ detected: paginator || liveScroll, paginator, liveScroll, scrollLimit, complete: !paginator && !liveScroll }) });
  }
  function parseOrderSummary(xml, context = {}) {
    const updates = parsePartialResponse(xml);
    const chosen = updates.find((update) => /(?:^|:)panelGrafico$/i.test(update.id) && /datatablePedidoVendaFinalizados/i.test(update.content)) || updates.find((update) => /datatablePedidoVendaFinalizados/i.test(update.content));
    if (!chosen) { const error = new Error(`Resposta JSF sem update contendo o resumo de pedidos. Updates encontrados: ${updates.map((item) => item.id).join(", ") || "nenhum"}.`); error.code = "ORDER_SUMMARY_PANEL_NOT_FOUND"; error.diagnostic = { updateIds: updates.map((item) => item.id), chosenUpdateId: null }; throw error; }
    const html = chosen.content;
    let rows = [], rowCount = null, pageSize = null;
    if (typeof DOMParser !== "undefined") {
      const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
      const table = doc.getElementById("form:datatablePedidoVendaFinalizados") || [...doc.querySelectorAll("table")].find((item) => /datatablePedidoVendaFinalizados/i.test(item.outerHTML));
      const headers = [...(table?.querySelectorAll("thead th") || [])].map((item) => decodeHtml(item.textContent));
      const findColumn = (pattern, fallback) => { const index = headers.findIndex((header) => pattern.test(header)); return index >= 0 ? index : fallback; };
      const numberIndex = findColumn(/n[uÃº]mero/i, 1), sellerIndex = findColumn(/vendedor/i, 4), dateIndex = findColumn(/data/i, 5), amountIndex = findColumn(/valor/i, 6);
      rows = [...(table?.querySelectorAll("tbody tr") || [])].filter((row) => !row.classList.contains("ui-datatable-empty-message")).map((row) => ({ cells: [...row.querySelectorAll("td")].map((cell) => decodeHtml(cell.textContent)), numberIndex, sellerIndex, dateIndex, amountIndex }));
    } else {
      const body = html.match(/<tbody\b[^>]*id=["'][^"']*datatablePedidoVendaFinalizados_data["'][^>]*>([\s\S]*?)<\/tbody>/i);
      rows = [...(body ? body[1].matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi) : [])].filter((row) => !/ui-datatable-empty-message/i.test(row[0])).map((row) => ({ cells: [...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map((cell) => cellText(cell[1])), numberIndex: 1, sellerIndex: 4, dateIndex: 5, amountIndex: 6 }));
    }
    const widget = html.match(/PrimeFaces\.cw\("DataTable","widget_form_datatablePedidoVendaFinalizados",\{([\s\S]*?)\}\);/i)?.[1] || "";
    rowCount = Number(widget.match(/rowCount\s*:\s*(\d+)/i)?.[1] || "") || null;
    pageSize = Number(widget.match(/rows\s*:\s*(\d+)/i)?.[1] || "") || null;
    const sales = [];
    for (const row of rows) {
      const { cells, numberIndex, sellerIndex, dateIndex, amountIndex } = row;
      const sellerName = String(cells[sellerIndex] || "").trim();
      const amount = parseBrazilianAmount(cells[amountIndex]);
      if (!sellerName || amount == null) continue;
      sales.push(Object.freeze({ document: String(cells[numberIndex] || "").trim() || null, sellerName, amount, occurredAt: String(cells[dateIndex] || "").trim() || null }));
    }
    const sellersByKey = new Map();
    for (const sale of sales) {
      const key = createLocalSellerKey(sale.sellerName);
      const seller = sellersByKey.get(key) || { localSellerKey: key, sellerId: null, sellerName: sale.sellerName, realized: 0, duplicateName: false, goalEligible: true };
      seller.realized += sale.amount; sellersByKey.set(key, seller);
    }
    const complete = rowCount == null || rows.length >= rowCount;
    return Object.freeze({
      period: Object.freeze({ start: String(context.start || ""), end: String(context.end || "") }),
      sellers: Object.freeze([...sellersByKey.values()].map((seller) => Object.freeze(seller))),
      totalRealized: sales.reduce((sum, sale) => sum + sale.amount, 0),
      sales: Object.freeze(sales), capturedAt: context.capturedAt || new Date().toISOString(), source: ORDER_SUMMARY_SOURCE,
      parserDiagnostic: Object.freeze({ updateIds: Object.freeze(updates.map((item) => item.id)), chosenUpdateId: chosen.id, rowCount: rows.length, expectedRowCount: rowCount, pageSize }),
      pagination: Object.freeze({ detected: rowCount != null && pageSize != null, rowCount, pageSize, complete })
    });
  }
  function currentMonthPeriod(date = new Date()) {
    const first = new Date(date.getFullYear(), date.getMonth(), 1);
    const last = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    const format = (value) => `${String(value.getDate()).padStart(2, "0")}/${String(value.getMonth() + 1).padStart(2, "0")}/${value.getFullYear()}`;
    return { start: `${format(first)} 00:00:00`, end: `${format(last)} 23:59:59`, month: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}` };
  }
  const api = Object.freeze({ SOURCE, UPDATE_ID, ORDER_SUMMARY_SOURCE, ORDER_SUMMARY_UPDATE_ID, createLocalSellerKey, currentMonthPeriod, inspectSellerReportResponse, normalizeSellerName, parseBrazilianAmount, parseOrderSummary, parseSellerReport });
  root.AvanteSellerReport = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
