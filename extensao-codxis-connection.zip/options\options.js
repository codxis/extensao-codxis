"use strict";

const storage = globalThis.AvanteStorage;
const keys = storage.KEYS;
const form = document.getElementById("preferences");
const amountInput = document.getElementById("amount");
const collapsedInput = document.getElementById("collapsed");
const diagnosticsInput = document.getElementById("diagnostics");
const amountError = document.getElementById("amount-error");
const status = document.getElementById("status");
const saveButton = document.getElementById("save");
const unlockButton = document.getElementById("unlock");
const changePasswordButton = document.getElementById("change-password");
const passwordModal = document.getElementById("password-modal");
const passwordForm = document.getElementById("password-form");
const passwordProtection = new globalThis.AvantePasswordProtection(storage);
const demoRepository = new globalThis.AvanteDemoData.DemoRepository(storage);
const demoEnabledInput = document.getElementById("demo-enabled");
const demoRoleInput = document.getElementById("demo-role");
const demoSellerInput = document.getElementById("demo-seller");
const adminPanelEnabledInput = document.getElementById("admin-panel-enabled");
const adminSessionNameInput = document.getElementById("admin-session-name");
let goalUnlocked = false;
let optionsAdministrator = false;
let bootstrapProvisioning = false;
let recoveryUnlock = false;
let detectedSession = null;
const syncApiUrlInput = document.getElementById("sync-api-url");
const syncAdminTokenInput = document.getElementById("sync-admin-token");
const syncSellerTokenInput = document.getElementById("sync-seller-token");
const syncAdminSellerInput = document.getElementById("sync-admin-seller");
const runtimeMessage = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => resolve(chrome.runtime.lastError ? { ok: false, errorCode: chrome.runtime.lastError.message } : response)));

const parseAmount = (value) => {
  let text = String(value || "").trim().replace(/[^\d,.-]/g, "");
  if (text.includes(",")) text = text.replace(/\./g, "").replace(",", ".");
  const amount = Number(text);
  return Number.isFinite(amount) ? amount : null;
};

const formatAmount = (amount) =>
  amount.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

const showStatus = (message, error = false) => {
  status.textContent = message;
  status.classList.toggle("error", error);
};

const connectedCodxisTabs = async () => {
  const tabs = await chrome.tabs.query({ url: "https://web.codxis.api.br/sistema/pages/privado/*" });
  const connected = await Promise.all(tabs.map(async (tab) => {
    if (!tab.id) return null;
    try { return { tab, evidence: await chrome.tabs.sendMessage(tab.id, { type: "AVANTE_GET_SESSION_EVIDENCE" }) }; }
    catch (_) { return null; }
  }));
  return connected.filter(Boolean);
};

const findConnectedCodxisTab = async (role = null) => {
  const connected = await connectedCodxisTabs();
  return connected.find((item) => !role || item.evidence?.resolvedRole === role) || null;
};

const loadAdminSellerCandidates = async (connected = null) => {
  const administrator = connected || await findConnectedCodxisTab("administrator");
  syncAdminSellerInput.replaceChildren(new Option("Selecione o vendedor", ""));
  if (!administrator?.tab?.id) return [];
  const response = await chrome.tabs.sendMessage(administrator.tab.id, { type: "AVANTE_GET_ADMIN_SELLER_CANDIDATES" }).catch(() => ({ ok: false }));
  const candidates = response?.ok && Array.isArray(response.candidates) ? response.candidates : [];
  for (const candidate of candidates) syncAdminSellerInput.add(new Option(`${candidate.sellerName} — meta ${formatAmount(candidate.goal)}`, candidate.localSellerKey));
  if (!candidates.length) syncAdminSellerInput.add(new Option("Nenhuma meta individual encontrada — atualize o painel", ""));
  if (candidates.length === 1) syncAdminSellerInput.value = candidates[0].localSellerKey;
  return candidates;
};
syncAdminSellerInput.addEventListener("focus", () => loadAdminSellerCandidates().catch(() => {}));

async function loadDetectedSessionEvidence() {
  try {
    const connected = await findConnectedCodxisTab();
    if (!connected) throw new Error("Recarregue uma aba privada do Codxis para conectar a extensão.");
    detectedSession = connected.evidence;
    document.getElementById("detected-login").textContent = detectedSession?.login || "não detectado";
    document.getElementById("detected-company").textContent = (detectedSession?.companyEvidence || []).join(" | ") || "não detectada";
    document.getElementById("detected-access-code").textContent = `${detectedSession?.resolvedRole || "unknown"} — ${detectedSession?.accessCode || "sem código"}`;
  } catch (error) {
    detectedSession = null;
    document.getElementById("detected-access-code").textContent = error.message;
  }
}

document.getElementById("use-detected-session").addEventListener("click", () => {
  if (!detectedSession?.login || !detectedSession?.companyEvidence?.length) { showStatus("Nenhuma sessão do Codxis foi detectada. Recarregue a home e tente novamente.", true); return; }
  adminSessionNameInput.value = detectedSession.login;
  document.getElementById("binding-company").value = detectedSession.companyEvidence.find((value) => /^\d+-.+/.test(value)) || detectedSession.companyEvidence[0];
  showStatus("Login e empresa copiados exatamente da sessão detectada.");
});

const setGoalUnlocked = (unlocked) => {
  goalUnlocked = unlocked;
  amountInput.disabled = !unlocked;
  saveButton.disabled = !unlocked;
  unlockButton.textContent = unlocked ? "Edição desbloqueada" : "Desbloquear edição";
  unlockButton.disabled = unlocked;
};

const closePasswordModal = () => {
  passwordModal.hidden = true;
  passwordForm.reset();
  document.getElementById("password-error").textContent = "";
};

const openPasswordModal = (mode, purpose = "unlock") => {
  const modes = {
    login: {
      title: "Editar meta mensal",
      description: "Digite a senha para liberar a edição da meta.",
      passwordLabel: "Senha",
      submit: "Entrar",
      current: false,
      confirm: false
    },
    setup: {
      title: "Proteja sua meta",
      description: "Cadastre uma senha com pelo menos 4 caracteres.",
      passwordLabel: "Nova senha",
      submit: "Salvar",
      current: false,
      confirm: true
    },
    change: {
      title: "Alterar senha",
      description: "Confirme a senha atual antes de definir uma nova.",
      passwordLabel: "Nova senha",
      submit: "Alterar senha",
      current: true,
      confirm: true
    }
  };
  const settings = modes[mode];
  passwordForm.reset();
  passwordForm.dataset.mode = mode;
  passwordForm.dataset.purpose = purpose;
  const currentField = passwordForm.querySelector("[data-field=current]");
  const confirmField = passwordForm.querySelector("[data-field=confirm]");
  currentField.hidden = !settings.current;
  currentField.querySelector("input").required = settings.current;
  confirmField.hidden = !settings.confirm;
  confirmField.querySelector("input").required = settings.confirm;
  passwordForm.elements.password.autocomplete =
    mode === "login" ? "current-password" : "new-password";
  passwordForm.querySelector("[data-field=password]").firstChild.textContent =
    settings.passwordLabel;
  document.getElementById("password-title").textContent = settings.title;
  document.getElementById("password-description").textContent =
    settings.description;
  document.getElementById("password-submit").textContent = settings.submit;
  document.getElementById("password-error").textContent = "";
  passwordModal.hidden = false;
  window.setTimeout(
    () =>
      (settings.current
        ? passwordForm.elements.currentPassword
        : passwordForm.elements.password
      ).focus(),
    0
  );
};

const requestUnlock = async () => {
  const mode = (await passwordProtection.hasPassword()) ? "login" : "setup";
  openPasswordModal(mode, "unlock");
};

document.getElementById("recover-admin-access").addEventListener("click", async () => {
  try {
    if (!(await passwordProtection.hasPassword())) {
      if (!bootstrapProvisioning) {
        showStatus("Existem vínculos salvos, mas nenhuma senha administrativa válida foi encontrada. A recuperação automática foi bloqueada.", true);
        return;
      }
      openPasswordModal("setup", "recovery");
      return;
    }
    openPasswordModal("login", "recovery");
  } catch (error) { showStatus(`Não foi possível iniciar a recuperação: ${error.message}`, true); }
});

const loadPreferences = async () => {
  const security = await storage.get([keys.activeSession, keys.identityBindings]);
  const bindings = Array.isArray(security[keys.identityBindings]) ? security[keys.identityBindings] : [];
  const connectedAdministrator = await findConnectedCodxisTab("administrator");
  optionsAdministrator = security[keys.activeSession]?.role === "administrator" || Boolean(connectedAdministrator);
  bootstrapProvisioning = bindings.length === 0;
  document.getElementById("admin-goal-section").hidden = !optionsAdministrator;
  document.getElementById("admin-security-section").hidden = !(optionsAdministrator || bootstrapProvisioning);
  document.getElementById("restricted-options").hidden = optionsAdministrator;
  document.querySelector(".demo-settings").hidden = !optionsAdministrator;
  const sync = await storage.get([keys.syncApiUrl, keys.syncAdminToken, keys.syncSellerToken]);
  syncApiUrlInput.value = sync[keys.syncApiUrl] || "http://127.0.0.1:8787";
  syncAdminTokenInput.value = sync[keys.syncAdminToken] || "";
  syncSellerTokenInput.value = sync[keys.syncSellerToken] || "";
  document.getElementById("sync-admin-token-field").hidden = !optionsAdministrator;
  document.getElementById("sync-seller-token-field").hidden = optionsAdministrator;
  document.getElementById("sync-admin-seller-field").hidden = !optionsAdministrator;
  document.getElementById("provision-seller").hidden = !optionsAdministrator;
  document.getElementById("publish-seller-goal").hidden = false;
  if (connectedAdministrator) await loadAdminSellerCandidates(connectedAdministrator);
  if (!optionsAdministrator) {
    amountInput.value = "";
    collapsedInput.checked = false;
    diagnosticsInput.checked = false;
    return;
  }
  const values = await storage.get([
    keys.goal,
    keys.collapsed,
    keys.diagnostics
  ]);
  const goal = values[keys.goal] || { amount: 0, period: "monthly" };
  const normalizedGoal =
    globalThis.AvanteGoalCalculator.normalizeMonthlyGoal(goal);

  amountInput.value =
    normalizedGoal.amount > 0 ? formatAmount(normalizedGoal.amount) : "";
  if (
    normalizedGoal.amount > 0 &&
    (goal.period !== "monthly" || goal.amount !== normalizedGoal.amount)
  ) {
    await storage.set({ [keys.goal]: normalizedGoal });
  }
  collapsedInput.checked = Boolean(values[keys.collapsed]);
  diagnosticsInput.checked = Boolean(values[keys.diagnostics]);
  const adminValues = await storage.get([keys.adminPanelEnabled, keys.adminSessionName]);
  adminPanelEnabledInput.checked = adminValues[keys.adminPanelEnabled] === true;
  adminSessionNameInput.value = adminValues[keys.adminSessionName] || "";
  const demo = await demoRepository.load();
  demoEnabledInput.checked = demo.enabled;
  demoRoleInput.value = demo.profile.role;
  demoSellerInput.value = demo.profile.sellerId || "demo-carlos";
  syncDemoFields();
};

const saveSyncConfig = async () => {
  const url = syncApiUrlInput.value.trim().replace(/\/$/, "");
  if (!/^https:\/\//i.test(url) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(url)) { showStatus("Use HTTPS ou a API local em localhost/127.0.0.1.", true); return false; }
  await storage.set({ [keys.syncApiUrl]: url, [keys.syncAdminToken]: syncAdminTokenInput.value.trim(), [keys.syncSellerToken]: syncSellerTokenInput.value.trim() });
  showStatus("Configuração da sincronização salva neste perfil.");
  return true;
};
document.getElementById("save-sync").addEventListener("click", saveSyncConfig);
document.getElementById("test-sync").addEventListener("click", async () => { if (!(await saveSyncConfig())) return; const response = await runtimeMessage({ type: "AVANTE_SYNC_HEALTH" }); showStatus(response?.ok ? "API de sincronização conectada." : `Falha ao conectar: ${response?.errorCode || "erro desconhecido"}`, !response?.ok); });
const configuredSellerScope = () => ({ companyScopeKey: document.getElementById("binding-company").value.trim(), userId: document.getElementById("binding-user-id").value.trim(), sellerId: document.getElementById("binding-seller-id").value.trim(), month: new Date().toISOString().slice(0, 7) });
const publishConfiguredSellerGoal = async () => {
  if (!(await saveSyncConfig())) return false;
  const scope = configuredSellerScope();
  if (!scope.companyScopeKey || !scope.userId || !scope.sellerId) { showStatus("Preencha empresa, User ID e Seller ID do vendedor.", true); return false; }
  const connected = await findConnectedCodxisTab("administrator");
  if (!connected) { showStatus("Nenhuma aba administrativa conectada. Recarregue a home do Codxis administrador e tente novamente.", true); return false; }
  if (!syncAdminSellerInput.options.length || syncAdminSellerInput.options.length === 1) await loadAdminSellerCandidates(connected);
  const localSellerKey = syncAdminSellerInput.value;
  if (!localSellerKey) { showStatus("Selecione o Davi em “Vendedor do painel administrativo” antes de espelhar.", true); syncAdminSellerInput.focus(); return false; }
  const response = await chrome.tabs.sendMessage(connected.tab.id, { type: "AVANTE_REPUBLISH_SELLER_DTOS", target: { ...scope, localSellerKey } }).catch(() => ({ ok: false, errorCode: "ADMIN_TAB_DISCONNECTED" }));
  showStatus(response?.ok ? `Painel administrativo conciliado: ${response.remotePublished} vendedor publicado.` : `Não foi possível conciliar: ${response?.failures?.join(", ") || response?.errorCode || "nenhum dado individual compatível"}.`, !response?.ok);
  return Boolean(response?.ok);
};
document.getElementById("publish-seller-goal").addEventListener("click", publishConfiguredSellerGoal);
document.getElementById("provision-seller").addEventListener("click", async () => {
  if (!optionsAdministrator) return showStatus("Somente o administrador pode provisionar vendedores.", true);
  if (!(await saveSyncConfig())) return;
  const scope = configuredSellerScope();
  const response = await runtimeMessage({ type: "AVANTE_SYNC_PROVISION", scope });
  if (!response?.ok) return showStatus(`Não foi possível gerar o token: ${response?.errorCode || "erro desconhecido"}`, true);
  document.getElementById("provisioned-token").hidden = false; document.getElementById("provisioned-token-value").textContent = response.result.accessToken;
  const connected = await findConnectedCodxisTab("administrator");
  let publication = null;
  if (connected?.tab?.id) publication = await chrome.tabs.sendMessage(connected.tab.id, { type: "AVANTE_REPUBLISH_SELLER_DTOS" }).catch(() => ({ ok: false, errorCode: "ADMIN_TAB_DISCONNECTED" }));
  showStatus(publication?.ok ? `Token gerado e ${publication.remotePublished} DTO individual publicado.` : "Token gerado. Copie-o para o vendedor, recarregue a home administrativa e use “Espelhar painel administrativo no vendedor”.");
});

const syncDemoFields = () => {
  document.getElementById("demo-profile-fields").hidden = !demoEnabledInput.checked;
  document.getElementById("demo-badge").hidden = !demoEnabledInput.checked;
  document.getElementById("demo-seller-field").hidden = demoRoleInput.value !== "seller";
};
demoEnabledInput.addEventListener("change", syncDemoFields);
demoRoleInput.addEventListener("change", syncDemoFields);
document.getElementById("save-demo").addEventListener("click", async () => {
  try {
    await demoRepository.setProfile(demoRoleInput.value === "seller" ? { role: "seller", sellerId: demoSellerInput.value } : { role: "administrator" });
    await demoRepository.setEnabled(demoEnabledInput.checked);
    syncDemoFields();
    showStatus(demoEnabledInput.checked ? "Demonstração ativada. Reabra a home do Codxis." : "Demonstração desativada. O comportamento real foi restaurado.");
  } catch (error) { showStatus(`Não foi possível alterar a demonstração: ${error.message}`, true); }
});
document.getElementById("restore-demo").addEventListener("click", async () => {
  if (!window.confirm("Restaurar todos os valores fictícios originais da demonstração?")) return;
  await demoRepository.restore();
  demoRoleInput.value = "administrator"; demoSellerInput.value = "demo-carlos"; syncDemoFields();
  showStatus("Valores fictícios restaurados.");
});
document.getElementById("save-admin-panel").addEventListener("click", async () => {
  if (!(optionsAdministrator || bootstrapProvisioning || recoveryUnlock)) { showStatus("Somente um administrador confirmado pode alterar vínculos.", true); return; }
  if (!goalUnlocked) { showStatus("Confirme a senha administrativa para alterar vínculos.", true); await requestUnlock(); return; }
  const sessionName = adminSessionNameInput.value.trim();
  const userId = document.getElementById("binding-user-id").value.trim();
  const companyScopeKey = document.getElementById("binding-company").value.trim();
  const role = document.getElementById("binding-role").value;
  const sellerId = document.getElementById("binding-seller-id").value.trim();
  if (!sessionName || !userId || !companyScopeKey || (role === "seller" && !sellerId)) {
    showStatus("Informe login exato, userId, empresa e sellerId quando vendedor.", true);
    adminSessionNameInput.focus();
    return;
  }
  const current = await storage.get([keys.identityBindings]);
  const bindings = Array.isArray(current[keys.identityBindings]) ? current[keys.identityBindings] : [];
  const withoutSameScope = bindings.filter((item) => !(item.login === sessionName && item.companyScopeKey === companyScopeKey));
  withoutSameScope.push({ login: sessionName, userId, companyId: globalThis.AvanteSessionAccess.companyIdFromScope(companyScopeKey), companyScopeKey, role, sellerId: role === "seller" ? sellerId : null, sellerName: role === "seller" ? sessionName : null, approvedAt: new Date().toISOString() });
  await storage.set({ [keys.identityBindings]: withoutSameScope });
  showStatus("Vínculo explícito salvo. Recarregue o Codxis para confirmar a sessão.");
  const button = document.getElementById("save-admin-panel");
  const original = button.textContent;
  button.textContent = "Configuração aplicada";
  window.setTimeout(() => { button.textContent = original; }, 1800);
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!goalUnlocked) {
    showStatus("Digite a senha para alterar a meta.", true);
    await requestUnlock();
    return;
  }
  const amount = parseAmount(amountInput.value);

  amountError.hidden = amount > 0;
  amountInput.setAttribute("aria-invalid", String(!(amount > 0)));
  if (!(amount > 0)) {
    showStatus("Revise os campos destacados.", true);
    amountInput.focus();
    return;
  }

  saveButton.disabled = true;
  showStatus("Salvando…");
  try {
    await storage.set({
      [keys.goal]: { amount, period: "monthly" },
      [keys.collapsed]: collapsedInput.checked,
      [keys.diagnostics]: diagnosticsInput.checked
    });
    amountInput.value = formatAmount(amount);
    showStatus("Configurações salvas.");
  } catch (error) {
    showStatus(`Não foi possível salvar: ${error.message}`, true);
  } finally {
    saveButton.disabled = false;
  }
});

amountInput.addEventListener("input", () => {
  amountError.hidden = true;
  amountInput.removeAttribute("aria-invalid");
});

unlockButton.addEventListener("click", () => {
  requestUnlock().catch((error) =>
    showStatus(`Não foi possível acessar a senha: ${error.message}`, true)
  );
});

changePasswordButton.addEventListener("click", async () => {
  try {
    const hasPassword = await passwordProtection.hasPassword();
    openPasswordModal(hasPassword ? "change" : "setup", "change");
  } catch (error) {
    showStatus(`Não foi possível acessar a senha: ${error.message}`, true);
  }
});

passwordModal.querySelectorAll("[data-close-password]").forEach((button) => {
  button.addEventListener("click", closePasswordModal);
});

passwordForm.elements.showPassword.addEventListener("change", (event) => {
  const type = event.currentTarget.checked ? "text" : "password";
  passwordForm
    .querySelectorAll("input[type=password], input[type=text]")
    .forEach((input) => {
      if (input.name !== "showPassword") input.type = type;
    });
});

passwordForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const mode = passwordForm.dataset.mode;
  const purpose = passwordForm.dataset.purpose;
  const password = passwordForm.elements.password.value;
  const confirmation = passwordForm.elements.confirmation.value;
  const currentPassword = passwordForm.elements.currentPassword.value;
  const errorElement = document.getElementById("password-error");
  const submit = document.getElementById("password-submit");

  if (mode !== "login" && password.length < 4) {
    errorElement.textContent = "A senha deve possuir no mínimo 4 caracteres.";
    return;
  }
  if (mode !== "login" && password !== confirmation) {
    errorElement.textContent = "As senhas são diferentes.";
    return;
  }

  submit.disabled = true;
  errorElement.textContent = "";
  try {
    const result =
      mode === "setup"
        ? await passwordProtection.createPassword(password)
        : mode === "change"
          ? await passwordProtection.changePassword(currentPassword, password)
          : await passwordProtection.verifyPassword(password);

    if (!result.ok) {
      const messages = {
        blocked: "Muitas tentativas. Aguarde 5 minutos.",
        incorrect:
          mode === "change" ? "Senha atual incorreta." : "Senha incorreta.",
        "too-short": "A senha deve possuir no mínimo 4 caracteres.",
        "already-configured": "Uma senha já foi cadastrada.",
        "not-configured": "Nenhuma senha foi cadastrada."
      };
      errorElement.textContent =
        messages[result.reason] || "Não foi possível validar a senha.";
      return;
    }

    closePasswordModal();
    if (purpose === "recovery") {
      recoveryUnlock = true;
      goalUnlocked = true;
      document.getElementById("admin-security-section").hidden = false;
      document.getElementById("restricted-options").hidden = true;
      showStatus("Recuperação autorizada. Preencha o vínculo exato e clique em aplicar.");
      adminSessionNameInput.focus();
    } else if (purpose === "unlock" || mode === "setup") {
      setGoalUnlocked(true);
      amountInput.focus();
      showStatus("Edição da meta desbloqueada.");
    } else {
      showStatus("Senha alterada.");
    }
  } catch (error) {
    errorElement.textContent =
      `Não foi possível acessar o armazenamento: ${error.message}`;
  } finally {
    submit.disabled = false;
  }
});

Promise.all([loadPreferences(), loadDetectedSessionEvidence()]).catch((error) => {
  showStatus(`Não foi possível carregar as configurações: ${error.message}`, true);
  saveButton.disabled = true;
});

setGoalUnlocked(false);
