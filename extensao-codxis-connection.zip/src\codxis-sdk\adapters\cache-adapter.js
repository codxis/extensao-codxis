"use strict";

const { CodxisDataUnavailableError, CodxisScopeMismatchError } = require("../errors");
const { scopesEqual } = require("../scoped-storage");

class CacheAdapter {
  constructor(storage) {
    this.storage = storage;
  }

  async read(key, expectedScope) {
    const values = await this.storage.get([key]);
    const record = values[key];
    if (!record) {
      throw new CodxisDataUnavailableError("Não há cache para o escopo solicitado.");
    }
    if (!scopesEqual(record.scope, expectedScope)) {
      throw new CodxisScopeMismatchError(
        "O cache pertence a outro usuário, empresa, filial, vendedor ou mês."
      );
    }
    return record.value;
  }
}

module.exports = CacheAdapter;

