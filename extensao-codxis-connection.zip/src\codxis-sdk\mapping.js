"use strict";

// Configuração deliberadamente vazia. Preencher somente com evidência
// registrada em CODXIS_MAP.md e coberta por testes anonimizados.
const roleConfig = Object.freeze({
  administrator: Object.freeze({
    profileIds: Object.freeze([]),
    profileCodes: Object.freeze([]),
    permissions: Object.freeze([])
  }),
  seller: Object.freeze({
    profileIds: Object.freeze([]),
    profileCodes: Object.freeze([]),
    permissions: Object.freeze([])
  })
});

const mappings = Object.freeze({
  identity: null,
  companyMonthlyPerformance: null,
  sellerMonthlyPerformance: Object.freeze({
    endpoint:
      "https://web.codxis.api.br/sistema/pages/privado/relatoriosGerenciais/resumoGeral",
    method: "POST",
    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
    facesRequest: "partial/ajax",
    reportType: "Vendas por Vendedores/Colaboradores - Comissão",
    fields: Object.freeze({
      ajax: "jakarta.faces.partial.ajax",
      source: null,
      execute: "jakarta.faces.partial.execute",
      form: "form",
      reportType: "form:tipo_input",
      startDate: "form:diaInicial_input",
      endDate: "form:diaFinal_input",
      sort: "form:ordenarPor",
      operationTypes: Object.freeze(["form:tiposOp"]),
      hideAccounts: "form:ocultarContas_input",
      dateType: "form:tipoData",
      seller: null,
      repeatedSelections: Object.freeze([]),
      viewState: "jakarta.faces.ViewState"
    }),
    updateIds: Object.freeze([]),
    selectors: Object.freeze({
      sellerRows: Object.freeze([]),
      sellerId: Object.freeze([]),
      sellerName: Object.freeze([]),
      salesAmount: Object.freeze([]),
      commissionAmount: Object.freeze([]),
      totalAmount: Object.freeze([])
    })
  }),
  companySalesHistory: null,
  sellerSalesHistory: null
});

module.exports = { mappings, roleConfig };
