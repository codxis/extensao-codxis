"use strict";

class CodxisError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = new.target.name;
    this.code = new.target.code;
    this.details = details;
  }
}

class CodxisMappingError extends CodxisError {}
CodxisMappingError.code = "CODXIS_MAPPING_ERROR";

class CodxisIdentityError extends CodxisError {}
CodxisIdentityError.code = "CODXIS_IDENTITY_ERROR";

class CodxisAuthorizationError extends CodxisError {}
CodxisAuthorizationError.code = "CODXIS_AUTHORIZATION_ERROR";

class CodxisSessionExpiredError extends CodxisError {}
CodxisSessionExpiredError.code = "CODXIS_SESSION_EXPIRED";

class CodxisSellerLinkError extends CodxisError {}
CodxisSellerLinkError.code = "CODXIS_SELLER_LINK_ERROR";

class CodxisDataUnavailableError extends CodxisError {}
CodxisDataUnavailableError.code = "CODXIS_DATA_UNAVAILABLE";

class CodxisScopeMismatchError extends CodxisError {}
CodxisScopeMismatchError.code = "CODXIS_SCOPE_MISMATCH";

module.exports = {
  CodxisError,
  CodxisMappingError,
  CodxisIdentityError,
  CodxisAuthorizationError,
  CodxisSessionExpiredError,
  CodxisSellerLinkError,
  CodxisDataUnavailableError,
  CodxisScopeMismatchError
};

