(function (root) {
  "use strict";
  const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
  const percentage = new Intl.NumberFormat("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const escapeHtml = (value) => String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  const monthNow = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;

  class RoleDashboard {
    constructor(options = {}) {
      this.provider = options.provider;
      this.demo = this.provider?.mode === "demo";
      this.demoRepository = options.demoRepository || (this.demo ? new root.AvanteDemoData.DemoRepository(root.AvanteStorage) : null);
      this.passwordProtection = new root.AvantePasswordProtection(root.AvanteStorage);
      this.root = null;
      this.model = null;
      this.unlocked = false;
    }
    async mount(host, fallback = false) {
      if (!this.root) {
        this.root = document.createElement("section");
        this.root.id = "avante-dashboard";
        this.root.className = `avante-role-dashboard${fallback ? " avante-fallback" : ""}`;
        this.root.setAttribute("aria-label", "Demonstração de metas e resultados");
        host.prepend(this.root);
      }
      await this.refresh();
    }
    async refresh() {
      try {
        this.demoState = await this.demoRepository.load();
        this.provider = root.AvanteDemoMode.createProvider(this.demoState);
        const identity = await this.provider.getCurrentIdentity();
        this.identity = identity;
        if (identity.role === "seller") await this.loadSeller(identity);
        else await this.loadAdministrator(identity);
      } catch (error) {
        this.model = { mode: "restricted", reason: "data-unavailable", message: error.message };
      }
      this.render();
    }
    async loadSeller(identity) {
      const performance = await this.provider.getSellerMonthlySales(identity.sellerId);
      this.model = root.AvanteDashboardModels.createSellerDashboardModel({
        identity, month: monthNow(), goal: { amount: this.demoState.sellerGoals[identity.sellerId] }, performance,
        history: this.demoState.history.sellers[identity.sellerId] || [], demo: true
      });
    }
    async loadAdministrator(identity) {
      const sellers = await this.provider.getSellerList();
      const sellerGoals = Object.fromEntries(sellers.map((seller) => [seller.sellerId, { amount: this.demoState.sellerGoals[seller.sellerId] }]));
      const sellerPerformance = Object.fromEntries(await Promise.all(sellers.map(async (seller) => [seller.sellerId, await this.provider.getSellerMonthlySales(seller.sellerId)])));
      this.model = root.AvanteDashboardModels.createAdministratorDashboardModel({
        identity, month: monthNow(), companyGoal: { amount: this.demoState.companyGoal }, companyPerformance: await this.provider.getCompanyMonthlySales(), sellers, sellerGoals, sellerPerformance, demo: true
      });
      this.model = Object.freeze({ ...this.model, history: Object.freeze([...(this.demoState.history.company || [])]), companyName: this.provider.company.companyName });
    }
    demoHeader() {
      const options = root.AvanteDemoData.SELLERS.filter((seller) => seller.sellerId !== "demo-mariana").map((seller) => `<option value="${seller.sellerId}" ${this.demoState.profile.sellerId === seller.sellerId ? "selected" : ""}>Vendedor — ${escapeHtml(seller.sellerName)}</option>`).join("");
      return `<div class="avante-demo-banner"><strong>MODO DEMONSTRAÇÃO</strong><span>Os valores exibidos nesta tela são exemplos.</span></div>
        <label class="avante-profile-picker">Visualizar como<select data-action="profile"><option value="administrator" ${this.model.mode === "administrator" ? "selected" : ""}>Administrador</option>${options}</select></label>`;
    }
    metricsCards(row, includeForecast = false) {
      const cards = [["Meta mensal", row.goal], ["Realizado", row.sales], ["Restante", row.metrics.remainingAmount], ["Percentual", `${percentage.format(row.metrics.progress)}%`], ["Média diária necessária", row.metrics.dailyRequired], [`Meta para os próximos ${row.metrics.windowDays} dias`, row.metrics.weeklyRequired], ["Superávit", row.metrics.surplus]];
      if (includeForecast) cards.push(["Previsão de atingimento", row.metrics.forecast]);
      return `<div class="avante-role-metrics">${cards.map(([label, value]) => `<div><span>${label}</span><strong>${typeof value === "number" ? money.format(value) : value}</strong></div>`).join("")}</div><div class="avante-role-progress" role="progressbar" aria-valuenow="${Math.min(row.metrics.progress, 100)}"><i style="width:${Math.min(row.metrics.progress, 100)}%"></i></div>`;
    }
    chart(title, label) {
      return `<section class="avante-role-chart" data-role="chart"><h3>${title}</h3><div class="avante-chart-shell"><svg aria-label="${label}"></svg><p data-role="chart-empty">Histórico indisponível.</p><p data-role="chart-hint" hidden>Primeiro ponto do histórico.</p><output data-role="chart-tooltip" hidden></output></div></section>`;
    }
    insights(rows, company = null) {
      const lines = [];
      if (company) { lines.push(`Restam ${money.format(company.metrics.remainingAmount)} para atingir a meta.`); lines.push(`A empresa atingiu ${percentage.format(company.metrics.progress)}% da meta.`); }
      for (const row of rows) {
        const firstName = row.sellerName.split(" ")[0];
        if (row.metrics.surplus > 0) lines.push(`${firstName} ultrapassou a meta em ${money.format(row.metrics.surplus)}.`);
        else if (row.metrics.progress >= 90) lines.push(`${firstName} está próximo de atingir a meta.`);
        else lines.push(`${firstName} precisa vender em média ${money.format(row.metrics.dailyRequired)} por dia.`);
      }
      return `<aside class="avante-insights"><h3>Insights</h3><ul>${lines.map((line) => `<li>${line}</li>`).join("")}</ul></aside>`;
    }
    renderSeller() {
      const seller = this.model.seller;
      this.root.innerHTML = `${this.demoHeader()}<header><div><small>Desempenho individual</small><h2>${escapeHtml(seller.sellerName)}</h2></div><button type="button" data-action="refresh">Atualizar</button></header>${this.metricsCards(seller)}${seller.metrics.surplus > 0 ? `<p class="avante-goal-achieved">Meta atingida — Superávit: ${money.format(seller.metrics.surplus)}</p>` : ""}${this.insights([seller])}${this.chart("Evolução individual", "Gráfico individual de vendas")}<footer>Última atualização: ${new Date(this.model.capturedAt).toLocaleString("pt-BR")}</footer>`;
      this.bindCommon();
      this.renderChart(this.model.history, seller.goal);
    }
    renderAdministrator() {
      const company = { goal: this.model.companyGoal, sales: this.model.companySales, metrics: this.model.companyMetrics };
      const rows = this.model.sellers.map((seller) => `<tr><td>${seller.rank}</td><td><strong>${escapeHtml(seller.sellerName)}</strong>${seller.metrics.surplus > 0 ? '<small class="avante-goal-achieved">Meta atingida</small>' : ""}</td><td>${money.format(seller.goal)}</td><td>${money.format(seller.sales)}</td><td>${money.format(seller.metrics.remainingAmount)}</td><td>${percentage.format(seller.metrics.progress)}%</td><td>${money.format(seller.metrics.surplus)}</td><td><div class="avante-role-progress"><i style="width:${Math.min(seller.metrics.progress, 100)}%"></i></div></td></tr>`).join("");
      const inputs = this.model.sellers.map((seller) => `<label>${escapeHtml(seller.sellerName)}<input type="number" min="0.01" step="0.01" name="${seller.sellerId}" value="${seller.goal}" required></label>`).join("");
      this.root.innerHTML = `${this.demoHeader()}<header><div><small>Painel administrativo · ${escapeHtml(this.model.companyName)}</small><h2>Metas e desempenho</h2></div><button type="button" data-action="refresh">Atualizar</button></header><h3>Empresa</h3>${this.metricsCards(company, true)}${this.insights(this.model.sellers, company)}${this.chart("Evolução da empresa", "Gráfico de evolução da empresa")}<h3 class="avante-sellers-title">Vendedores</h3><div class="avante-role-table"><table><thead><tr><th>Posição</th><th>Nome</th><th>Meta</th><th>Realizado</th><th>Restante</th><th>Percentual</th><th>Superávit</th><th>Progresso</th></tr></thead><tbody>${rows}</tbody></table></div><section class="avante-role-editor"><button type="button" data-action="unlock">${this.unlocked ? "Edição liberada" : "Editar metas da demonstração"}</button>${this.unlocked ? `<form data-role="demo-goals"><label>Meta da empresa<input type="number" min="0.01" step="0.01" name="company" value="${this.model.companyGoal}" required></label>${inputs}<div class="avante-editor-actions"><button type="submit">Salvar metas fictícias</button><button type="button" class="secondary" data-action="restore">Restaurar valores da demonstração</button></div></form>` : ""}</section><footer>Última atualização: ${new Date(this.model.capturedAt).toLocaleString("pt-BR")}</footer>`;
      this.bindCommon();
      this.root.querySelector("[data-action=unlock]")?.addEventListener("click", () => this.requestUnlock());
      this.root.querySelector("[data-role=demo-goals]")?.addEventListener("submit", (event) => this.saveGoals(event));
      this.root.querySelector("[data-action=restore]")?.addEventListener("click", () => this.restore());
      this.renderChart(this.model.history, this.model.companyGoal);
    }
    bindCommon() {
      this.root.querySelector("[data-action=refresh]")?.addEventListener("click", () => this.refresh());
      this.root.querySelector("[data-action=profile]")?.addEventListener("change", async (event) => { const sellerId = event.currentTarget.value; await this.demoRepository.setProfile(sellerId === "administrator" ? { role: "administrator" } : { role: "seller", sellerId }); await this.refresh(); });
    }
    renderChart(history, goal) {
      const chart = new root.AvanteMiniChart.MiniChart(this.root.querySelector("[data-role=chart]"), { money, percentage, locale: "pt-BR" });
      chart.render(history, goal);
    }
    async requestUnlock() {
      let result;
      if (await this.passwordProtection.hasPassword()) { const password = window.prompt("Digite a senha administrativa local:"); if (password == null) return; result = await this.passwordProtection.verifyPassword(password); }
      else { const password = window.prompt("Cadastre uma senha administrativa local (mínimo 4 caracteres):"); if (password == null) return; const confirmation = window.prompt("Confirme a senha administrativa local:"); if (password !== confirmation) return window.alert("As senhas são diferentes."); result = await this.passwordProtection.createPassword(password); }
      if (!result.ok) return window.alert("Senha não validada.");
      this.unlocked = true; this.render();
    }
    async saveGoals(event) {
      event.preventDefault(); if (!this.unlocked || this.model.mode !== "administrator") return;
      const form = new FormData(event.currentTarget); const sellerGoals = {};
      for (const seller of this.model.sellers) sellerGoals[seller.sellerId] = Number(form.get(seller.sellerId));
      await this.demoRepository.setCompanyGoal(Number(form.get("company"))); await this.demoRepository.setSellerGoals(sellerGoals); await this.refresh();
    }
    async restore() { if (!window.confirm("Restaurar todos os valores fictícios originais da demonstração?")) return; await this.demoRepository.restore(); await this.refresh(); }
    renderRestricted() { this.root.innerHTML = `<div class="avante-demo-banner"><strong>MODO DEMONSTRAÇÃO</strong></div><p class="avante-role-state">Dados de demonstração indisponíveis.</p>`; }
    render() { if (!this.root) return; if (this.model?.mode === "seller") this.renderSeller(); else if (this.model?.mode === "administrator") this.renderAdministrator(); else this.renderRestricted(); }
  }
  root.AvanteRoleDashboard = RoleDashboard;
  if (typeof module !== "undefined" && module.exports) module.exports = RoleDashboard;
})(typeof globalThis !== "undefined" ? globalThis : this);
