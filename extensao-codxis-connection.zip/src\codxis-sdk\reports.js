"use strict";

const { CodxisMappingError } = require("./errors");

function parseFormUrlEncoded(body) {
  if (typeof body !== "string") {
    throw new TypeError("O corpo form-urlencoded deve ser uma string.");
  }
  const fields = {};
  for (const [name, value] of new URLSearchParams(body)) {
    (fields[name] ||= []).push(value);
  }
  return fields;
}

function parseJsfPartialResponse(xml) {
  if (typeof xml !== "string" || !/<partial-response[\s>]/i.test(xml)) {
    throw new CodxisMappingError("A resposta não é um partial-response JSF válido.");
  }
  const updates = [];
  const pattern =
    /<update\b[^>]*\bid=(?:"([^"]*)"|'([^']*)')[^>]*>([\s\S]*?)<\/update>/gi;
  let match;
  while ((match = pattern.exec(xml))) {
    const raw = match[3].trim();
    const cdata = raw.match(/^<!\[CDATA\[([\s\S]*?)\]\]>$/);
    updates.push(Object.freeze({
      id: match[1] || match[2] || "",
      content: cdata ? cdata[1] : raw
    }));
  }
  return Object.freeze({ updates: Object.freeze(updates) });
}

function decodeHtml(text) {
  return String(text || "")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function cellText(cell) {
  return decodeHtml(String(cell || "").replace(/<[^>]*>/g, " "));
}

function parseBrazilianAmount(value) {
  const text = decodeHtml(value).replace(/[^\d,.-]/g, "");
  if (!text) return null;
  const normalized = text.includes(",")
    ? text.replace(/\./g, "").replace(",", ".")
    : text;
  const amount = Number(normalized);
  return Number.isFinite(amount) ? amount : null;
}

function parseSellerSalesReport(xml) {
  const parsed = parseJsfPartialResponse(xml);
  const update = parsed.updates.find((item) => item.id === "form:painelGeralRelatorios");
  if (!update) {
    return Object.freeze({
      sellers: Object.freeze([]),
      totals: Object.freeze({ documentValue: null, commissionBase: null, commissionValue: null }),
      pagination: Object.freeze({ detected: false, liveScroll: null, scrollLimit: null, paginator: false })
    });
  }
  const html = update.content;
  const table = html.match(/<tbody\b[^>]*id=["']form:datatableVendasVendedores_data["'][^>]*>([\s\S]*?)<\/tbody>/i);
  const sellers = [];
  for (const row of table ? table[1].matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi) : []) {
    if (/ui-datatable-empty-message/i.test(row[0])) continue;
    const cells = [...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map((match) => cellText(match[1]));
    if (cells.length < 5) continue;
    sellers.push(Object.freeze({
      sellerName: cells[1] || "",
      sellerId: null,
      documentValue: parseBrazilianAmount(cells[2]),
      commissionBase: parseBrazilianAmount(cells[3]),
      commissionValue: parseBrazilianAmount(cells[4])
    }));
  }
  const readId = (id) => {
    const match = html.match(new RegExp(`<[^>]+\\bid=["']form:${id}["'][^>]*>([\\s\\S]*?)<\\/[^>]+>`, "i"));
    return match ? parseBrazilianAmount(cellText(match[1])) : null;
  };
  const script = html.match(/PrimeFaces\.cw\("DataTable","widget_form_datatableVendasVendedores",\{([\s\S]*?)\}\);/i)?.[1] || "";
  const liveScroll = script.match(/liveScroll:(true|false)/i);
  const scrollLimit = script.match(/scrollLimit:(\d+)/i);
  return Object.freeze({
    sellers: Object.freeze(sellers),
    totals: Object.freeze({
      documentValue: readId("totalDocumento"),
      commissionBase: readId("totalBase"),
      commissionValue: readId("totalComissao")
    }),
    pagination: Object.freeze({
      detected: /paginator\s*:/i.test(script) || /paginator/i.test(html),
      liveScroll: liveScroll ? liveScroll[1].toLowerCase() === "true" : null,
      scrollLimit: scrollLimit ? Number(scrollLimit[1]) : null,
      paginator: /paginator\s*:/i.test(script)
    })
  });
}

async function getCompanySalesHistory() {
  throw new CodxisMappingError(
    "O histórico oficial de vendas da empresa ainda não foi identificado."
  );
}

async function getSellerSalesHistory(_sellerId) {
  throw new CodxisMappingError(
    "O histórico oficial de vendas por vendedor ainda não foi identificado."
  );
}

module.exports = {
  getCompanySalesHistory,
  getSellerSalesHistory,
  parseFormUrlEncoded,
  parseJsfPartialResponse,
  parseSellerSalesReport
};
