"use strict";

const { CodxisMappingError } = require("../errors");

class ApiAdapter {
  async read(_mapping, _input) {
    throw new CodxisMappingError(
      "Nenhum endpoint de API de negócio foi confirmado."
    );
  }
}

module.exports = ApiAdapter;

