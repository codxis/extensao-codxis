"use strict";

const { CodxisMappingError } = require("./errors");

async function getCurrentCompany() {
  throw new CodxisMappingError(
    "O mapeamento da empresa atual ainda não foi identificado."
  );
}

async function getCurrentBranch() {
  throw new CodxisMappingError(
    "O mapeamento da filial atual ainda não foi identificado."
  );
}

module.exports = { getCurrentBranch, getCurrentCompany };

