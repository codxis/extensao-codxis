(function (root) {
  "use strict";

  const CODXIS_HOST = "web.codxis.api.br";
  const CODXIS_HOME_PATH = "/sistema/pages/privado/index";

  function parseCodxisUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      const pathname = url.pathname.replace(/\/+$/, "").replace(/\.xhtml$/i, "") || "/";
      return {
        isCodxis: url.protocol === "https:" && url.hostname === CODXIS_HOST,
        hostname: url.hostname,
        pathname,
        sanitizedUrl: `${url.protocol}//${url.host}${url.pathname}`
      };
    } catch (_) {
      return { isCodxis: false, hostname: "", pathname: "", sanitizedUrl: "" };
    }
  }

  function isCodxisHomeUrl(rawUrl) {
    const parsed = parseCodxisUrl(rawUrl);
    return parsed.isCodxis && parsed.pathname === CODXIS_HOME_PATH;
  }

  function detectCodxisHome(rawUrl, documentRef, config) {
    const parsed = parseCodxisUrl(rawUrl);
    const selectors = config?.mount?.homeExclusiveSelectors || [];
    const textGroups = config?.mount?.homeTextEvidenceGroups || [];
    const bodyText = String(documentRef?.body?.innerText || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const selectorMatched = selectors.some((selector) => {
      try { return Boolean(documentRef?.querySelector(selector)); } catch (_) { return false; }
    });
    const textMatched = textGroups.some((group) => group.length && group.every((text) =>
      bodyText.includes(String(text).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase())
    ));
    const domMatched = selectorMatched || textMatched;
    const urlMatched = isCodxisHomeUrl(rawUrl);
    return {
      isCodxis: parsed.isCodxis,
      isHome: parsed.isCodxis && (urlMatched || domMatched),
      urlMatched,
      domMatched,
      pathname: parsed.pathname
    };
  }

  root.AvantePageContext = Object.freeze({
    CODXIS_HOST,
    CODXIS_HOME_PATH,
    CODXIS_HOME_URL: `https://${CODXIS_HOST}${CODXIS_HOME_PATH}`,
    parseCodxisUrl,
    isCodxisHomeUrl,
    detectCodxisHome
  });

  if (typeof module !== "undefined" && module.exports) module.exports = root.AvantePageContext;
})(typeof globalThis !== "undefined" ? globalThis : this);
