(function (root) {
  "use strict";
  // Gerado por tools/customer-bindings/generate.js — cliente: Connection.
  // Não edite à mão: ajuste o config.json e gere novamente. A presença de
  // vínculos aqui substitui integralmente os vínculos base (demonstração).
  root.AvanteCustomerBindings = () => ({
    customer: "Connection",
      admins: [
        { login: "Junior", userId: "29", companyId: "43381", companyScopeKey: "43381-AVANTE_2942", role: "administrator" },
        { login: "Junior", userId: "29", companyId: "45889", companyScopeKey: "45889-AVANTE_3067", role: "administrator" }
      ],
      assignments: [
        { companyScopeKey: "43381-AVANTE_2942", userId: "26", sellerId: "141352", localSellerKey: "local:ivan:975c6b01" },
        { companyScopeKey: "43381-AVANTE_2942", userId: "20", sellerId: "141440", localSellerKey: "local:janderson-alves-vasconcelos:fe6e4c1e" },
        { companyScopeKey: "43381-AVANTE_2942", userId: "33", sellerId: "141494", localSellerKey: "local:lucas-ribeiro:80f58efe" },
        { companyScopeKey: "43381-AVANTE_2942", userId: "34", sellerId: "141549", localSellerKey: "local:bianca:7ea493f3" }
      ],
      sellers: [
        { login: "Ivan", userId: "26", companyId: "43381", companyScopeKey: "43381-AVANTE_2942", role: "seller", sellerId: "141352", sellerName: "IVAN", localSellerKey: "local:ivan:975c6b01" },
        { login: "Janderson", userId: "20", companyId: "43381", companyScopeKey: "43381-AVANTE_2942", role: "seller", sellerId: "141440", sellerName: "JANDERSON ALVES VASCONCELOS", localSellerKey: "local:janderson-alves-vasconcelos:fe6e4c1e" },
        { login: "Lucas Ribeiro", userId: "33", companyId: "43381", companyScopeKey: "43381-AVANTE_2942", role: "seller", sellerId: "141494", sellerName: "LUCAS RIBEIRO", localSellerKey: "local:lucas-ribeiro:80f58efe" },
        { login: "Bianca", userId: "34", companyId: "43381", companyScopeKey: "43381-AVANTE_2942", role: "seller", sellerId: "141549", sellerName: "BIANCA", localSellerKey: "local:bianca:7ea493f3" }
      ]
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
