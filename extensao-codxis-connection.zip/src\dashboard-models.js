(function (root) {
  "use strict";

  const calculate = (goal, sales, date) => {
    if (!(goal > 0) || !Number.isFinite(sales)) return null;
    return root.AvanteGoalCalculator.calculateMonthlyGoalMetrics(goal, sales, date);
  };

  const sellerRow = (seller, goalRecord, performance, date) => {
    const goal = goalRecord?.amount ?? null;
    const sales = Number.isFinite(performance?.sales) ? performance.sales : null;
    const metrics = calculate(goal, sales, date);
    return Object.freeze({
      sellerId: seller.sellerId,
      sellerName: seller.sellerName || null,
      goal,
      sales,
      metrics,
      state: goal == null
        ? "missing-goal"
        : sales == null
          ? "unavailable"
          : "ready"
    });
  };

  function createSellerDashboardModel(input) {
    const identity = input.identity;
    if (identity?.role !== "seller") {
      return Object.freeze({ mode: "restricted", reason: "unknown-profile" });
    }
    if (!identity.sellerId) {
      return Object.freeze({ mode: "restricted", reason: "missing-seller-link" });
    }
    if (input.performance?.sellerId !== identity.sellerId) {
      return Object.freeze({ mode: "restricted", reason: "scope-mismatch" });
    }
    const row = sellerRow({ sellerId: identity.sellerId, sellerName: identity.sellerName }, input.goal, input.performance, input.date);
    return Object.freeze({ userId: identity.userId, sellerId: identity.sellerId, sellerName: row.sellerName, companyScopeKey: identity.companyScopeKey || identity.companyId, month: input.month, goal: row.goal, realized: row.sales, progress: row.metrics?.progress ?? null, remaining: row.metrics?.remainingAmount ?? null, surplus: row.metrics?.surplus ?? null, individualHistory: Object.freeze([...(input.history || [])].filter((point) => !point.sellerId || point.sellerId === identity.sellerId)), capturedAt: input.performance.capturedAt || null });
  }

  function createAdministratorDashboardModel(input) {
    if (input.identity?.role !== "administrator") {
      return Object.freeze({ mode: "restricted", reason: "unknown-profile" });
    }
    const sellers = (input.sellers || []).map((seller) =>
      sellerRow(
        seller,
        input.sellerGoals?.[seller.sellerId] || null,
        input.sellerPerformance?.[seller.sellerId] || null,
        input.date
      )
    );
    const ranked = sellers
      .filter((seller) => seller.metrics)
      .sort((left, right) =>
        right.metrics.progress - left.metrics.progress ||
        right.sales - left.sales ||
        String(left.sellerName || "").localeCompare(String(right.sellerName || ""), "pt-BR")
      )
      .map((seller, index) => Object.freeze({ ...seller, rank: index + 1 }));
    const unranked = sellers
      .filter((seller) => !seller.metrics)
      .map((seller) => Object.freeze({ ...seller, rank: null }));
    return Object.freeze({
      mode: "administrator",
      demo: Boolean(input.demo),
      companyId: input.identity.companyId,
      branchId: input.identity.branchId,
      month: input.month,
      companyGoal: input.companyGoal?.amount ?? null,
      companySales: Number.isFinite(input.companyPerformance?.sales)
        ? input.companyPerformance.sales
        : null,
      companyMetrics: calculate(
        input.companyGoal?.amount,
        input.companyPerformance?.sales,
        input.date
      ),
      sellers: Object.freeze([...ranked, ...unranked]),
      state: sellers.length ? "ready" : "missing-seller-list",
      capturedAt: input.companyPerformance?.capturedAt || null
    });
  }

  const api = Object.freeze({
    createAdministratorDashboardModel,
    createSellerDashboardModel
  });
  root.AvanteDashboardModels = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
