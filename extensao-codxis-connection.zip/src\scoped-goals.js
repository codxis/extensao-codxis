(function (root) {
  "use strict";

  const STORAGE_KEY = "avante.goals";
  const SCHEMA_VERSION = 2;

  const required = (name, value) => {
    const normalized = typeof value === "string" ? value.trim() : "";
    if (!normalized) throw new TypeError(`${name} é obrigatório.`);
    return encodeURIComponent(normalized);
  };

  const validMonth = (month) => {
    const normalized = typeof month === "string" ? month.trim() : "";
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(normalized)) {
      throw new TypeError("month deve usar YYYY-MM.");
    }
    return normalized;
  };

  const companyKey = ({ companyId, branchId, month }) =>
    `company-${required("companyId", companyId)}:branch-${required("branchId", branchId)}:month-${validMonth(month)}`;

  const sellerKey = ({ companyId, branchId, sellerId, month }) =>
    `company-${required("companyId", companyId)}:branch-${required("branchId", branchId)}:seller-${required("sellerId", sellerId)}:month-${validMonth(month)}`;

  const emptyState = () => ({
    schemaVersion: SCHEMA_VERSION,
    companyGoals: {},
    sellerGoals: {}
  });

  const normalizeAmount = (amount) =>
    typeof amount === "number" && Number.isFinite(amount) && amount > 0
      ? amount
      : null;

  class ScopedGoalRepository {
    constructor(storage, options = {}) {
      this.storage = storage;
      this.key = options.key || STORAGE_KEY;
      this.now = options.now || (() => new Date().toISOString());
    }

    async load() {
      const values = await this.storage.get([this.key]);
      const value = values[this.key];
      return value?.schemaVersion === SCHEMA_VERSION ? value : emptyState();
    }

    async save(state) {
      await this.storage.set({ [this.key]: state });
      return state;
    }

    async getCompanyGoal(scope) {
      const state = await this.load();
      return state.companyGoals[companyKey(scope)] || null;
    }

    async setCompanyGoal(scope, amount, updatedByUserId) {
      const normalized = normalizeAmount(amount);
      if (normalized == null) throw new TypeError("A meta deve ser maior que zero.");
      const state = await this.load();
      const record = {
        companyId: scope.companyId,
        branchId: scope.branchId,
        month: validMonth(scope.month),
        amount: normalized,
        updatedAt: this.now(),
        updatedByUserId: updatedByUserId || null
      };
      state.companyGoals[companyKey(scope)] = record;
      await this.save(state);
      return record;
    }

    async getSellerGoal(scope) {
      const state = await this.load();
      return state.sellerGoals[sellerKey(scope)] || null;
    }

    async setSellerGoal(scope, amount, updatedByUserId, sellerName = null) {
      const normalized = normalizeAmount(amount);
      if (normalized == null) throw new TypeError("A meta deve ser maior que zero.");
      const state = await this.load();
      const record = {
        companyId: scope.companyId,
        branchId: scope.branchId,
        sellerId: scope.sellerId,
        sellerName,
        month: validMonth(scope.month),
        amount: normalized,
        updatedAt: this.now(),
        updatedByUserId: updatedByUserId || null
      };
      state.sellerGoals[sellerKey(scope)] = record;
      await this.save(state);
      return record;
    }

    async listSellerGoals(scope) {
      const state = await this.load();
      const prefix =
        `company-${required("companyId", scope.companyId)}:` +
        `branch-${required("branchId", scope.branchId)}:seller-`;
      const suffix = `:month-${validMonth(scope.month)}`;
      return Object.entries(state.sellerGoals)
        .filter(([key]) => key.startsWith(prefix) && key.endsWith(suffix))
        .map(([, value]) => value);
    }
  }

  class MemoryGoalRepository extends ScopedGoalRepository {
    constructor(initial = {}) {
      const values = { [STORAGE_KEY]: { ...emptyState(), ...initial } };
      super({
        async get(keys) {
          return Object.fromEntries(keys.map((key) => [key, values[key]]));
        },
        async set(entries) {
          Object.assign(values, entries);
        }
      });
      this.values = values;
    }
  }

  const api = Object.freeze({
    MemoryGoalRepository,
    SCHEMA_VERSION,
    STORAGE_KEY,
    ScopedGoalRepository,
    companyKey,
    emptyState,
    sellerKey
  });
  root.AvanteScopedGoals = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);

