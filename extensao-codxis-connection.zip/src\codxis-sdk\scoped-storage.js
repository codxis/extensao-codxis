"use strict";

const { CodxisScopeMismatchError } = require("./errors");
const { optionalString } = require("./contracts");

const SCHEMA_VERSION = 2;
const KEYS = Object.freeze({
  goals: "avante.goals",
  sessionContext: "avante.sessionContext",
  scopedSnapshots: "avante.scopedSnapshots",
  scopedSalesHistory: "avante.scopedSalesHistory",
  goalMigration: "avante.goalMigration"
});

const LEGACY_KEYS = Object.freeze([
  "avante.goal",
  "avante.snapshot",
  "avante.salesHistory",
  "avante.password",
  "avante.passwordAttempts",
  "avante.passwordBlockedUntil",
  "avante.diagnostics",
  "avante.collapsed"
]);

function requirePart(name, value) {
  const normalized = optionalString(value);
  if (!normalized) {
    throw new CodxisScopeMismatchError(`${name} é obrigatório para esta chave.`);
  }
  return encodeURIComponent(normalized);
}

function monthPart(month) {
  const normalized = optionalString(month);
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(normalized || "")) {
    throw new CodxisScopeMismatchError("month deve usar o formato YYYY-MM.");
  }
  return normalized;
}

function companyGoalKey({ companyId, branchId, month }) {
  return `company-${requirePart("companyId", companyId)}:branch-${requirePart("branchId", branchId)}:month-${monthPart(month)}`;
}

function sellerGoalKey({ companyId, branchId, sellerId, month }) {
  return `company-${requirePart("companyId", companyId)}:branch-${requirePart("branchId", branchId)}:seller-${requirePart("sellerId", sellerId)}:month-${monthPart(month)}`;
}

function snapshotScopeKey(scope) {
  return [
    `company-${requirePart("companyId", scope.companyId)}`,
    `branch-${requirePart("branchId", scope.branchId)}`,
    `user-${requirePart("userId", scope.userId)}`,
    `seller-${scope.sellerId ? encodeURIComponent(scope.sellerId) : "none"}`,
    `month-${monthPart(scope.month)}`
  ].join(":");
}

function normalizeScope(scope = {}) {
  return {
    companyId: optionalString(scope.companyId),
    branchId: optionalString(scope.branchId),
    userId: optionalString(scope.userId),
    sellerId: optionalString(scope.sellerId),
    month: optionalString(scope.month),
    sessionFingerprint: optionalString(scope.sessionFingerprint)
  };
}

function scopesEqual(left, right) {
  const a = normalizeScope(left);
  const b = normalizeScope(right);
  return Object.keys(a).every((key) => a[key] === b[key]);
}

function createEmptyGoals() {
  return {
    schemaVersion: SCHEMA_VERSION,
    companyGoals: {},
    sellerGoals: {}
  };
}

async function prepareVersionedStorage(storage) {
  const values = await storage.get([KEYS.goals]);
  const existing = values[KEYS.goals];
  if (existing?.schemaVersion === SCHEMA_VERSION) return existing;
  // Não converte avante.goal: empresa e filial ainda não são conhecidas.
  if (existing !== undefined) return existing;
  const empty = createEmptyGoals();
  await storage.set({ [KEYS.goals]: empty });
  return empty;
}

async function inspectLegacyState(storage) {
  return storage.get(LEGACY_KEYS);
}

module.exports = {
  KEYS,
  LEGACY_KEYS,
  SCHEMA_VERSION,
  companyGoalKey,
  createEmptyGoals,
  inspectLegacyState,
  normalizeScope,
  prepareVersionedStorage,
  scopesEqual,
  sellerGoalKey,
  snapshotScopeKey
};

