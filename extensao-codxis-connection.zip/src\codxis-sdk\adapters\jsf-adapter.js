"use strict";

const { CodxisMappingError } = require("../errors");

class JsfAdapter {
  async read(_mapping, _input) {
    throw new CodxisMappingError(
      "Nenhuma consulta JSF de negócio foi confirmada."
    );
  }
}

module.exports = JsfAdapter;

