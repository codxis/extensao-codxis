(function (root) {
  "use strict";
  const STATES = Object.freeze({
    NOT_CODXIS: "NOT_CODXIS",
    CODXIS_OTHER_PAGE: "CODXIS_OTHER_PAGE",
    CODXIS_HOME_OPEN: "CODXIS_HOME_OPEN",
    CODXIS_HOME_CLOSED: "CODXIS_HOME_CLOSED",
    CODXIS_HOME_COLLAPSED: "CODXIS_HOME_COLLAPSED",
    INITIALIZING: "INITIALIZING",
    COMMUNICATION_ERROR: "COMMUNICATION_ERROR"
  });
  const VIEW = Object.freeze({
    NOT_CODXIS: ["Abra o Codxis Web para usar a extensão.", "Mostrar dashboard"],
    CODXIS_OTHER_PAGE: ["O painel está disponível na página inicial do Codxis.", "Ir para a home"],
    CODXIS_HOME_OPEN: ["Painel ativo na página inicial.", "Mostrar dashboard"],
    CODXIS_HOME_CLOSED: ["Painel fechado nesta página.", "Abrir painel"],
    CODXIS_HOME_COLLAPSED: ["Painel recolhido nesta página.", "Expandir painel"],
    INITIALIZING: ["A extensão está inicializando.", "Tentar novamente"],
    COMMUNICATION_ERROR: ["Não foi possível consultar o estado da página.", "Tentar novamente"]
  });
  function fromContext(context) {
    if (!context?.isCodxis) return STATES.NOT_CODXIS;
    if (!context.isHome) return STATES.CODXIS_OTHER_PAGE;
    if (context.panelClosed) return STATES.CODXIS_HOME_CLOSED;
    if (context.panelCollapsed) return STATES.CODXIS_HOME_COLLAPSED;
    return STATES.CODXIS_HOME_OPEN;
  }
  root.AvantePopupState = Object.freeze({ STATES, VIEW, fromContext });
  if (typeof module !== "undefined" && module.exports) module.exports = root.AvantePopupState;
})(typeof globalThis !== "undefined" ? globalThis : this);
