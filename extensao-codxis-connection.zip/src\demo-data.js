(function (root) {
  "use strict";
  const KEYS = Object.freeze({ enabled: "avante.demo.enabled", profile: "avante.demo.profile", companyGoal: "avante.demo.companyGoal", sellerGoals: "avante.demo.sellerGoals", history: "avante.demo.history" });
  const COMPANY = Object.freeze({ companyId: "demo-company", branchId: "demo-branch", companyName: "Loja Exemplo" });
  const SELLERS = Object.freeze([
    Object.freeze({ sellerId: "demo-carlos", sellerName: "Carlos Silva", goal: 30000, sales: 28500 }),
    Object.freeze({ sellerId: "demo-ana", sellerName: "Ana Souza", goal: 25000, sales: 19750 }),
    Object.freeze({ sellerId: "demo-joao", sellerName: "João Martins", goal: 20000, sales: 21200 }),
    Object.freeze({ sellerId: "demo-mariana", sellerName: "Mariana Costa", goal: 15000, sales: 9800 })
  ]);
  const DEFAULT_PROFILE = Object.freeze({ role: "administrator", sellerId: null });
  const COMPANY_GOAL = 100000;
  const COMPANY_SALES = 78500;
  const localDate = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  function historyFor(total, index, today = new Date()) {
    const count = Math.min(13, today.getDate());
    return Array.from({ length: count }, (_, offset) => {
      const date = new Date(today.getFullYear(), today.getMonth(), today.getDate() - count + offset + 1, 12);
      const ratio = (offset + 1) / count;
      const curve = Math.min(1, ratio * (0.94 + ((offset + index) % 3) * 0.025));
      return Object.freeze({ date: localDate(date), timestamp: date.getTime(), monthlySales: offset === count - 1 ? total : Math.round(total * curve) });
    });
  }
  function createDefaultHistory(today = new Date()) {
    return { company: historyFor(COMPANY_SALES, 2, today), sellers: Object.fromEntries(SELLERS.map((seller, index) => [seller.sellerId, historyFor(seller.sales, index, today)])) };
  }
  const defaultSellerGoals = () => Object.fromEntries(SELLERS.map((seller) => [seller.sellerId, seller.goal]));
  const defaults = (today = new Date()) => ({ [KEYS.profile]: { ...DEFAULT_PROFILE }, [KEYS.companyGoal]: COMPANY_GOAL, [KEYS.sellerGoals]: defaultSellerGoals(), [KEYS.history]: createDefaultHistory(today) });
  const validProfile = (value) => value?.role === "seller" && SELLERS.some((seller) => seller.sellerId === value.sellerId) ? { role: "seller", sellerId: value.sellerId } : { ...DEFAULT_PROFILE };
  class DemoRepository {
    constructor(storage, now = () => new Date()) { this.storage = storage; this.now = now; }
    async load() {
      const values = await this.storage.get(Object.values(KEYS));
      const initial = defaults(this.now());
      const missing = {};
      for (const key of [KEYS.profile, KEYS.companyGoal, KEYS.sellerGoals, KEYS.history]) if (values[key] == null) missing[key] = initial[key];
      if (Object.keys(missing).length) await this.storage.set(missing);
      return { enabled: values[KEYS.enabled] === true, profile: validProfile(values[KEYS.profile] ?? initial[KEYS.profile]), companyGoal: values[KEYS.companyGoal] > 0 ? values[KEYS.companyGoal] : initial[KEYS.companyGoal], sellerGoals: { ...initial[KEYS.sellerGoals], ...(values[KEYS.sellerGoals] || {}) }, history: values[KEYS.history] || initial[KEYS.history] };
    }
    async setEnabled(enabled) { await this.storage.set({ [KEYS.enabled]: enabled === true }); }
    async setProfile(profile) { await this.storage.set({ [KEYS.profile]: validProfile(profile) }); }
    async setCompanyGoal(amount) { if (!(amount > 0)) throw new TypeError("A meta deve ser maior que zero."); await this.storage.set({ [KEYS.companyGoal]: amount }); }
    async setSellerGoals(goals) { if (!goals || Object.values(goals).some((amount) => !(amount > 0))) throw new TypeError("As metas devem ser maiores que zero."); await this.storage.set({ [KEYS.sellerGoals]: { ...goals } }); }
    async restore() { await this.storage.set(defaults(this.now())); return this.load(); }
  }
  const api = Object.freeze({ KEYS, COMPANY, COMPANY_GOAL, COMPANY_SALES, DEFAULT_PROFILE, SELLERS, DemoRepository, createDefaultHistory, defaultSellerGoals, defaults, validProfile });
  root.AvanteDemoData = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
