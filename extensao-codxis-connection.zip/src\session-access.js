(function (root) {
  "use strict";

  const ROLES = new Set(["administrator", "seller"]);
  const BINDINGS_KEY = "avante.security.identityBindings.v1";
  const ACTIVE_SESSION_KEY = "avante.security.activeSession.v1";
  const SCOPED_DATA_PREFIX = "avante.security.scope.v1:";
  const exact = (value) => String(value ?? "").trim();
  const identityKey = (value) => exact(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").toUpperCase();
  const numberOrNull = (value) => value === null || value === undefined || value === "" || !Number.isFinite(Number(value)) ? null : Number(value);
  const monthPattern = /^\d{4}-(0[1-9]|1[0-2])$/;
  const freeze = (value) => Object.freeze(value);
  // Vínculos base do repositório de desenvolvimento (demonstração). Não
  // concedem papel a vendedores e não usam aproximação.
  const BASE_ADMIN_BINDINGS = freeze([
    freeze({ login: "DEMO WEB CODXIS", userId: "9", companyId: "35379", companyScopeKey: "35379-AVANTE_2500", role: "administrator" }),
    freeze({ login: "Demo Web Codxis", userId: "9", companyId: "35379", companyScopeKey: "35379-AVANTE_2500", role: "administrator" })
  ]);
  const BASE_SELLER_ASSIGNMENTS = freeze([
    freeze({ companyScopeKey: "35379-AVANTE_2500", userId: "39", sellerId: "22447", localSellerKey: "local:davi-suporte:4c8d1ee8" })
  ]);
  const BASE_SELLER_BINDINGS = freeze([
    freeze({ login: "Davi", userId: "39", companyId: "35379", companyScopeKey: "35379-AVANTE_2500", role: "seller", sellerId: "22447", sellerName: "DAVI SUPORTE", localSellerKey: "local:davi-suporte:4c8d1ee8" }),
    freeze({ login: "Davi Suporte", userId: "39", companyId: "35379", companyScopeKey: "35379-AVANTE_2500", role: "seller", sellerId: "22447", sellerName: "DAVI SUPORTE", localSellerKey: "local:davi-suporte:4c8d1ee8" }),
    // O Codxis pode exibir o nome canônico do mesmo usuário no cabeçalho.
    // Mantemos uma segunda evidência exata, presa ao mesmo userId/sellerId;
    // não há comparação aproximada ou autorização somente pelo nome.
    freeze({ login: "DAVI SUPORTE", userId: "39", companyId: "35379", companyScopeKey: "35379-AVANTE_2500", role: "seller", sellerId: "22447", sellerName: "DAVI SUPORTE", localSellerKey: "local:davi-suporte:4c8d1ee8" })
  ]);
  // Build de cliente: src/customer-bindings.js, gerado por
  // tools/customer-bindings/generate.js --write, SUBSTITUI integralmente os
  // vínculos base — a demonstração deixa de existir no build entregue.
  const customerBindings = typeof root.AvanteCustomerBindings === "function" ? root.AvanteCustomerBindings() : null;
  const customerMode = Boolean(customerBindings && ((Array.isArray(customerBindings.admins) && customerBindings.admins.length) || (Array.isArray(customerBindings.sellers) && customerBindings.sellers.length)));
  const APPROVED_ADMIN_BINDINGS = freeze(customerMode && Array.isArray(customerBindings.admins) ? customerBindings.admins.map(freeze) : BASE_ADMIN_BINDINGS);
  const APPROVED_SELLER_ASSIGNMENTS = freeze(customerMode && Array.isArray(customerBindings.assignments) ? customerBindings.assignments.map(freeze) : BASE_SELLER_ASSIGNMENTS);
  const APPROVED_SELLER_BINDINGS = freeze(customerMode && Array.isArray(customerBindings.sellers) ? customerBindings.sellers.map(freeze) : BASE_SELLER_BINDINGS);

  function currentSessionLogin(doc = document, extraApprovedBindings = []) {
    const selectors = ["#name-user", "[data-login]", "[data-user-name]", ".name-user", ".user-name", ".username", ".topbar-user-name", ".user-info strong"];
    const controls = [];
    for (const selector of selectors) {
      try {
        const matches = doc.querySelectorAll?.(selector) || (selector === "#name-user" && doc.getElementById?.("name-user") ? [doc.getElementById("name-user")] : []);
        for (const match of matches) if (match && !controls.includes(match)) controls.push(match);
      } catch (_) {}
    }
    const candidates = controls.flatMap((control) => [control.getAttribute?.("data-login"), control.getAttribute?.("data-user-name"), control.getAttribute?.("aria-label"), control.getAttribute?.("title"), control.textContent, ...String(control.textContent || "").split(/[\r\n]+/)]).map(exact).filter(Boolean);
    // Vínculos salvos pelo administrador nas opções participam da mesma
    // evidência exata/delimitada dos embutidos; nunca ampliam para aproximação.
    const approved = [...APPROVED_ADMIN_BINDINGS, ...APPROVED_SELLER_BINDINGS, ...(Array.isArray(extraApprovedBindings) ? extraApprovedBindings : [])].filter(validBinding);
    const exactMatch = candidates.find((candidate) => approved.some((item) => identityKey(item.login) === identityKey(candidate)));
    if (exactMatch) return exactMatch;
    // Alguns temas incluem saudacao ou cargo no mesmo elemento do nome. So
    // aceitamos uma ocorrencia delimitada que aponte para uma unica identidade
    // previamente aprovada, escolhendo o login mais especifico.
    for (const candidate of candidates) {
      const key = identityKey(candidate);
      const matches = approved.filter((item) => new RegExp(`(^|[^A-Z0-9])${identityKey(item.login).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|[^A-Z0-9])`).test(key));
      // A mesma pessoa pode estar vinculada a varias empresas; para DETECTAR
      // o login apenas a identidade importa (userId/papel/sellerId). A escolha
      // da empresa correta acontece depois em resolveIdentity.
      const identities = new Set(matches.map((item) => [item.userId, item.role, item.sellerId || ""].join("|")));
      if (identities.size === 1 && matches.length) return matches.sort((left, right) => identityKey(right.login).length - identityKey(left.login).length)[0].login;
    }
    return candidates[0] || "";
  }

  function currentCompanyScopeKey(doc = document) {
    return currentCompanyEvidence(doc)[0] || "";
  }

  function currentCompanyEvidence(doc = document) {
    const selectors = ["#formTopBar\\:empresas_input", "[data-company-scope-key]", "[data-company-id]", "select[id*='empresas']", "input[id*='empresas']"];
    const controls = [];
    for (const selector of selectors) {
      try { for (const match of doc.querySelectorAll?.(selector) || []) if (match && !controls.includes(match)) controls.push(match); } catch (_) {}
    }
    const legacy = doc.getElementById?.("formTopBar:empresas_input");
    if (legacy && !controls.includes(legacy)) controls.unshift(legacy);
    const values = controls.flatMap((control) => [control.value, control.getAttribute?.("data-company-id"), control.getAttribute?.("data-company-scope-key"), control.selectedOptions?.[0]?.textContent, control.getAttribute?.("aria-label")]).map(exact).filter(Boolean);
    return freeze([...new Set(values)]);
  }

  function companyIdFromScope(value) {
    const scope = exact(value);
    return /^\d+(?:\s*-|$)/.test(scope) ? scope.match(/^\d+/)?.[0] || null : null;
  }

  function unknown(code = "SESSION_NOT_LINKED", evidence = []) {
    return freeze({ userId: null, role: "unknown", companyId: null, companyScopeKey: null, sellerId: null, sellerName: null, sessionFingerprint: null, evidence: freeze([...evidence]), code });
  }

  function validBinding(binding) {
    if (!binding || !exact(binding.login) || !exact(binding.userId) || !exact(binding.companyScopeKey) || !ROLES.has(binding.role)) return false;
    return binding.role !== "seller" || Boolean(exact(binding.sellerId));
  }

  // This is an exact lookup into a password-protected, administrator-approved
  // binding. The visible name is evidence used to select a binding, never the
  // authorization fact itself. Approximate/name-only matching is forbidden.
  function resolveIdentity({ login, companyScopeKey, companyEvidence = [], bindings = [], sessionNonce = "" } = {}) {
    const observedLogin = exact(login);
    let observedCompanies = [...new Set([companyScopeKey, ...(Array.isArray(companyEvidence) ? companyEvidence : [])].map(exact).filter(Boolean))];
    const evidence = freeze([{ source: "DOM", selector: "#name-user", value: observedLogin }, { source: "DOM", selector: "#formTopBar:empresas_input", values: freeze(observedCompanies) }, { source: "LOCAL_APPROVED_BINDING", confirmed: true }]);
    if (!observedLogin) return unknown("SESSION_EVIDENCE_INCOMPLETE", evidence);
    // Perfis com acesso a uma unica empresa podem nao receber o seletor no
    // topo. Somente um vinculo embutido e explicitamente aprovado pode suprir
    // essa evidencia; vinculos no storage continuam fail-closed.
    if (!observedCompanies.length) {
      const approvedMatches = [...APPROVED_ADMIN_BINDINGS, ...APPROVED_SELLER_BINDINGS].filter((item) => validBinding(item) && identityKey(item.login) === identityKey(observedLogin));
      const uniqueApproved = [...new Map(approvedMatches.map((item) => [[item.userId, item.sellerId, item.companyScopeKey].join("|"), item])).values()];
      if (uniqueApproved.length === 1) observedCompanies = [uniqueApproved[0].companyScopeKey];
      else return unknown("SESSION_EVIDENCE_INCOMPLETE", evidence);
    }
    const embeddedBindings = [...APPROVED_ADMIN_BINDINGS, ...APPROVED_SELLER_BINDINGS];
    const configured = [...(Array.isArray(bindings) ? bindings : []), ...embeddedBindings];
    const unique = [...new Map(configured.map((item) => [[identityKey(item.login), item.userId, item.companyScopeKey, item.role, item.sellerId || ""].join("|"), item])).values()];
    const candidateMatches = unique.filter((item) => {
      if (!validBinding(item) || identityKey(item.login) !== identityKey(observedLogin)) return false;
      const bindingCompanyId = exact(item.companyId) || companyIdFromScope(item.companyScopeKey);
      const observedCompanyIds = observedCompanies.map(companyIdFromScope).filter(Boolean);
      return observedCompanies.includes(exact(item.companyScopeKey)) || Boolean(bindingCompanyId && (observedCompanies.includes(bindingCompanyId) || observedCompanyIds.includes(bindingCompanyId)));
    });
    // Um vínculo embutido confirmado não pode ser invalidado por cadastros
    // antigos ou duplicados deixados no storage após várias tentativas.
    const embeddedMatches = candidateMatches.filter((item) => embeddedBindings.includes(item));
    const embeddedIdentities = new Set(embeddedMatches.map((item) => [item.userId, item.companyScopeKey, item.role, item.sellerId || ""].join("|")));
    const matches = embeddedIdentities.size === 1 ? [embeddedMatches[0]] : candidateMatches;
    if (matches.length !== 1) return unknown(matches.length ? "AMBIGUOUS_BINDING" : "SESSION_NOT_LINKED", evidence);
    const binding = matches[0];
    const canonicalCompany = exact(binding.companyScopeKey);
    const fingerprint = [canonicalCompany, exact(binding.userId), binding.role, binding.role === "seller" ? exact(binding.sellerId) : "none", exact(sessionNonce || binding.sessionNonce || "approved")].map(encodeURIComponent).join("|");
    return freeze({
      userId: exact(binding.userId), role: binding.role, companyId: exact(binding.companyId) || companyIdFromScope(canonicalCompany) || canonicalCompany,
      companyScopeKey: canonicalCompany, sellerId: binding.role === "seller" ? exact(binding.sellerId) : null,
      sellerName: binding.role === "seller" ? exact(binding.sellerName || binding.login) : null,
      sessionFingerprint: fingerprint, evidence, code: "AUTHORIZED"
    });
  }

  function authorizedScope(identity, month) {
    if (!identity || identity.role === "unknown" || !exact(identity.userId) || !exact(identity.companyScopeKey) || !exact(identity.sessionFingerprint) || !monthPattern.test(exact(month))) return null;
    if (identity.role === "seller" && !exact(identity.sellerId)) return null;
    return freeze({ companyId: identity.companyScopeKey, companyScopeKey: identity.companyScopeKey, userId: identity.userId, sellerId: identity.sellerId, role: identity.role, month: exact(month), sessionFingerprint: identity.sessionFingerprint });
  }

  function scopeKey(scope) {
    if (!scope || !authorizedScope(scope, scope.month)) throw new Error("Escopo de segurança incompleto.");
    return `${SCOPED_DATA_PREFIX}company-${encodeURIComponent(scope.companyScopeKey)}:user-${encodeURIComponent(scope.userId)}:${scope.role === "seller" ? `seller-${encodeURIComponent(scope.sellerId)}:` : ""}role-${scope.role}:month-${scope.month}`;
  }

  function validateEnvelope(envelope, scope) {
    if (!envelope || envelope.schemaVersion !== 1 || envelope.scopeKey !== scopeKey(scope)) return null;
    const actual = envelope.scope || {};
    for (const field of ["companyScopeKey", "userId", "sellerId", "role", "month", "sessionFingerprint"]) if ((actual[field] ?? null) !== (scope[field] ?? null)) return null;
    return envelope.data ?? null;
  }

  function sanitizeSellerModel(identity, input = {}) {
    if (identity?.role !== "seller" || !identity.sellerId || exact(input.sellerId) !== exact(identity.sellerId)) return null;
    const recentSales = Array.isArray(input.recentSales) ? input.recentSales.slice(-10).map((sale) => ({ id: exact(sale.id), sellerId: identity.sellerId, amount: numberOrNull(sale.amount), type: exact(sale.type).slice(0, 40), document: exact(sale.document).slice(0, 80) || null, paymentMethod: exact(sale.paymentMethod).slice(0, 80) || null, itemCount: numberOrNull(sale.itemCount), items: Array.isArray(sale.items) ? sale.items.slice(0, 20).map((item) => ({ description: exact(item?.description).slice(0, 160) })).filter((item) => item.description) : [], occurredAt: exact(sale.occurredAt) })).filter((sale) => sale.id && sale.amount != null && sale.amount > 0 && sale.occurredAt) : [];
    const allowed = { userId: identity.userId, sellerId: identity.sellerId, localSellerKey: exact(input.localSellerKey) || null, sellerName: exact(input.sellerName || identity.sellerName), companyScopeKey: identity.companyScopeKey, month: exact(input.month), goal: numberOrNull(input.goal), realized: numberOrNull(input.realized), progress: numberOrNull(input.progress), remaining: numberOrNull(input.remaining), surplus: numberOrNull(input.surplus), commissionPercent: numberOrNull(input.commissionPercent), commissionEstimated: numberOrNull(input.commissionEstimated), individualHistory: Array.isArray(input.individualHistory) ? input.individualHistory.filter((point) => !point.sellerId || exact(point.sellerId) === identity.sellerId).map((point) => ({ date: exact(point.date), timestamp: Number(point.timestamp), realized: Number(point.realized), sellerId: identity.sellerId })).filter((point) => point.date && Number.isFinite(point.timestamp) && Number.isFinite(point.realized) && point.realized >= 0) : [], recentSales, capturedAt: exact(input.capturedAt) || null, syncState: exact(input.syncState) || null, syncErrorCode: exact(input.syncErrorCode) || null };
    return freeze(allowed);
  }

  function approvedLocalSellerKey(identity) {
    if (identity?.role !== "seller") return null;
    const match = APPROVED_SELLER_ASSIGNMENTS.find((item) => item.companyScopeKey === exact(identity.companyScopeKey) && item.userId === exact(identity.userId) && item.sellerId === exact(identity.sellerId));
    return match?.localSellerKey || null;
  }

  const api = freeze({ ACTIVE_SESSION_KEY, APPROVED_ADMIN_BINDINGS, APPROVED_SELLER_ASSIGNMENTS, APPROVED_SELLER_BINDINGS, BINDINGS_KEY, SCOPED_DATA_PREFIX, approvedLocalSellerKey, authorizedScope, companyIdFromScope, currentCompanyEvidence, currentCompanyScopeKey, currentSessionLogin, resolveIdentity, sanitizeSellerModel, scopeKey, unknown, validateEnvelope });
  root.AvanteSessionAccess = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
