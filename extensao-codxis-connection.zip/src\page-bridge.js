(function () {
  "use strict";
  console.log("[Avante][PageBridge] page-bridge.js carregado, window === window.top?", window === window.top, "location:", location.href);

  const config = globalThis.AVANTE_CONFIG;
  if (!config || globalThis.__AVANTE_PAGE_BRIDGE_LISTENER__) return;
  globalThis.__AVANTE_PAGE_BRIDGE_LISTENER__ = true;
  const REPORT_MAPPING_KEY = "avante.goals.report-request-template.v1";
  const REPORT_PATH = "/sistema/pages/privado/relatoriosGerenciais/resumoGeral";
  const ORDER_SUMMARY_PATH = "/sistema/pages/privado/faturamento/relatorios/resumoVendas";
  const REPORT_LABEL = /Vendas por Vendedores\/Colaboradores - Comiss/i;
  const VIEW_STATE_NAMES = ["jakarta.faces.ViewState", "javax.faces.ViewState"];
  const viewStateSelector = VIEW_STATE_NAMES.map((name) => `input[name="${name}"]`).join(",");
  const extractUpdatedViewState = (text) => {
    for (const name of VIEW_STATE_NAMES) {
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const match = String(text || "").match(new RegExp(`<update\\b[^>]*\\bid=["']${escaped}["'][^>]*>\\s*(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?\\s*</update>`, "i"));
      if (match?.[1]) return { name, value: match[1].trim() };
    }
    return null;
  };
  const restoreSellerReportRequest = () => { try { const saved = JSON.parse(sessionStorage.getItem(REPORT_MAPPING_KEY) || "null"); const sameOrigin = String(saved?.url || "").startsWith("/") || new URL(saved?.url || "", location.href).origin === location.origin; return sameOrigin && saved?.method === "POST" && typeof saved?.body === "string" ? saved : null; } catch (_) { return null; } };
  const rememberSellerReportRequest = (request, requestBody) => { try { if (!request?.url || typeof requestBody !== "string" || !requestBody) return; const rawUrl = String(request.url); const url = rawUrl.startsWith("/") ? rawUrl : new URL(rawUrl, location.href); if (!rawUrl.startsWith("/") && url.origin !== location.origin) return; const fields = new URLSearchParams(requestBody); const detectedName = VIEW_STATE_NAMES.find((name) => fields.has(name)); if (detectedName) latestSellerViewStateName = detectedName; for (const name of VIEW_STATE_NAMES) fields.delete(name); const safe = { url: rawUrl.startsWith("/") ? rawUrl : url.href, method: "POST", body: fields.toString(), viewStateName: latestSellerViewStateName }; lastSellerReportRequest = safe; try { sessionStorage.setItem(REPORT_MAPPING_KEY, JSON.stringify(safe)); } catch (_) {} } catch (_) {} };
  let lastSellerReportRequest = restoreSellerReportRequest();
  let latestSellerViewState = "";
  let latestSellerViewStateName = VIEW_STATE_NAMES.includes(lastSellerReportRequest?.viewStateName) ? lastSellerReportRequest.viewStateName : "jakarta.faces.ViewState";
  let pendingSale = null;
  let authorizedAdministrator = false;
  let bridgeInstalled = false;
  const endpointPath = (url) => { try { return new URL(String(url || ""), location.href).pathname; } catch (_) { return String(url || "").split("?")[0]; } };
  const diagnose = (stage, detail = {}) => { if (authorizedAdministrator) window.dispatchEvent(new CustomEvent("avante:seller-report-diagnostic", { detail: JSON.stringify({ stage, at: new Date().toISOString(), source: "CODXIS_SELLER_REPORT", updateId: globalThis.AvanteSellerReport.UPDATE_ID, ...detail }) })); };

  const isCandidate = (url) =>
    String(url || "").includes("/relatoriosGerenciais/resumoGeral") || config.api.urlIncludes.some((part) =>
      String(url || "").toLowerCase().includes(part.toLowerCase())
    );

  const isSellerReportUrl = (url) => String(url || "").includes("/relatoriosGerenciais/resumoGeral");
  const isOrderSummaryUrl = (url) => String(url || "").includes("/faturamento/relatorios/resumoVendas");
  const hasSellerReportUpdate = (text) => /<update\b[^>]*\bid=["'][^"']*painelGeralRelatorios[^"']*["']/i.test(String(text || "")) || /datatableVendasVendedores|Valor Documento/i.test(String(text || ""));
  const hasOrderSummaryUpdate = (text) => /<update\b[^>]*\bid=["'][^"']*panelGrafico[^"']*["']/i.test(String(text || "")) && /datatablePedidoVendaFinalizados/i.test(String(text || ""));
  const collectRawUpdateIds = (text) => {
    const ids = []; let match;
    const pattern = /<update\b[^>]*\bid=(?:"([^"]*)"|'([^']*)')[^>]*>/gi;
    while ((match = pattern.exec(String(text || "")))) ids.push(match[1] || match[2] || "");
    return ids;
  };
  const redactSellerReportMarkup = (text) => String(text || "")
    .replace(/\b(value|title|aria-label|data-(?!widget)[\w:-]+)=("[^"]*"|'[^']*')/gi, '$1="[REDACTED]"')
    .replace(/(^|>)([^<]*\S[^<]*)(?=<|$)/g, (whole, prefix) => `${prefix}[REDACTED_TEXT]`);
  const sanitizeSellerReportXml = (text) => String(text || "")
    .replace(/(<update\b[^>]*\bid=["'](?:jakarta|javax)\.faces\.ViewState["'][^>]*>)[\s\S]*?(<\/update>)/gi, "$1[REDACTED_VIEW_STATE]$2")
    .replace(/(<update\b[^>]*>)(?!\s*<!\[CDATA\[)([\s\S]*?)(<\/update>)/gi, (whole, opening, content, closing) => `${opening}${redactSellerReportMarkup(content)}${closing}`)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (whole, content) => `<![CDATA[${redactSellerReportMarkup(content)}]]>`)
    .replace(/\b(value|title|aria-label|data-(?!widget)[\w:-]+)=("[^"]*"|'[^']*')/gi, '$1="[REDACTED]"');
  const debugSellerReportResponse = (stage, text, detail = {}) => {
    if (window.__AVANTE_DEBUG__ !== true) return;
    if (!/<partial-response[\s>]/i.test(String(text || ""))) return;
    const updateIds = collectRawUpdateIds(text);
    const sanitizedXml = sanitizeSellerReportXml(text);
    window.__lastSellerReportRawXML = sanitizedXml;
    console.debug("[Avante][SellerReport] Resposta JSF", { stage, updateIds, sanitizedXml, ...detail });
  };
  const isSameOrigin = (url) => {
    try { return new URL(String(url || ""), location.href).origin === location.origin; }
    catch (_) { return false; }
  };
  const publishSalesActivity = (url, transport) => {
    if (!authorizedAdministrator) return;
    if (!isCandidate(url) || isSellerReportUrl(url)) return;
    window.dispatchEvent(new CustomEvent("avante:sales-activity", { detail: JSON.stringify({ source: "confirmed-response", endpoint: endpointPath(url), transport, observedAt: Date.now() }) }));
  };

  const readSaleDraft = (type) => {
    const amountText = document.getElementById("formNFCe:totalVenda")?.textContent || "";
    const normalizedAmount = amountText.replace(/[^\d,.-]/g, "").replace(/\./g, "").replace(",", ".");
    const collaborator = document.getElementById("formNFCe:colaborador");
    const sellerInput = document.getElementById("formNFCe:colaborador_input") || collaborator?.querySelector?.("input,select");
    const sellerName = collaborator?.querySelector?.(".ui-selectonemenu-label")?.textContent || sellerInput?.selectedOptions?.[0]?.textContent || sellerInput?.getAttribute?.("aria-label") || collaborator?.textContent || "";
    const companyScopeKey = String(document.getElementById("formTopBar:empresas_input")?.value || "").trim();
    const itemRows = document.querySelectorAll('#formNFCe\\:itens_data tr:not(.ui-datatable-empty-message), #formNFCe\\:datatableItens_data tr:not(.ui-datatable-empty-message), [id^="formNFCe:"][id$="_data"] tr:not(.ui-datatable-empty-message)');
    const items = [...itemRows].map((row, index) => {
      const cells = [...row.querySelectorAll("td")].map((cell) => String(cell.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean);
      return { line: index + 1, description: cells[0] || `Item ${index + 1}`, cells };
    });
    const documentNumber = document.querySelector('#formNFCe\\:numeroDocumento, #formNFCe\\:numeroNfce, [id^="formNFCe:"][id*="numero"][value]')?.value || null;
    const payment = document.querySelector('#formNFCe\\:formaPagamento_input, #formNFCe\\:formaPagamento_label, [id^="formNFCe:"][id*="formaPagamento"]')?.value || document.querySelector('#formNFCe\\:formaPagamento_label')?.textContent || null;
    return { id: globalThis.crypto?.randomUUID?.() || `sale-${Date.now()}-${Math.random().toString(16).slice(2)}`, companyScopeKey, sellerId: sellerInput?.value || null, sellerName: String(sellerName).replace(/\s+/g, " ").trim(), amount: Number(normalizedAmount), type, document: documentNumber ? String(documentNumber).trim() : null, paymentMethod: payment ? String(payment).replace(/\s+/g, " ").trim() : null, itemCount: items.length || null, items, occurredAt: new Date().toISOString(), pageUrl: location.pathname };
  };

  document.addEventListener("click", (event) => {
    const pv = event.target.closest?.("#formNFCe\\:btn-finalizar-pv");
    const nfce = event.target.closest?.("#formNFCe\\:btn-finalizar-nfce");
    if (pv || nfce) pendingSale = readSaleDraft(pv ? "PV" : "NFCe");
  }, true);

  const publish = (url, payload) => {
    if (!isCandidate(url) || !payload || typeof payload !== "object") return;
    window.dispatchEvent(
      new CustomEvent("avante:data-response", {
        detail: JSON.stringify({
          url: String(url),
          payload,
          capturedAt: new Date().toISOString()
        })
      })
    );
  };

  const publishSellerReport = (xml, requestBody = "", request = null) => {
    if (!authorizedAdministrator) return;
    debugSellerReportResponse("publishSellerReport", xml, { endpoint: request?.url ? endpointPath(request.url) : REPORT_PATH });
    const updatedViewState = extractUpdatedViewState(xml);
    if (updatedViewState) { latestSellerViewState = updatedViewState.value; latestSellerViewStateName = updatedViewState.name; }
    rememberSellerReportRequest(request, requestBody);
    const fields = new URLSearchParams(typeof requestBody === "string" ? requestBody : "");
    diagnose("parsing");
    let report;
    try {
      report = globalThis.AvanteSellerReport.parseSellerReport(xml, { start: fields.get("form:diaInicial_input") || "", end: fields.get("form:diaFinal_input") || "", capturedAt: new Date().toISOString() });
    } catch (error) {
      if (window.__AVANTE_DEBUG__ === true) console.debug("[Avante][SellerReport] Falha no parser", error?.diagnostic || error);
      throw error;
    }
    const parserDiagnostic = report.parserDiagnostic || {};
    try { sessionStorage.setItem("avante.goals.last-seller-report-parser-diagnostic.v1", JSON.stringify(parserDiagnostic)); } catch (_) {}
    diagnose("response-received", { endpoint: request?.url ? endpointPath(request.url) : "/relatoriosGerenciais/resumoGeral", updateIds: parserDiagnostic.updateIds || [], chosenUpdateId: parserDiagnostic.chosenUpdateId || null, hasCdata: parserDiagnostic.hasCdata === true });
    diagnose("parsed", { sellerCount: report.sellers.length, updateIds: parserDiagnostic.updateIds || [], chosenUpdateId: parserDiagnostic.chosenUpdateId || null, tableCount: parserDiagnostic.tableCount || 0, tbodyCount: parserDiagnostic.tbodyCount || 0, rowCount: parserDiagnostic.rowCount || 0, dataRowCount: parserDiagnostic.dataRowCount || 0, cellCount: parserDiagnostic.cellCount || 0, columns: parserDiagnostic.columns || [], totalRealized: report.totalRealized });
    const companyScopeKey = document.getElementById("formTopBar:empresas_input")?.value || "";
    window.dispatchEvent(new CustomEvent("avante:seller-report", { detail: JSON.stringify({ ...report, companyScopeKey }) }));
  };
  const publishOrderSummary = (xml, requestBody = "", request = null) => {
    debugSellerReportResponse("publishOrderSummary", xml, { endpoint: request?.url ? endpointPath(request.url) : ORDER_SUMMARY_PATH });
    const updatedViewState = extractUpdatedViewState(xml);
    if (updatedViewState) { latestSellerViewState = updatedViewState.value; latestSellerViewStateName = updatedViewState.name; }
    const fields = new URLSearchParams(typeof requestBody === "string" ? requestBody : "");
    diagnose("parsing", { source: "CODXIS_ORDER_SUMMARY" });
    const report = globalThis.AvanteSellerReport.parseOrderSummary(xml, { start: fields.get("form:tabView:diaInicial_input") || "", end: fields.get("form:tabView:diaFinal_input") || "", capturedAt: new Date().toISOString() });
    const diagnostic = report.parserDiagnostic || {};
    diagnose("response-received", { source: report.source, endpoint: ORDER_SUMMARY_PATH, updateIds: diagnostic.updateIds || [], chosenUpdateId: diagnostic.chosenUpdateId || null });
    diagnose("parsed", { source: report.source, sellerCount: report.sellers.length, rowCount: diagnostic.rowCount || 0, expectedRowCount: diagnostic.expectedRowCount ?? null, totalRealized: report.totalRealized });
    const companyScopeKey = document.getElementById("formTopBar:empresas_input")?.value || "";
    window.dispatchEvent(new CustomEvent("avante:seller-report", { detail: JSON.stringify({ ...report, companyScopeKey }) }));
  };
  const publishSellerReportError = (error) => { const message = String(error?.message || "Resposta JSF inválida."); const code = error?.code || (/sem o update|painelGeralRelatorios/i.test(message) ? "REPORT_PANEL_NOT_FOUND" : /ViewState|sessão do relatório/i.test(message) ? "REPORT_VIEWSTATE_UNAVAILABLE" : "REPORT_REQUEST_FAILED"); diagnose("error", { code, message: message.slice(0, 180) }); window.dispatchEvent(new CustomEvent("avante:seller-report-status", { detail: JSON.stringify({ ok: false, code, message: code === "REPORT_PAGE_NOT_INITIALIZED" ? "O formulário do relatório de comissão não pôde ser inicializado." : code === "REPORT_PANEL_NOT_FOUND" ? "A resposta foi recebida, mas o painel do relatório não foi encontrado." : code === "REPORT_VIEWSTATE_UNAVAILABLE" ? "Não foi possível obter o ViewState atual do relatório." : "Não foi possível executar a consulta do relatório de comissão." }) })); };

  const activate = () => {
    authorizedAdministrator = true;
    if (bridgeInstalled) return;
    bridgeInstalled = true;
    if (globalThis.__AVANTE_PAGE_BRIDGE__) return;
    globalThis.__AVANTE_PAGE_BRIDGE__ = true;

    const nativeFetch = window.fetch;
    const reportUrl = () => new URL(REPORT_PATH, location.origin).href;
    const readSuccessfulControls = (form) => {
      const fields = new URLSearchParams();
      for (const control of form?.elements || []) {
        if (!control.name || control.disabled || ["button", "submit", "reset", "file"].includes(String(control.type).toLowerCase())) continue;
        if (["checkbox", "radio"].includes(String(control.type).toLowerCase()) && !control.checked) continue;
        if (control.tagName === "SELECT" && control.multiple) {
          for (const option of control.selectedOptions) fields.append(control.name, option.value);
        } else fields.append(control.name, control.value || "");
      }
      return fields;
    };
    const findReportSource = (doc, form) => {
      const controls = [...(form?.querySelectorAll("button,input[type=submit],input[type=button],a") || [])];
      const button = controls.find((element) => /consultar|pesquisar|gerar|visualizar/i.test(element.textContent || element.value || element.title || ""));
      if (!button) return "";
      const script = `${button.getAttribute("onclick") || ""} ${button.getAttribute("href") || ""}`;
      return button.name || button.id || script.match(/(?:source|s)\s*:\s*['\"]([^'\"]+)/i)?.[1] || "";
    };
    const requestOrderSummary = async () => {
      const url = new URL(ORDER_SUMMARY_PATH, location.origin).href;
      const period = globalThis.AvanteSellerReport.currentMonthPeriod();
      diagnose("requesting", { source: "CODXIS_ORDER_SUMMARY", mode: "initialize-order-summary", endpoint: ORDER_SUMMARY_PATH });
      const pageResponse = await nativeFetch(url, { method: "GET", credentials: "same-origin", headers: { Accept: "text/html,application/xhtml+xml" } });
      if (!pageResponse.ok) throw Object.assign(new Error(`A página de resumo de vendas retornou HTTP ${pageResponse.status}.`), { code: "ORDER_SUMMARY_REQUEST_FAILED" });
      const html = await pageResponse.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const start = doc.getElementById("form:tabView:diaInicial_input") || doc.querySelector('[name="form:tabView:diaInicial_input"]');
      const end = doc.getElementById("form:tabView:diaFinal_input") || doc.querySelector('[name="form:tabView:diaFinal_input"]');
      const form = start?.closest("form") || doc.getElementById("form") || doc.querySelector("form");
      if (!start || !end || !form) throw Object.assign(new Error("O formulário do resumo de pedidos não foi encontrado."), { code: "ORDER_SUMMARY_PAGE_NOT_INITIALIZED" });
      const source = findReportSource(doc, form) || (doc.getElementById("form:tabView:j_idt2188") ? "form:tabView:j_idt2188" : "");
      if (!source) throw Object.assign(new Error("O botão de consulta do resumo de pedidos não foi identificado."), { code: "ORDER_SUMMARY_PAGE_NOT_INITIALIZED" });
      const fields = readSuccessfulControls(form);
      const viewStateName = VIEW_STATE_NAMES.find((name) => fields.has(name));
      if (!viewStateName || !fields.get(viewStateName)) throw Object.assign(new Error("O ViewState do resumo de pedidos não foi encontrado."), { code: "REPORT_VIEWSTATE_UNAVAILABLE" });
      fields.set("jakarta.faces.partial.ajax", "true"); fields.set("jakarta.faces.source", source); fields.set("jakarta.faces.partial.execute", "@all");
      fields.set("jakarta.faces.partial.render", "growl form:grafico form:datatablePedidoVendaFinalizados form:datatablePedidoVendaAberto form:panelGrafico");
      fields.set(source, source); fields.set("form", form.id || form.name || "form"); fields.set("form:tabView:diaInicial_input", period.start.split(" ")[0]); fields.set("form:tabView:diaFinal_input", period.end.split(" ")[0]);
      const body = fields.toString();
      diagnose("requesting", { source: "CODXIS_ORDER_SUMMARY", mode: "monthly-order-summary", endpoint: ORDER_SUMMARY_PATH });
      const response = await nativeFetch(url, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "Faces-Request": "partial/ajax", "X-Requested-With": "XMLHttpRequest" }, body });
      if (!response.ok) throw Object.assign(new Error(`A consulta do resumo de vendas retornou HTTP ${response.status}.`), { code: "ORDER_SUMMARY_REQUEST_FAILED" });
      const xml = await response.text(); publishOrderSummary(xml, body, { url, method: "POST" });
    };
    const initializeSellerReportRequest = async () => {
      const url = reportUrl();
      diagnose("requesting", { mode: "initialize-report-page", endpoint: REPORT_PATH });
      const response = await nativeFetch(url, { method: "GET", credentials: "same-origin", headers: { Accept: "text/html,application/xhtml+xml" } });
      if (!response.ok) throw Object.assign(new Error(`A página do relatório retornou HTTP ${response.status}.`), { code: "REPORT_REQUEST_FAILED" });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const type = doc.getElementById("form:tipo_input") || doc.querySelector('[name="form:tipo_input"]');
      const form = type?.closest("form") || doc.getElementById("form") || doc.querySelector("form");
      if (!type || !form) throw Object.assign(new Error("O formulário do relatório de comissão não foi encontrado."), { code: "REPORT_PAGE_NOT_INITIALIZED" });
      if (type.tagName === "SELECT") {
        const option = [...type.options].find((item) => REPORT_LABEL.test(item.textContent || item.value || ""));
        if (!option) throw Object.assign(new Error("O tipo de relatório de comissão não está disponível."), { code: "REPORT_PAGE_NOT_INITIALIZED" });
        type.value = option.value;
      } else {
        const option = [...doc.querySelectorAll('[id^="form:tipo"] option')].find((item) => REPORT_LABEL.test(item.textContent || item.value || ""));
        type.value = option?.value || "Vendas por Vendedores/Colaboradores - Comissão";
      }
      const source = findReportSource(doc, form);
      if (!source) throw Object.assign(new Error("O botão de consulta do relatório não foi identificado."), { code: "REPORT_PAGE_NOT_INITIALIZED" });
      const fields = readSuccessfulControls(form);
      const viewStateName = VIEW_STATE_NAMES.find((name) => fields.has(name));
      const viewState = viewStateName ? fields.get(viewStateName) : "";
      if (!viewState) throw Object.assign(new Error("O ViewState atual do relatório não foi encontrado."), { code: "REPORT_VIEWSTATE_UNAVAILABLE" });
      for (const name of VIEW_STATE_NAMES) fields.delete(name);
      fields.set("jakarta.faces.partial.ajax", "true");
      fields.set("jakarta.faces.source", source);
      fields.set("jakarta.faces.partial.execute", "@all");
      fields.set("form", form.id || form.name || "form");
      fields.set("form:tipo_input", type.value);
      const safe = { url, method: "POST", body: fields.toString(), viewStateName };
      lastSellerReportRequest = safe;
      latestSellerViewState = viewState;
      latestSellerViewStateName = viewStateName;
      try { sessionStorage.setItem(REPORT_MAPPING_KEY, JSON.stringify(safe)); } catch (_) {}
      diagnose("initialized", { endpoint: REPORT_PATH, sourceFound: true });
      return safe;
    };
    const resolveFreshViewState = async (url) => {
      const liveInput = document.querySelector(viewStateSelector);
      const live = liveInput?.value || latestSellerViewState;
      if (live) return { name: liveInput?.name || latestSellerViewStateName, value: live };
      diagnose("requesting", { mode: "fresh-context", endpoint: endpointPath(url) });
      const response = await nativeFetch(url, { method: "GET", credentials: "same-origin", headers: { Accept: "text/html,application/xhtml+xml" } });
      if (!response.ok) throw new Error(`Não foi possível abrir o relatório: HTTP ${response.status}.`);
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const documentInput = doc.querySelector(viewStateSelector);
      const updated = extractUpdatedViewState(html);
      const fresh = documentInput?.value || updated?.value || "";
      if (!fresh) throw Object.assign(new Error("A sessão do relatório precisa ser confirmada novamente no Codxis."), { code: "REPORT_VIEWSTATE_UNAVAILABLE" });
      latestSellerViewState = fresh;
      latestSellerViewStateName = documentInput?.name || updated?.name || latestSellerViewStateName;
      return { name: latestSellerViewStateName, value: fresh };
    };
    if (nativeFetch) {
      window.fetch = async function (...args) {
        const response = await nativeFetch.apply(this, args);
        const url = response.url || args[0]?.url || args[0];
        const method = String(args[1]?.method || args[0]?.method || "GET").toUpperCase();
        if (isSellerReportUrl(url) || isOrderSummaryUrl(url) || (method === "POST" && isSameOrigin(url))) {
          response.clone().text().then((text) => {
            const hasReportUpdate = hasSellerReportUpdate(text);
            const hasOrderUpdate = hasOrderSummaryUpdate(text);
            debugSellerReportResponse("hasSellerReportUpdate:fetch", text, { matched: hasReportUpdate, endpoint: endpointPath(url) });
            if (hasOrderUpdate) publishOrderSummary(text, args[1]?.body, { url, method });
            else if (isSellerReportUrl(url) || hasReportUpdate) publishSellerReport(text, args[1]?.body, { url, method });
          }).catch((error) => { if (isSellerReportUrl(url) || isOrderSummaryUrl(url)) publishSellerReportError(error); });
        }
        if (isCandidate(url)) {
          if (response.ok) publishSalesActivity(url, "fetch");
          response
            .clone()
            .json()
            .then((json) => publish(url, json))
            .catch(() => {});
        }
        return response;
      };
      console.log("[Avante][PageBridge] window.fetch sobrescrito, window === window.top?", window === window.top, "location:", location.href);
    }

    const nativeOpen = XMLHttpRequest.prototype.open;
    const nativeSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this.__avanteUrl = url; this.__avanteMethod = method;
      return nativeOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function (...args) {
      const requestBody = typeof args[0] === "string" ? args[0] : "";
      const shouldInspectJsResponse = String(this.__avanteMethod || "GET").toUpperCase() === "POST" && isSameOrigin(this.__avanteUrl);
      if (isCandidate(this.__avanteUrl) || shouldInspectJsResponse) {
        const requestFields = new URLSearchParams(requestBody);
        const requestSource = requestFields.get("jakarta.faces.source") || requestFields.get("javax.faces.source") || "";
        const finalizesSale = /formNFCe:btn-finalizar-(?:pv|nfce)/i.test(requestSource);
        this.addEventListener(
          "load",
          () => {
            try {
              const responseUrl = this.responseURL || this.__avanteUrl;
              if (finalizesSale && this.status >= 200 && this.status < 400 && pendingSale) {
                const hasExplicitError = /ui-messages-error|ui-growl-error|severity-error/i.test(this.responseText || "");
                if (!hasExplicitError) window.dispatchEvent(new CustomEvent("avante:sale-completed", { detail: JSON.stringify({ ...pendingSale, confirmedAt: new Date().toISOString(), endpoint: endpointPath(responseUrl) }) }));
                pendingSale = null;
              }
              const hasReportUpdate = hasSellerReportUpdate(this.responseText);
              const hasOrderUpdate = hasOrderSummaryUpdate(this.responseText);
              debugSellerReportResponse("hasSellerReportUpdate:xhr", this.responseText, { matched: hasReportUpdate, endpoint: endpointPath(responseUrl) });
              if (/<partial-response[\s>]/i.test(this.responseText || "") && (isSellerReportUrl(responseUrl) || hasReportUpdate || hasOrderUpdate)) {
                if (hasOrderUpdate) publishOrderSummary(this.responseText, requestBody, { url: this.responseURL || this.__avanteUrl, method: this.__avanteMethod || "POST" });
                else publishSellerReport(this.responseText, requestBody, { url: this.responseURL || this.__avanteUrl, method: this.__avanteMethod || "POST" });
                return;
              }
              if (this.status >= 200 && this.status < 400) publishSalesActivity(responseUrl, "xhr");
              const json =
                this.responseType === "json"
                  ? this.response
                  : JSON.parse(this.responseText);
              publish(this.responseURL || this.__avanteUrl, json);
            } catch (_) {}
          },
          { once: true }
        );
      }
      return nativeSend.apply(this, args);
    };

    window.addEventListener("avante:request-seller-report", async () => {
      try { await requestOrderSummary(); return; }
      catch (orderError) { diagnose("fallback", { source: "CODXIS_ORDER_SUMMARY", code: orderError?.code || "ORDER_SUMMARY_REQUEST_FAILED" }); }
      const period = globalThis.AvanteSellerReport.currentMonthPeriod();
      const start = document.getElementById("form:diaInicial_input");
      const end = document.getElementById("form:diaFinal_input");
      const reportType = document.getElementById("form:tipo_input");
      if (start && end && reportType && /Vendas por Vendedores\/Colaboradores - Comiss/i.test(reportType.value || "")) {
        start.value = period.start; end.value = period.end; start.dispatchEvent(new Event("change", { bubbles: true })); end.dispatchEvent(new Event("change", { bubbles: true }));
        const form = start.closest("form"); const button = [...(form?.querySelectorAll("button,input[type=submit]") || [])].find((element) => /consultar|pesquisar|gerar|visualizar/i.test(element.textContent || element.value || ""));
        if (button) { diagnose("requesting", { mode: "live-form" }); button.click(); window.dispatchEvent(new CustomEvent("avante:seller-report-status", { detail: JSON.stringify({ ok: true, stage: "waiting-report", message: "Consulta mensal solicitada pelo formulário atual." }) })); return; }
      }
      try {
        if (!lastSellerReportRequest) await initializeSellerReportRequest();
        diagnose("requesting", { mode: "captured-request", endpoint: endpointPath(lastSellerReportRequest.url) });
        const fields = new URLSearchParams(lastSellerReportRequest.body); fields.set("form:diaInicial_input", period.start); fields.set("form:diaFinal_input", period.end);
        const liveViewState = await resolveFreshViewState(lastSellerReportRequest.url); for (const name of VIEW_STATE_NAMES) fields.delete(name); fields.set(liveViewState.name, liveViewState.value);
        window.dispatchEvent(new CustomEvent("avante:seller-report-status", { detail: JSON.stringify({ ok: true, stage: "waiting-report", message: "Consulta mensal enviada com a sessão autenticada atual." }) }));
        const response = await nativeFetch(lastSellerReportRequest.url, { method: lastSellerReportRequest.method, credentials: "same-origin", headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "Faces-Request": "partial/ajax", "X-Requested-With": "XMLHttpRequest" }, body: fields.toString() });
        if (!response.ok) throw new Error(`Consulta retornou HTTP ${response.status}.`); const xml = await response.text(); publishSellerReport(xml, fields.toString(), { url: lastSellerReportRequest.url, method: lastSellerReportRequest.method });
      } catch (error) { publishSellerReportError(error); }
    });

    // Avisa o content script sobre navegações internas da SPA.
    const notifyRoute = (kind) =>
      window.dispatchEvent(
        new CustomEvent("avante:route-change", {
          detail: JSON.stringify({ kind, url: location.href, at: Date.now() })
        })
      );
    for (const method of ["pushState", "replaceState"]) {
      const nativeMethod = history[method];
      history[method] = function (...args) {
        const result = nativeMethod.apply(this, args);
        notifyRoute(method);
        return result;
      };
    }
    window.addEventListener("popstate", () => notifyRoute("popstate"));
    window.addEventListener("hashchange", () => notifyRoute("hashchange"));
  };

  window.addEventListener("avante:activate-bridge", activate);
  window.addEventListener("avante:deactivate-bridge", () => { authorizedAdministrator = false; pendingSale = null; lastSellerReportRequest = null; latestSellerViewState = ""; });
})();
