"use strict";

const { createUnknownIdentity, optionalString } = require("./contracts");

function normalizeProfile(raw = {}) {
  return Object.freeze({
    profileId: optionalString(raw.profileId ?? raw.id),
    profileCode: optionalString(raw.profileCode ?? raw.code),
    profileName: optionalString(raw.profileName ?? raw.name),
    permissions: Object.freeze(
      Array.isArray(raw.permissions)
        ? [...new Set(raw.permissions.map(optionalString).filter(Boolean))]
        : []
    )
  });
}

function normalizeIdentity(raw = {}) {
  const profile = normalizeProfile(raw.profile || raw);
  return createUnknownIdentity({
    userId: raw.userId,
    userName: raw.userName,
    rawProfileId: profile.profileId,
    rawProfileName: profile.profileName,
    companyId: raw.companyId,
    branchId: raw.branchId,
    sellerId: raw.sellerId,
    sellerName: raw.sellerName,
    sessionFingerprint: raw.sessionFingerprint,
    evidence: raw.evidence || []
  });
}

module.exports = { normalizeIdentity, normalizeProfile };

