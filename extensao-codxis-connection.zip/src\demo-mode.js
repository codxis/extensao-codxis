(function (root) {
  "use strict";
  const monthNow = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  function createProvider(state) {
    const data = root.AvanteDemoData;
    const profile = data.validProfile(state.profile);
    const selected = data.SELLERS.find((seller) => seller.sellerId === profile.sellerId) || null;
    const identity = Object.freeze({ userId: profile.role === "administrator" ? "demo-admin" : `demo-user-${selected.sellerId}`, userName: profile.role === "administrator" ? "Administrador" : selected.sellerName, role: profile.role, companyId: data.COMPANY.companyId, branchId: data.COMPANY.branchId, sellerId: selected?.sellerId || null, sellerName: selected?.sellerName || null, sessionFingerprint: `demo-${profile.role}-${selected?.sellerId || "admin"}` });
    const deny = (message) => { throw new root.AvanteCodxisIntegration.CodxisMappingError(message); };
    return Object.freeze({
      mode: "demo", state, company: data.COMPANY,
      async getCurrentIdentity() { return identity; },
      async getSellerList() { return profile.role === "administrator" ? data.SELLERS : []; },
      async getCompanyMonthlySales() { if (profile.role !== "administrator") deny("O modo vendedor não carrega dados da empresa."); return { companyId: data.COMPANY.companyId, branchId: data.COMPANY.branchId, month: monthNow(), sales: data.COMPANY_SALES, capturedAt: new Date().toISOString(), source: "DEMO" }; },
      async getSellerMonthlySales(sellerId) { if (profile.role === "seller" && sellerId !== identity.sellerId) deny("O vendedor demo só pode consultar o próprio sellerId."); const seller = data.SELLERS.find((item) => item.sellerId === sellerId); return { sellerId, companyId: data.COMPANY.companyId, branchId: data.COMPANY.branchId, month: monthNow(), sales: seller?.sales ?? null, capturedAt: new Date().toISOString(), source: "DEMO" }; },
      demoHistory: state.history
    });
  }
  const api = Object.freeze({ createProvider });
  root.AvanteDemoMode = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
