(function (root) {
  "use strict";
  const STORAGE_KEY = "avante.localSellerGoals";
  const SCHEMA_VERSION = 6;
  const clean = (value, label) => { const text = String(value || "").trim(); if (!text) throw new TypeError(`${label} é obrigatório.`); return text; };
  const recordKey = ({ companyScopeKey, month, localSellerKey }) => `${clean(companyScopeKey, "companyScopeKey")}:${clean(month, "month")}:${clean(localSellerKey, "localSellerKey")}`;
  class LocalSellerGoalRepository {
    constructor(storage, now = () => new Date().toISOString()) { this.storage = storage; this.now = now; }
    async load() {
      const values = await this.storage.get([STORAGE_KEY]);
      const stored = values[STORAGE_KEY];
      if (!stored || typeof stored !== "object") return { schemaVersion: SCHEMA_VERSION, companyGoals: {}, sellerGoals: {}, knownSellers: {}, sellerLinks: {}, reportHistory: {}, context: null };
      return { schemaVersion: SCHEMA_VERSION, companyGoals: structuredClone(stored.companyGoals || {}), sellerGoals: structuredClone(stored.sellerGoals || {}), knownSellers: structuredClone(stored.knownSellers || {}), sellerLinks: structuredClone(stored.sellerLinks || {}), reportHistory: structuredClone(stored.reportHistory || {}), context: structuredClone(stored.context || null) };
    }
    async list(scope) { const state = await this.load(); return Object.values(state.sellerGoals).filter((goal) => goal.companyScopeKey === scope.companyScopeKey && goal.month === scope.month); }
    async set(scope, seller, amount, commissionPercent = 0) { if (seller?.goalEligible === false) throw new TypeError("Nome duplicado: meta bloqueada até diferenciação segura."); if (!(amount > 0)) throw new TypeError("A meta deve ser maior que zero."); const rate = Number(commissionPercent); if (!Number.isFinite(rate) || rate < 0 || rate > 100) throw new TypeError("A comissão deve estar entre 0% e 100%."); const state = await this.load(); const record = { companyScopeKey: clean(scope.companyScopeKey, "companyScopeKey"), month: clean(scope.month, "month"), localSellerKey: clean(seller.localSellerKey, "localSellerKey"), sellerName: clean(seller.sellerName, "sellerName"), amount, commissionPercent: rate, updatedAt: this.now() }; state.sellerGoals[recordKey(record)] = record; await this.storage.set({ [STORAGE_KEY]: state }); return record; }
    async remove(scope) { const state = await this.load(); delete state.sellerGoals[recordKey(scope)]; await this.storage.set({ [STORAGE_KEY]: state }); }
    async rememberSellers(companyScopeKey, sellers, source = "report") {
      const state = await this.load();
      const company = clean(companyScopeKey, "companyScopeKey");
      for (const seller of sellers || []) {
        if (!seller?.localSellerKey || !seller?.sellerName) continue;
        const key = `${company}:${seller.localSellerKey}`;
        const previous = state.knownSellers[key];
        state.knownSellers[key] = { companyScopeKey: company, localSellerKey: clean(seller.localSellerKey, "localSellerKey"), sellerName: clean(seller.sellerName, "sellerName"), source: previous?.source === "local" ? "local" : source, firstSeenAt: previous?.firstSeenAt || this.now(), updatedAt: this.now() };
      }
      await this.storage.set({ [STORAGE_KEY]: state });
      return this.listKnown(company);
    }
    async listKnown(companyScopeKey) {
      const state = await this.load();
      const company = clean(companyScopeKey, "companyScopeKey");
      const byKey = new Map(Object.values(state.knownSellers).filter((seller) => seller.companyScopeKey === company).map((seller) => [seller.localSellerKey, seller]));
      for (const goal of Object.values(state.sellerGoals)) if (goal.companyScopeKey === company && !byKey.has(goal.localSellerKey)) byKey.set(goal.localSellerKey, { companyScopeKey: company, localSellerKey: goal.localSellerKey, sellerName: goal.sellerName, source: "goal", firstSeenAt: goal.updatedAt, updatedAt: goal.updatedAt });
      return [...byKey.values()].sort((a, b) => a.sellerName.localeCompare(b.sellerName, "pt-BR"));
    }
    async setSellerLink(companyScopeKey, link) { const state = await this.load(); const company = clean(companyScopeKey, "companyScopeKey"); const reportSellerKey = clean(link.reportSellerKey, "reportSellerKey"); const duplicate = Object.values(state.sellerLinks).find((item) => item.companyScopeKey === company && item.reportSellerKey === reportSellerKey && item.localSellerKey !== link.localSellerKey); if (duplicate && link.allowDuplicate !== true) { const error = new Error("Esse vendedor do relatório já está vinculado a outra meta local."); error.code = "REPORT_SELLER_ALREADY_LINKED"; throw error; } const record = { companyScopeKey: company, localSellerKey: clean(link.localSellerKey, "localSellerKey"), localName: clean(link.localName, "localName"), goal: Number.isFinite(Number(link.goal)) ? Number(link.goal) : null, reportSellerKey, reportSellerName: clean(link.reportSellerName || link.reportName, "reportSellerName"), reportName: clean(link.reportSellerName || link.reportName, "reportName"), linkedAt: this.now() }; state.sellerLinks[`${company}:${record.localSellerKey}`] = record; await this.storage.set({ [STORAGE_KEY]: state }); return record; }
    async listSellerLinks(companyScopeKey) { const state = await this.load(); const company = clean(companyScopeKey, "companyScopeKey"); return Object.values(state.sellerLinks).filter((link) => link.companyScopeKey === company); }
    async removeSellerLink(companyScopeKey, localSellerKey) { const state = await this.load(); delete state.sellerLinks[`${clean(companyScopeKey, "companyScopeKey")}:${clean(localSellerKey, "localSellerKey")}`]; await this.storage.set({ [STORAGE_KEY]: state }); }
    async setContext(scope) { const state = await this.load(); state.context = { companyScopeKey: clean(scope.companyScopeKey, "companyScopeKey"), month: clean(scope.month, "month") }; await this.storage.set({ [STORAGE_KEY]: state }); return state.context; }
    async getContext() { return (await this.load()).context; }
    async getCompanyGoal(scope) {
      const state = await this.load();
      return state.companyGoals[`${clean(scope.companyScopeKey, "companyScopeKey")}:${clean(scope.month, "month")}`] || null;
    }
    async setCompanyGoal(scope, amount) {
      if (!(amount > 0)) throw new TypeError("A meta empresarial deve ser maior que zero.");
      const state = await this.load();
      const companyScopeKey = clean(scope.companyScopeKey, "companyScopeKey");
      const month = clean(scope.month, "month");
      const record = { companyScopeKey, month, amount, updatedAt: this.now() };
      state.companyGoals[`${companyScopeKey}:${month}`] = record;
      await this.storage.set({ [STORAGE_KEY]: state });
      return record;
    }
    async removeCompanyGoal(scope) { const state = await this.load(); delete state.companyGoals[`${clean(scope.companyScopeKey, "companyScopeKey")}:${clean(scope.month, "month")}`]; await this.storage.set({ [STORAGE_KEY]: state }); }
    async recordReportPoint(scope, monthlySales, capturedAt = this.now()) {
      if (!Number.isFinite(monthlySales) || monthlySales < 0) throw new TypeError("O realizado deve ser um número não negativo.");
      const state = await this.load(); const companyScopeKey = clean(scope.companyScopeKey, "companyScopeKey"); const month = clean(scope.month, "month");
      const date = String(capturedAt || this.now()).slice(0, 10); const key = `${companyScopeKey}:${month}:${date}`;
      state.reportHistory[key] = { companyScopeKey, month, date, timestamp: new Date(`${date}T12:00:00`).getTime(), monthlySales, capturedAt: String(capturedAt || this.now()) };
      await this.storage.set({ [STORAGE_KEY]: state }); return state.reportHistory[key];
    }
    async recordSalePoint(scope, monthlySales, sale) {
      if (!Number.isFinite(monthlySales) || monthlySales < 0) throw new TypeError("O realizado deve ser um número não negativo.");
      const state = await this.load(); const companyScopeKey = clean(scope.companyScopeKey, "companyScopeKey"); const month = clean(scope.month, "month");
      const capturedAt = String(sale?.occurredAt || this.now()); const date = capturedAt.slice(0, 10); const key = `${companyScopeKey}:${month}:${date}:sale:${clean(sale?.id, "saleId")}`;
      state.reportHistory[key] = { companyScopeKey, month, date, timestamp: new Date(capturedAt).getTime(), monthlySales, capturedAt, saleId: sale.id, sellerName: sale.sellerName, amount: sale.amount, source: "CODXIS_CONFIRMED_SALE" };
      await this.storage.set({ [STORAGE_KEY]: state }); return state.reportHistory[key];
    }
    async listReportHistory(scope) { const state = await this.load(); return Object.values(state.reportHistory).filter((point) => point.companyScopeKey === scope.companyScopeKey && point.month === scope.month).sort((a, b) => a.timestamp - b.timestamp); }
  }
  const api = Object.freeze({ LocalSellerGoalRepository, SCHEMA_VERSION, STORAGE_KEY, recordKey });
  root.AvanteLocalSellerGoals = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
