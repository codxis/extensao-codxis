"use strict";
const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
const message = document.getElementById("message");
const showButton = document.getElementById("show");
const refreshButton = document.getElementById("refresh");
let activeTab = null;
let currentContext = null;
const setMessage = (text, error = false) => { message.textContent = text; message.classList.toggle("error", error); };
const clearSummary = () => { document.querySelector(".summary span").textContent = "Sem acesso"; document.getElementById("goal").textContent = "Indisponível"; document.getElementById("updated").textContent = "Nenhum dado carregado"; };

async function send(type, timeoutMs = 14000) {
  if (!activeTab) [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab?.id) throw new Error("Nenhuma aba ativa.");
  return Promise.race([chrome.tabs.sendMessage(activeTab.id, { type }), new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error("Tempo limite da extensão excedido."), { code: "POPUP_TIMEOUT" })), timeoutMs))]);
}

function renderModel(response) {
  const model = response?.model;
  if (!response?.ok || !model || response.role === "unknown") {
    clearSummary();
    if (response?.role === "seller") { document.querySelector(".summary span").textContent = "Vendedor vinculado"; document.getElementById("updated").textContent = "Aguardando sincronização"; setMessage("Conta vinculada. Peça ao administrador para atualizar o relatório e a meta individual."); showButton.disabled = false; refreshButton.disabled = false; return; }
    setMessage("Esta conta ainda não está vinculada."); showButton.disabled = true; refreshButton.disabled = true; return;
  }
  const seller = response.role === "seller";
  document.querySelector(".summary span").textContent = seller ? "Minha meta" : "Meta empresarial";
  const goal = seller ? model.goal : model.companyGoal;
  document.getElementById("goal").textContent = goal > 0 ? money.format(goal) : "Não definida";
  document.getElementById("updated").textContent = model.capturedAt ? new Date(model.capturedAt).toLocaleString("pt-BR") : "Ainda não sincronizado";
  setMessage(seller ? "Resumo individual do vendedor." : "Resumo empresarial do administrador.");
  showButton.disabled = false; refreshButton.disabled = false;
}

async function initialize() {
  clearSummary(); showButton.disabled = true; refreshButton.disabled = true;
  try {
    currentContext = await send("AVANTE_GET_PAGE_CONTEXT");
    if (!currentContext?.isCodxis) { setMessage("Abra uma página do Codxis para usar a extensão."); return; }
    // Security invariant: identity is resolved by the content script before it
    // reads any scoped cache and returns this allowlisted view model. The popup
    // never reads chrome.storage business keys.
    renderModel(await send("AVANTE_GET_SANITIZED_VIEW_MODEL"));
  } catch (_) { setMessage("Não foi possível confirmar a sessão do Codxis.", true); }
}

showButton.addEventListener("click", async () => { try { const result = await send("AVANTE_OPEN_GOALS_PANEL"); if (result?.ok) window.close(); else setMessage(result?.message || "Painel indisponível.", true); } catch (_) { setMessage("Não foi possível abrir o painel.", true); } });
refreshButton.addEventListener("click", async () => { refreshButton.disabled = true; setMessage("Atualizando dados individuais…"); try { const result = await send("AVANTE_REFRESH"); if (!result?.ok) return setMessage(result?.message || `Atualização recusada: ${result?.errorCode || "erro desconhecido"}.`, true); renderModel(await send("AVANTE_GET_SANITIZED_VIEW_MODEL")); } catch (error) { setMessage(error?.code === "POPUP_TIMEOUT" ? "A atualização excedeu 14 segundos. Recarregue a página do Codxis e tente novamente." : "Não foi possível atualizar. Recarregue a página do Codxis.", true); } finally { refreshButton.disabled = false; } });
document.getElementById("exit-demo").hidden = true;
document.getElementById("options").addEventListener("click", () => chrome.runtime.openOptionsPage());
chrome.runtime.onMessage.addListener((event) => { if (event?.type === "AVANTE_PAGE_CONTEXT_CHANGED") initialize(); });
initialize();
