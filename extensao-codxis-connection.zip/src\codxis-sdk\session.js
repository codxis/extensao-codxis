"use strict";

const { CodxisMappingError } = require("./errors");

async function getCurrentIdentity() {
  throw new CodxisMappingError(
    "O mapeamento da identidade da sessão ainda não foi identificado."
  );
}

async function getCurrentRole() {
  const identity = await getCurrentIdentity();
  return identity.role;
}

module.exports = { getCurrentIdentity, getCurrentRole };

