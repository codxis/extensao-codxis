(function (root) {
  "use strict";
  const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
  const percent = new Intl.NumberFormat("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const esc = (value) => String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");

  class LocalSellerDashboard {
    constructor(options = {}) { this.storage = options.storage || root.AvanteStorage; this.identity = options.identity || root.AvanteSessionAccess.unknown(); this.root = null; this.model = null; this.state = "unlinked"; }
    scope() { return root.AvanteSessionAccess.authorizedScope(this.identity, root.AvanteSellerReport.currentMonthPeriod().month); }
    async loadSanitizedModel() { const scope = this.scope(); if (!scope) return null; const key = root.AvanteSessionAccess.scopeKey(scope); const values = await this.storage.get([key]); return root.AvanteSessionAccess.validateEnvelope(values[key], scope); }
    async mount(host) { if (!this.root) { this.root = document.createElement("section"); this.root.id = "avante-dashboard"; this.root.className = "avante-goals-panel avante-seller-only-panel"; host.prepend(this.root); } await this.render(); }
    async refresh() { await this.render(); return { ok: Boolean(this.model), role: "seller", state: this.state }; }
    stateHtml(state) {
      const messages = { unlinked: "Esta conta ainda não está vinculada.", awaiting: "Conta vinculada com segurança. Aguardando a primeira sincronização individual.", "missing-goal": "Sua conta está vinculada, mas ainda não possui meta cadastrada para este mês.", "waiting-realized": "Sua meta foi cadastrada. Aguardando a sincronização do realizado individual.", error: "Não foi possível validar os dados individuais. Solicite uma nova sincronização." };
      const login = this.identity?.evidence?.find((item) => item.selector === "#name-user")?.value || "não detectado";
      const diagnostic = state === "unlinked" ? `<small class="avante-seller-link-diagnostic">Login detectado: ${esc(login)} · Código: ${esc(this.identity?.code || "SESSION_NOT_LINKED")}</small>` : "";
      return `<div class="avante-goals-body"><p class="avante-role-state" data-seller-state="${state}">${messages[state]}</p>${diagnostic}</div>`;
    }
    goalHtml(model) {
      const hasProgress = Number.isFinite(model.realized) && Number.isFinite(model.progress);
      const progress = hasProgress ? Math.max(0, Math.min(Number(model.progress), 100)) : 0;
      const progressLabel = hasProgress ? `${percent.format(model.progress)}% da meta` : "Aguardando progresso real";
      const status = hasProgress ? (model.progress >= 100 ? "Meta alcançada" : "Meta em andamento") : "Meta mensal definida";
      const state = progress >= 100 ? "achieved" : progress >= 80 ? "near" : progress > 0 ? "advancing" : "waiting";
      const sales = [...(model.recentSales || [])].reverse();
      const productCount = sales.reduce((sum, sale) => sum + (Number(sale.itemCount) || sale.items?.length || 0), 0);
      const activity = sales.length ? `<section class="avante-seller-activity"><header><div><small>Atividade recente</small><h3>Minhas últimas vendas</h3></div><span>Atualização automática</span></header><ol>${sales.slice(0, 5).map((sale) => { const descriptions = (sale.items || []).map((item) => item.description).filter(Boolean); return `<li><div><strong>${descriptions.length ? esc(descriptions.join(" · ")) : esc(sale.type || "Venda confirmada")}</strong><span>${sale.itemCount || descriptions.length || 0} produto(s)${sale.paymentMethod ? ` · ${esc(sale.paymentMethod)}` : ""}${sale.document ? ` · Documento ${esc(sale.document)}` : ""}</span><time datetime="${esc(sale.occurredAt)}">${esc(new Date(sale.occurredAt).toLocaleString("pt-BR"))}</time></div><strong>${money.format(sale.amount)}</strong></li>`; }).join("")}</ol></section>` : `<section class="avante-seller-activity-empty"><strong>Aguardando a próxima venda confirmada</strong><span>Este painel será atualizado automaticamente quando uma venda individual for sincronizada.</span></section>`;
      return `<header class="avante-seller-goal-header"><div class="avante-seller-goal-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"></circle><circle cx="12" cy="12" r="3"></circle><path d="M12 2v3M22 12h-3M12 22v-3M2 12h3"></path></svg></div><div><small>Meu painel</small><h2>${esc(model.sellerName || "Vendedor")}</h2></div><span>${status}</span></header><div class="avante-seller-goal-body"><section class="avante-seller-goal-card is-${state}" aria-label="Meta mensal do vendedor"><span>Minha meta mensal</span><strong>${money.format(model.goal)}</strong><div class="avante-seller-goal-progress-heading"><span>${progressLabel}</span>${hasProgress ? `<strong>${percent.format(model.progress)}%</strong>` : ""}</div><div class="avante-seller-goal-progress" role="progressbar" aria-label="${esc(progressLabel)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(progress)}"><i style="--avante-seller-progress:${progress}%"></i></div><div class="avante-seller-goal-scale"><span>Início</span><span>Meta</span></div></section>${hasProgress ? `<section class="avante-seller-kpis"><article><span>Vendido no mês</span><strong>${money.format(model.realized)}</strong></article><article><span>Falta para a meta</span><strong>${money.format(model.remaining || 0)}</strong></article><article><span>Vendas recentes</span><strong>${sales.length}</strong></article><article><span>Produtos registrados</span><strong>${productCount}</strong></article></section>` : ""}${activity}<footer>Atualizado em ${model.capturedAt ? esc(new Date(model.capturedAt).toLocaleString("pt-BR")) : "agora"} · sincronização automática a cada 10 segundos</footer></div>`;
    }
    async render() {
      const linked = this.identity?.role === "seller" && this.identity?.sellerId && this.scope();
      if (!linked) { this.model = null; this.state = "unlinked"; this.root.innerHTML = this.stateHtml(this.state); return; }
      try { this.model = await this.loadSanitizedModel(); } catch (_) { this.model = null; this.state = "error"; this.root.innerHTML = this.stateHtml(this.state); return; }
      if (!this.model) { this.state = "awaiting"; this.root.innerHTML = this.stateHtml(this.state); return; }
      const m = this.model;
      if (m.syncErrorCode) { this.state = "error"; this.root.innerHTML = this.stateHtml(this.state); return; }
      if (m.goal == null) { this.state = "missing-goal"; this.root.innerHTML = this.stateHtml(this.state); return; }
      if (m.realized == null) {
        this.state = "goal-only";
        this.root.innerHTML = this.goalHtml(m);
        return;
      }
      this.state = "ready";
      // This execution path receives only the validated, allowlisted seller DTO.
      this.root.innerHTML = this.goalHtml(m);
    }
    unmount() { this.model = null; this.root?.replaceChildren(); this.root?.remove(); this.root = null; }
  }
  root.AvanteLocalSellerDashboard = LocalSellerDashboard;
  if (typeof module !== "undefined" && module.exports) module.exports = { LocalSellerDashboard };
})(typeof globalThis !== "undefined" ? globalThis : this);
