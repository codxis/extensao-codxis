"use strict";

const {
  CodxisAuthorizationError,
  CodxisSellerLinkError,
  CodxisScopeMismatchError
} = require("./errors");
const { createUnknownIdentity, optionalString } = require("./contracts");

const normalizedSet = (values) =>
  new Set((values || []).map(optionalString).filter(Boolean));

function matchesRole(profile, configured = {}) {
  const ids = normalizedSet(configured.profileIds);
  const codes = normalizedSet(configured.profileCodes);
  const permissions = normalizedSet(configured.permissions);
  if (profile.profileId && ids.has(profile.profileId)) return true;
  if (profile.profileCode && codes.has(profile.profileCode)) return true;
  return profile.permissions.some((permission) => permissions.has(permission));
}

function resolveRole(identity, roleConfig) {
  const profile = {
    profileId: optionalString(identity?.rawProfileId ?? identity?.profileId),
    profileCode: optionalString(identity?.rawProfileCode ?? identity?.profileCode),
    permissions: Array.isArray(identity?.permissions) ? identity.permissions : []
  };
  const administrator = matchesRole(profile, roleConfig?.administrator);
  const seller = matchesRole(profile, roleConfig?.seller);
  // Configuração ambígua também falha de forma fechada.
  if (administrator === seller) return "unknown";
  return administrator ? "administrator" : "seller";
}

function withResolvedRole(identity, roleConfig) {
  return createUnknownIdentity({
    ...identity,
    role: resolveRole(identity, roleConfig)
  });
}

const canViewCompany = (identity) => identity?.role === "administrator";
const canViewAllSellers = (identity) => identity?.role === "administrator";
const canEditGoals = (identity) => identity?.role === "administrator";

function canViewSeller(identity, sellerId) {
  const target = optionalString(sellerId);
  if (!target) return false;
  if (identity?.role === "administrator") return true;
  return identity?.role === "seller" &&
    optionalString(identity.sellerId) === target;
}

function assertCanViewSeller(identity, sellerId) {
  if (identity?.role === "seller" && !identity.sellerId) {
    throw new CodxisSellerLinkError(
      "O usuário vendedor não possui sellerId confirmado."
    );
  }
  if (!canViewSeller(identity, sellerId)) {
    throw new CodxisScopeMismatchError(
      "O sellerId solicitado não pertence ao escopo autorizado.",
      { requestedSellerId: optionalString(sellerId) }
    );
  }
  return true;
}

function assertCanViewCompany(identity) {
  if (!canViewCompany(identity)) {
    throw new CodxisAuthorizationError(
      "O perfil atual não pode visualizar dados gerais da empresa."
    );
  }
  return true;
}

function assertCanEditGoals(identity) {
  if (!canEditGoals(identity)) {
    throw new CodxisAuthorizationError(
      "O perfil Codxis atual não pode editar metas."
    );
  }
  return true;
}

module.exports = {
  assertCanEditGoals,
  assertCanViewCompany,
  assertCanViewSeller,
  canEditGoals,
  canViewAllSellers,
  canViewCompany,
  canViewSeller,
  resolveRole,
  withResolvedRole
};

