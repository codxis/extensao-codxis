(function (root) {
  "use strict";

  const KEYS = Object.freeze({
    goal: "avante.goal",
    snapshot: "avante.snapshot",
    collapsed: "avante.collapsed",
    goalsPanelClosed: "avante.goals.panel.closed",
    goalsPanelCollapsed: "avante.goals.panel.collapsed",
    goalsPanelLastOpenAt: "avante.goals.panel.lastOpenAt",
    diagnostics: "avante.diagnostics",
    password: "avante.password",
    passwordAttempts: "avante.passwordAttempts",
    passwordBlockedUntil: "avante.passwordBlockedUntil",
    salesHistory: "avante.salesHistory",
    demoEnabled: "avante.demo.enabled",
    demoProfile: "avante.demo.profile",
    demoCompanyGoal: "avante.demo.companyGoal",
    demoSellerGoals: "avante.demo.sellerGoals",
    demoHistory: "avante.demo.history",
    adminPanelEnabled: "avante.adminPanel.enabled",
    adminSessionName: "avante.adminPanel.sessionName",
    localSellerGoals: "avante.localSellerGoals",
    sellerReportSnapshot: "avante.sellerReportSnapshot",
    identityBindings: "avante.security.identityBindings.v1",
    activeSession: "avante.security.activeSession.v1"
    ,syncApiUrl: "avante.sync.apiUrl"
    ,syncAdminToken: "avante.sync.adminToken"
    ,syncSellerToken: "avante.sync.sellerToken"
  });

  const isContextInvalidated = (error) =>
    /extension context invalidated/i.test(String(error?.message || error || ""));

  const runtimeError = () => {
    try {
      const error = chrome.runtime?.lastError;
      return error ? new Error(error.message || String(error)) : null;
    } catch (error) {
      return error;
    }
  };

  const get = (keys) =>
    new Promise((resolve, reject) => {
      try {
        chrome.storage.local.get(keys, (values) => {
          const error = runtimeError();
          if (isContextInvalidated(error)) return resolve({});
          error ? reject(error) : resolve(values || {});
        });
      } catch (error) {
        // Ao recarregar a extensão, o content script antigo perde o acesso às
        // APIs. A instância nova será injetada ao recarregar a página.
        isContextInvalidated(error) ? resolve({}) : reject(error);
      }
    });

  const set = (values) =>
    new Promise((resolve, reject) => {
      try {
        chrome.storage.local.set(values, () => {
          const error = runtimeError();
          if (isContextInvalidated(error)) return resolve();
          error ? reject(error) : resolve();
        });
      } catch (error) {
        isContextInvalidated(error) ? resolve() : reject(error);
      }
    });

  const remove = (keys) => new Promise((resolve, reject) => {
    try { chrome.storage.local.remove(keys, () => { const error = runtimeError(); error ? reject(error) : resolve(); }); }
    catch (error) { isContextInvalidated(error) ? resolve() : reject(error); }
  });
  root.AvanteStorage = Object.freeze({ KEYS, get, set, remove, isContextInvalidated });
})(globalThis);
