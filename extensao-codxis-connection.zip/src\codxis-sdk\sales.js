"use strict";

const { CodxisMappingError } = require("./errors");

async function getCompanyMonthlyPerformance() {
  throw new CodxisMappingError(
    "O endpoint do relatório mensal da empresa ainda não foi identificado."
  );
}

async function getSellerMonthlyPerformance(_sellerId) {
  throw new CodxisMappingError(
    "O endpoint do relatório mensal por vendedor ainda não foi identificado."
  );
}

async function getAllSellerMonthlyPerformance() {
  throw new CodxisMappingError(
    "O relatório de todos os vendedores ainda não foi identificado."
  );
}

module.exports = {
  getAllSellerMonthlyPerformance,
  getCompanyMonthlyPerformance,
  getSellerMonthlyPerformance
};

