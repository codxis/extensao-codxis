(function () {
  "use strict";

  const config = globalThis.AVANTE_CONFIG;
  let dashboard;
  let collector;
  let started = false;
  let visibilityQueued = false;
  let sellerReportScanQueued = false;
  let saleListenerAttached = false;
  let reportListenerAttached = false;
  let lastPersistedReportSignature = "";
  let activeSellerReportRefresh = null;
  let saleRefreshTimer = null;
  let sellerSyncTimer = null;
  let sellerSyncInFlight = null;
  let lastContextSignature = "";
  const diagnosticsEnabled = () =>
    config.app.diagnostics || globalThis.__AVANTE_DIAGNOSTICS__;
  let activeDemo = false;
  let localAdminEnabled = false;
  let administrativeAccessDenied = false;
  let sellerMode = false;
  let activeIdentity = globalThis.AvanteSessionAccess.unknown();
  let activeScope = null;
  const demoEnabled = () => activeDemo;
  const runtimeMessage = (message, timeoutMs = 10000) => new Promise((resolve) => { let settled = false; const finish = (value) => { if (settled) return; settled = true; window.clearTimeout(timeout); resolve(value); }; const timeout = window.setTimeout(() => finish({ ok: false, errorCode: "EXTENSION_MESSAGE_TIMEOUT" }), timeoutMs); try { chrome.runtime.sendMessage(message, (response) => finish(chrome.runtime.lastError ? { ok: false, errorCode: chrome.runtime.lastError.message } : response || { ok: false, errorCode: "EMPTY_EXTENSION_RESPONSE" })); } catch (error) { finish({ ok: false, errorCode: error.message }); } });
  const publishRemoteSellerDto = (scope, data) => runtimeMessage({ type: "AVANTE_SYNC_PUBLISH", scope: { companyScopeKey: scope.companyScopeKey, userId: scope.userId, sellerId: scope.sellerId, month: scope.month }, data });
  async function pullRemoteSellerDto() {
    if (activeIdentity.role !== "seller" || !activeScope) return { ok: false, errorCode: "SELLER_SCOPE_UNAVAILABLE" };
    const remoteScope = { companyScopeKey: activeScope.companyScopeKey, userId: activeScope.userId, sellerId: activeScope.sellerId, month: activeScope.month };
    const response = await runtimeMessage({ type: "AVANTE_SYNC_READ", scope: remoteScope });
    if (!response?.ok && response?.errorCode === "DTO_NOT_PUBLISHED") return { ok: true, pending: true, errorCode: "DTO_NOT_PUBLISHED" };
    const record = response?.result;
    if (!response?.ok || !record?.data) return response;
    const data = globalThis.AvanteSessionAccess.sanitizeSellerModel(activeIdentity, record.data);
    if (!data || data.month !== activeScope.month || data.companyScopeKey !== activeScope.companyScopeKey) return { ok: false, errorCode: "REMOTE_DTO_SCOPE_MISMATCH" };
    const key = globalThis.AvanteSessionAccess.scopeKey(activeScope);
    await globalThis.AvanteStorage.set({ [key]: { schemaVersion: 1, scopeKey: key, scope: activeScope, data } });
    return { ok: true, data, revision: record.revision };
  }

  const syncSellerAutomatically = async () => {
    if (!sellerMode || document.visibilityState === "hidden") return;
    if (sellerSyncInFlight) return sellerSyncInFlight;
    sellerSyncInFlight = (async () => { const result = await pullRemoteSellerDto(); if (result?.ok) await dashboard?.refresh?.(); return result; })();
    try { return await sellerSyncInFlight; } finally { sellerSyncInFlight = null; }
  };

  const startSellerSyncLoop = () => {
    window.clearInterval(sellerSyncTimer);
    sellerSyncTimer = window.setInterval(() => syncSellerAutomatically().catch(() => {}), 10000);
  };

  const normalize = (text) =>
    String(text || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();

  const isAllowedApp = () => {
    if (config.app.allowedHosts.length) {
      return config.app.allowedHosts.some(
        (host) =>
          location.hostname === host || location.hostname.endsWith(`.${host}`)
      );
    }
    const sample = `${document.title} ${document.body?.innerText?.slice(0, 5000)}`;
    return config.app.titleHints.some((hint) =>
      normalize(sample).includes(normalize(hint))
    );
  };

  /**
   * A home é reconhecida pela rota canônica ou por evidência DOM exclusiva,
   * sempre limitada ao domínio Codxis permitido.
   */
  const detectCodxisHome = () =>
    globalThis.AvantePageContext.detectCodxisHome(location.href, document, config);

  const isHomePage = () => detectCodxisHome().isHome;

  const isPrivateCodxisPage = () => {
    const context = globalThis.AvantePageContext.parseCodxisUrl(location.href);
    return context.isCodxis && context.pathname.startsWith("/sistema/pages/privado/");
  };

  // O vendedor navega por varias telas durante a venda. O painel individual
  // permanece disponivel na area privada; o administrativo continua na home.
  const shouldShowDashboard = () => sellerMode || administrativeAccessDenied
    ? isPrivateCodxisPage()
    : isHomePage();

  function scanVisibleSellerReport() {
    if (!localAdminEnabled) return false;
    const panel = document.getElementById("form:painelGeralRelatorios");
    const rows = document.getElementById("form:datatableVendasVendedores_data");
    const companyScopeKey = activeIdentity.role === "administrator" ? activeIdentity.companyScopeKey : "";
    if (!panel || !rows || !companyScopeKey) return false;
    try {
      const period = globalThis.AvanteSellerReport.currentMonthPeriod();
      const report = globalThis.AvanteSellerReport.parseSellerReport(
        `<partial-response><changes><update id="form:painelGeralRelatorios"><![CDATA[${panel.outerHTML}]]></update></changes></partial-response>`,
        {
          start: document.getElementById("form:diaInicial_input")?.value || period.start,
          end: document.getElementById("form:diaFinal_input")?.value || period.end,
          capturedAt: new Date().toISOString()
        }
      );
      if (!report.sellers.length) return false;
      window.dispatchEvent(new CustomEvent("avante:seller-report", {
        detail: JSON.stringify({ ...report, companyScopeKey })
      }));
      return true;
    } catch (_) { return false; }
  }

  function queueVisibleSellerReportScan() {
    if (sellerReportScanQueued) return;
    sellerReportScanQueued = true;
    window.setTimeout(() => {
      sellerReportScanQueued = false;
      scanVisibleSellerReport();
    }, 400);
  }

  async function onConfirmedSale(event) {
    try {
      const detail = JSON.parse(event.detail);
      if (!detail.companyScopeKey) detail.companyScopeKey = dashboard?.scope?.().companyScopeKey || "";
      const result = await globalThis.AvanteSaleLedger.record(globalThis.AvanteStorage, detail);
      if (!result.ok || result.duplicate) return;
      const salePeriod = globalThis.AvanteSellerReport.currentMonthPeriod(new Date(result.sale.occurredAt));
      await dashboard?.goals?.recordSalePoint?.({ companyScopeKey: result.sale.companyScopeKey, month: salePeriod.month }, result.snapshot.totalRealized, result.sale);
      window.dispatchEvent(new CustomEvent("avante:seller-report", { detail: JSON.stringify(result.snapshot) }));
      if (localAdminEnabled) {
        window.clearTimeout(saleRefreshTimer);
        saleRefreshTimer = window.setTimeout(() => refreshSellerReport({ reason: "sale-completed", force: true }).catch((error) => { if (diagnosticsEnabled()) console.warn("[CODXIS WEB] Atualização após venda falhou", { code: error?.code || "REFRESH_ERROR" }); }), 1000);
      }
    } catch (error) {
      if (diagnosticsEnabled()) console.warn("[CODXIS WEB] Venda confirmada não pôde ser registrada", error);
    }
  }

  const reportSignature = (report) => JSON.stringify({
    companyScopeKey: report?.companyScopeKey || "",
    period: report?.period || null,
    totalRealized: report?.totalRealized ?? null,
    sellers: (report?.sellers || []).map((seller) => [seller.localSellerKey, seller.realized]).sort((a, b) => String(a[0]).localeCompare(String(b[0])))
  });

  const recentSalesForSeller = (ledger, { companyScopeKey, month, sellerId, localSellerKeys = [] }) => (Array.isArray(ledger) ? ledger : []).filter((sale) => sale.companyScopeKey === companyScopeKey && String(sale.occurredAt || "").startsWith(month) && (String(sale.sellerId || "") === String(sellerId) || localSellerKeys.includes(sale.sellerKey))).slice(-10).map((sale) => ({ id: sale.id, sellerId, amount: sale.amount, type: sale.type, document: sale.document, paymentMethod: sale.paymentMethod, itemCount: sale.itemCount, items: sale.items, occurredAt: sale.occurredAt }));

  async function persistIndividualScopes(report) {
    if (activeIdentity.role !== "administrator") return { localPublished: 0, remotePublished: 0, failures: ["ADMIN_REQUIRED"] };
    const period = globalThis.AvanteSellerReport.currentMonthPeriod();
    const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.identityBindings, globalThis.AvanteStorage.KEYS.localSellerGoals, "avante.salesLedger"]);
    const storedBindings = Array.isArray(values[globalThis.AvanteStorage.KEYS.identityBindings]) ? values[globalThis.AvanteStorage.KEYS.identityBindings] : [];
    const bindings = [...storedBindings, ...globalThis.AvanteSessionAccess.APPROVED_SELLER_BINDINGS].filter((item, index, all) => item.role === "seller" && item.companyScopeKey === report.companyScopeKey && item.sellerId && all.findIndex((candidate) => candidate.userId === item.userId && candidate.sellerId === item.sellerId && candidate.companyScopeKey === item.companyScopeKey) === index);
    const goalState = values[globalThis.AvanteStorage.KEYS.localSellerGoals] || {};
    const goals = Object.values(goalState.sellerGoals || {});
    const sellerLinks = Object.values(goalState.sellerLinks || {});
    const ledger = Array.isArray(values["avante.salesLedger"]) ? values["avante.salesLedger"] : [];
    const writes = {};
    const skipped = [];
    for (const binding of bindings) {
      const identity = globalThis.AvanteSessionAccess.resolveIdentity({ login: binding.login, companyScopeKey: binding.companyScopeKey, bindings: [binding] });
      let seller = (report.sellers || []).find((item) => String(item.sellerId || "") === String(binding.sellerId));
      if (!seller) {
        const confirmedKeys = [...new Set(ledger.filter((sale) => String(sale.sellerId || "") === String(binding.sellerId) && (sale.companyScopeKey === report.companyScopeKey || globalThis.AvanteSessionAccess.currentCompanyEvidence(document).includes(String(sale.companyScopeKey || "")))).map((sale) => sale.sellerKey || globalThis.AvanteSellerReport.createLocalSellerKey(sale.sellerName)).filter(Boolean))];
        const candidates = (report.sellers || []).filter((item) => confirmedKeys.includes(item.localSellerKey));
        if (confirmedKeys.length === 1 && candidates.length === 1 && candidates[0].duplicateName !== true) seller = candidates[0];
      }
      const approvedLocalKey = String(binding.localSellerKey || globalThis.AvanteSessionAccess.approvedLocalSellerKey(identity) || "").trim() || null;
      const sellerLink = sellerLinks.find((link) => link.companyScopeKey === report.companyScopeKey && (link.localSellerKey === approvedLocalKey || link.reportSellerKey === approvedLocalKey)) || null;
      const reportSellerKey = sellerLink?.reportSellerKey || approvedLocalKey;
      if (!seller && reportSellerKey) seller = (report.sellers || []).find((item) => item.localSellerKey === reportSellerKey || item.reportSellerKey === reportSellerKey) || null;
      const localSellerKey = sellerLink?.localSellerKey || approvedLocalKey || seller?.localSellerKey;
      if (!localSellerKey) { skipped.push(`${binding.sellerId}:SELLER_LINK_MISSING`); continue; } // never fall back to a name
      const goal = goals.find((item) => item.companyScopeKey === report.companyScopeKey && item.month === period.month && item.localSellerKey === localSellerKey);
      if (!seller) { skipped.push(`${binding.sellerId}:REPORT_SELLER_NOT_MAPPED`); continue; }
      if (!goal) { skipped.push(`${binding.sellerId}:INDIVIDUAL_GOAL_NOT_MAPPED`); continue; }
      const amount = goal?.amount == null ? Number.NaN : Number(goal.amount); const realized = seller?.realized == null ? Number.NaN : Number(seller.realized);
      const metrics = amount > 0 && Number.isFinite(realized) ? globalThis.AvanteGoalCalculator.calculateMonthlyGoalMetrics(amount, realized) : null;
      const scope = globalThis.AvanteSessionAccess.authorizedScope(identity, period.month);
      if (!scope) { skipped.push(`${binding.sellerId}:AUTHORIZED_SCOPE_MISSING`); continue; }
      const key = globalThis.AvanteSessionAccess.scopeKey(scope);
      const previousValues = await globalThis.AvanteStorage.get([key]);
      const previous = globalThis.AvanteSessionAccess.validateEnvelope(previousValues[key], scope);
      const capturedAt = report.capturedAt || new Date().toISOString();
      const history = Array.isArray(previous?.individualHistory) ? [...previous.individualHistory] : [];
      if (Number.isFinite(realized)) {
        const date = String(capturedAt).slice(0, 10); const timestamp = new Date(capturedAt).getTime();
        const point = { date, timestamp: Number.isFinite(timestamp) ? timestamp : Date.now(), realized, sellerId: identity.sellerId };
        const index = history.findIndex((item) => item.date === date);
        if (index >= 0) history[index] = point; else history.push(point);
      }
      const commissionPercent = goal?.commissionPercent == null ? Number.NaN : Number(goal.commissionPercent);
      const recentSales = recentSalesForSeller(ledger, { companyScopeKey: report.companyScopeKey, month: period.month, sellerId: identity.sellerId, localSellerKeys: [localSellerKey, reportSellerKey].filter(Boolean) });
      const model = globalThis.AvanteSessionAccess.sanitizeSellerModel(identity, { sellerId: identity.sellerId, localSellerKey, sellerName: seller?.sellerName || goal?.sellerName || binding.sellerName, month: period.month, goal: amount > 0 ? amount : null, realized: Number.isFinite(realized) ? realized : null, progress: metrics?.progress ?? null, remaining: metrics?.remainingAmount ?? null, surplus: metrics?.surplus ?? null, commissionPercent: Number.isFinite(commissionPercent) ? commissionPercent : null, commissionEstimated: Number.isFinite(realized) && Number.isFinite(commissionPercent) ? realized * commissionPercent / 100 : null, individualHistory: history.sort((left, right) => left.timestamp - right.timestamp), recentSales, capturedAt, syncState: !goal ? "missing-goal" : !Number.isFinite(realized) ? "waiting-realized" : "ready" });
      if (!model) { skipped.push(`${binding.sellerId}:SELLER_MODEL_REJECTED`); continue; }
      writes[key] = { schemaVersion: 1, scopeKey: key, scope, data: model };
    }
    const result = { localPublished: Object.keys(writes).length, remotePublished: 0, failures: [...skipped] };
    if (Object.keys(writes).length) {
      await globalThis.AvanteStorage.set(writes);
      const remote = await Promise.all(Object.values(writes).map((envelope) => publishRemoteSellerDto(envelope.scope, envelope.data)));
      result.remotePublished = remote.filter((item) => item?.ok).length;
      result.failures.push(...remote.filter((item) => !item?.ok).map((item) => item?.errorCode || "REMOTE_PUBLISH_FAILED"));
    }
    return result;
  }

  async function republishIndividualScopesFromStoredReport() {
    if (activeIdentity.role !== "administrator") return { localPublished: 0, remotePublished: 0, failures: ["ADMIN_REQUIRED"] };
    const current = dashboard?.currentModel;
    const currentSellers = current?.reportSellers?.length ? current.reportSellers : current?.sellers;
    if (currentSellers?.length) {
      return persistIndividualScopes({ companyScopeKey: activeIdentity.companyScopeKey, sellers: currentSellers.map((seller) => ({ localSellerKey: seller.reportSellerKey || seller.localSellerKey, sellerId: seller.sellerId || null, sellerName: seller.reportName || seller.sellerName, realized: seller.realized })), capturedAt: dashboard?.snapshot?.capturedAt || new Date().toISOString(), source: "ADMIN_CURRENT_MODEL" });
    }
    const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.sellerReportSnapshot]);
    const storedReport = values[globalThis.AvanteStorage.KEYS.sellerReportSnapshot];
    // A meta individual pode ser publicada sem o relatório de realizados. Isso
    // mantém o DTO restrito ao vendedor e evita bloquear a visualização da meta.
    const report = storedReport?.companyScopeKey === activeIdentity.companyScopeKey
      ? storedReport
      : { companyScopeKey: activeIdentity.companyScopeKey, sellers: [], capturedAt: new Date().toISOString(), source: "GOAL_ONLY" };
    return persistIndividualScopes(report);
  }

  async function currentAdminSellerRows() {
    if (activeIdentity.role !== "administrator") return [];
    await dashboard?.render?.();
    const model = dashboard?.currentModel;
    const rows = [...(model?.ranked || []), ...(model?.goalsWithoutSales || [])];
    for (const seller of model?.sellers || []) {
      if (rows.some((row) => row.localSellerKey === seller.localSellerKey)) continue;
      const goal = (model?.goals || []).find((item) => item.localSellerKey === seller.localSellerKey);
      if (!goal?.amount) continue;
      const metrics = seller.realized == null ? null : globalThis.AvanteGoalCalculator.calculateMonthlyGoalMetrics(Number(goal.amount), Number(seller.realized));
      rows.push({ ...seller, goal, metrics });
    }
    if (rows.length) return [...new Map(rows.filter((row) => row?.localSellerKey && row?.goal?.amount > 0).map((row) => [row.localSellerKey, row])).values()];
    const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.localSellerGoals, globalThis.AvanteStorage.KEYS.sellerReportSnapshot]);
    const state = values[globalThis.AvanteStorage.KEYS.localSellerGoals] || {};
    const report = values[globalThis.AvanteStorage.KEYS.sellerReportSnapshot];
    const period = globalThis.AvanteSellerReport.currentMonthPeriod();
    const links = Object.values(state.sellerLinks || {});
    return Object.values(state.sellerGoals || {}).filter((goal) => goal.companyScopeKey === activeIdentity.companyScopeKey && goal.month === period.month && goal.amount > 0).map((goal) => {
      const link = links.find((item) => item.companyScopeKey === goal.companyScopeKey && item.localSellerKey === goal.localSellerKey);
      const seller = report?.companyScopeKey === goal.companyScopeKey ? (report.sellers || []).find((item) => item.localSellerKey === (link?.reportSellerKey || goal.localSellerKey)) : null;
      const realized = seller?.realized == null ? null : Number(seller.realized);
      return { localSellerKey: goal.localSellerKey, sellerName: goal.sellerName, realized, goal, metrics: realized == null ? null : globalThis.AvanteGoalCalculator.calculateMonthlyGoalMetrics(Number(goal.amount), realized) };
    });
  }

  async function publishSelectedAdminSeller(target) {
    if (activeIdentity.role !== "administrator") return { localPublished: 0, remotePublished: 0, failures: ["ADMIN_REQUIRED"] };
    if (!target || target.companyScopeKey !== activeIdentity.companyScopeKey || !target.userId || !target.sellerId || !target.localSellerKey) return { localPublished: 0, remotePublished: 0, failures: ["INVALID_RECONCILIATION_TARGET"] };
    const rows = await currentAdminSellerRows();
    const row = rows.find((item) => item.localSellerKey === target.localSellerKey);
    if (!row) return { localPublished: 0, remotePublished: 0, failures: [`${target.sellerId}:ADMIN_ROW_NOT_FOUND`] };
    const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.identityBindings, "avante.salesLedger"]);
    const storedBindings = Array.isArray(values[globalThis.AvanteStorage.KEYS.identityBindings]) ? values[globalThis.AvanteStorage.KEYS.identityBindings] : [];
    const binding = [...globalThis.AvanteSessionAccess.APPROVED_SELLER_BINDINGS, ...storedBindings].find((item) => item.role === "seller" && item.companyScopeKey === target.companyScopeKey && String(item.userId) === String(target.userId) && String(item.sellerId) === String(target.sellerId));
    if (!binding) return { localPublished: 0, remotePublished: 0, failures: [`${target.sellerId}:IDENTITY_BINDING_NOT_FOUND`] };
    const identity = globalThis.AvanteSessionAccess.resolveIdentity({ login: binding.login, companyScopeKey: binding.companyScopeKey, bindings: [binding] });
    const period = globalThis.AvanteSellerReport.currentMonthPeriod();
    const scope = globalThis.AvanteSessionAccess.authorizedScope(identity, period.month);
    if (!scope) return { localPublished: 0, remotePublished: 0, failures: [`${target.sellerId}:AUTHORIZED_SCOPE_MISSING`] };
    const goal = Number(row.goal.amount); const realized = row.realized == null ? Number.NaN : Number(row.realized);
    const metrics = Number.isFinite(realized) ? globalThis.AvanteGoalCalculator.calculateMonthlyGoalMetrics(goal, realized) : null;
    const commissionPercent = Number(row.goal.commissionPercent);
    const capturedAt = dashboard?.snapshot?.capturedAt || new Date().toISOString();
    const recentSales = recentSalesForSeller(values["avante.salesLedger"], { companyScopeKey: target.companyScopeKey, month: period.month, sellerId: identity.sellerId, localSellerKeys: [row.localSellerKey] });
    const data = globalThis.AvanteSessionAccess.sanitizeSellerModel(identity, { sellerId: identity.sellerId, localSellerKey: row.localSellerKey, sellerName: row.sellerName, month: period.month, goal, realized: Number.isFinite(realized) ? realized : null, progress: metrics?.progress ?? null, remaining: metrics?.remainingAmount ?? null, surplus: metrics?.surplus ?? null, commissionPercent: Number.isFinite(commissionPercent) ? commissionPercent : null, commissionEstimated: Number.isFinite(realized) && Number.isFinite(commissionPercent) ? realized * commissionPercent / 100 : null, individualHistory: [], recentSales, capturedAt, syncState: Number.isFinite(realized) ? "ready" : "waiting-realized", syncErrorCode: null });
    if (!data) return { localPublished: 0, remotePublished: 0, failures: [`${target.sellerId}:SELLER_MODEL_REJECTED`] };
    const key = globalThis.AvanteSessionAccess.scopeKey(scope);
    const updatedBinding = { ...binding, localSellerKey: row.localSellerKey, approvedAt: binding.approvedAt || new Date().toISOString() };
    const updatedBindings = [...storedBindings.filter((item) => !(item.companyScopeKey === target.companyScopeKey && String(item.userId) === String(target.userId) && String(item.sellerId) === String(target.sellerId))), updatedBinding];
    await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.identityBindings]: updatedBindings, [key]: { schemaVersion: 1, scopeKey: key, scope, data } });
    const remote = await publishRemoteSellerDto(scope, data);
    return { localPublished: 1, remotePublished: remote?.ok ? 1 : 0, failures: remote?.ok ? [] : [remote?.errorCode || "REMOTE_PUBLISH_FAILED"] };
  }

  async function persistCapturedSellerReport(event) {
    try {
      if (activeSellerReportRefresh) return;
      let report = JSON.parse(event.detail);
      const observedCompanies = globalThis.AvanteSessionAccess.currentCompanyEvidence(document);
      if (activeIdentity.role !== "administrator" || (!observedCompanies.includes(String(report?.companyScopeKey || "")) && report?.companyScopeKey !== activeIdentity.companyScopeKey)) return;
      report = { ...report, companyScopeKey: activeIdentity.companyScopeKey };
      if (!report?.companyScopeKey || !report.sellers?.length || (report.pagination?.detected && !report.pagination?.complete)) return;
      const signature = reportSignature(report);
      if (signature === lastPersistedReportSignature) return;
      const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.sellerReportSnapshot]);
      const previous = values[globalThis.AvanteStorage.KEYS.sellerReportSnapshot];
      if (signature === reportSignature(previous)) { lastPersistedReportSignature = signature; return; }
      const snapshot = { ...report, capturedAt: report.capturedAt || new Date().toISOString() };
      await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.sellerReportSnapshot]: snapshot });
      await persistIndividualScopes(snapshot);
      lastPersistedReportSignature = signature;
      window.dispatchEvent(new CustomEvent("avante:seller-report-persisted", { detail: JSON.stringify(snapshot) }));
      if (diagnosticsEnabled()) console.debug("[CODXIS WEB] Snapshot real persistido", { companyScopeKey: snapshot.companyScopeKey, sellerCount: snapshot.sellers.length, totalRealized: snapshot.totalRealized, capturedAt: snapshot.capturedAt });
    } catch (error) {
      if (diagnosticsEnabled()) console.warn("[CODXIS WEB] Snapshot real preservado após falha de persistência", { code: "SNAPSHOT_PERSIST_FAILED", message: String(error?.message || error).slice(0, 160) });
    }
  }

  async function refreshSellerReport({ reason = "manual", force = false } = {}) {
    if (activeSellerReportRefresh) return activeSellerReportRefresh;
    const previous = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.sellerReportSnapshot]);
    const previousSnapshot = previous[globalThis.AvanteStorage.KEYS.sellerReportSnapshot] || null;
    const previousCapturedAt = previousSnapshot?.capturedAt || null;
    const refreshRequestedAt = new Date().toISOString();
    activeSellerReportRefresh = new Promise((resolve) => {
      let finished = false;
      let reportResponseReceived = false;
      let reportUpdateIdFound = false;
      const finish = (result) => {
        if (finished) return;
        finished = true;
        window.clearTimeout(timeout);
        window.removeEventListener("avante:seller-report", onReport);
        window.removeEventListener("avante:seller-report-status", onStatus);
        window.removeEventListener("avante:seller-report-diagnostic", onDiagnostic);
        const response = { refreshStarted: true, reason, force: force === true, reportResponseReceived, reportUpdateIdFound, sellersParsed: 0, previousCapturedAt, newCapturedAt: null, refreshRequestedAt, refreshCompletedAt: new Date().toISOString(), errorCode: null, ...result };
        if (diagnosticsEnabled()) console.debug("[CODXIS WEB] Diagnóstico de atualização", { saleCompletedDetected: reason === "sale-completed", refreshStarted: true, refreshReason: reason, reportQueried: true, responseReceived: response.reportResponseReceived, updateIdFound: response.reportUpdateIdFound, rows: response.sellersParsed, sellersFound: response.sellersParsed, documentValueFound: response.documentValueFound || 0, linksFound: response.linkedSellers || 0, previousCapturedAt, newCapturedAt: response.newCapturedAt, previousCompanyRealized: previousSnapshot?.totalRealized ?? null, newCompanyRealized: response.companyRealized ?? null, errorCode: response.errorCode });
        resolve(response);
      };
      const onDiagnostic = (event) => {
        try {
          const detail = JSON.parse(event.detail);
          if (["response-received", "parsing", "parsed"].includes(detail.stage)) reportResponseReceived = true;
          if (detail.updateId === globalThis.AvanteSellerReport.UPDATE_ID) reportUpdateIdFound = true;
        } catch (_) {}
      };
      const onReport = async (event) => {
        reportResponseReceived = true;
        reportUpdateIdFound = true;
        try {
          let report = JSON.parse(event.detail);
          const observedCompanies = globalThis.AvanteSessionAccess.currentCompanyEvidence(document);
          if (activeIdentity.role !== "administrator" || (!observedCompanies.includes(String(report?.companyScopeKey || "")) && report?.companyScopeKey !== activeIdentity.companyScopeKey)) return finish({ ok: false, errorCode: "COMPANY_SCOPE_MISMATCH", message: "A empresa do relatório não corresponde à sessão autorizada." });
          report = { ...report, companyScopeKey: activeIdentity.companyScopeKey };
          const sellersParsed = report?.sellers?.length || 0;
          if (!sellersParsed || !report.companyScopeKey) return finish({ ok: false, stage: "parsing", sellersParsed, errorCode: !report.companyScopeKey ? "MISSING_COMPANY" : "REPORT_NO_SELLERS", message: "A resposta do relatório foi recebida, mas nenhuma linha foi reconhecida." });
          if (report.pagination?.detected && !report.pagination?.complete) return finish({ ok: false, sellersParsed, errorCode: "INCOMPLETE_PAGINATION", message: "O relatório possui mais páginas e não foi usado para substituir os realizados." });
          const capturedAt = new Date().toISOString();
          const dataSignature = reportSignature(report);
          const links = await dashboard?.goals?.listSellerLinks?.(report.companyScopeKey) || [];
          const reportKeys = new Set((report.sellers || []).map((seller) => seller.localSellerKey));
          const validLinks = links.filter((link) => reportKeys.has(link.reportSellerKey));
          const linkedKeys = new Set(validLinks.map((link) => link.reportSellerKey));
          const linkedRealized = report.sellers.filter((seller) => linkedKeys.has(seller.localSellerKey)).reduce((sum, seller) => sum + (Number(seller.realized) || 0), 0);
          const companyRealized = Number.isFinite(report.totalRealized) ? report.totalRealized : report.sellers.reduce((sum, seller) => sum + (Number(seller.realized) || 0), 0);
          const snapshot = { ...report, capturedAt, sourceCapturedAt: report.capturedAt || capturedAt, refreshRequestedAt, refreshCompletedAt: capturedAt, dataSignature };
          await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.sellerReportSnapshot]: snapshot });
          await persistIndividualScopes(snapshot);
          finish({ ok: true, stage: "completed", sellersParsed, documentValueFound: report.sellers.filter((seller) => Number.isFinite(seller.realized)).length, companyRealized, linkedSellers: validLinks.length, unlinkedSellers: report.sellers.length - linkedKeys.size, linkedRealized, unlinkedRealized: Math.max(companyRealized - linkedRealized, 0), capturedAt, newCapturedAt: capturedAt, dataSignature, changed: dataSignature !== reportSignature(previousSnapshot), message: dataSignature === reportSignature(previousSnapshot) ? "A atualização foi concluída, mas os valores não mudaram." : validLinks.length < report.sellers.length ? `${report.sellers.length - linkedKeys.size} vendedores do Codxis ainda não estão vinculados às metas.` : "Realizados atualizados com sucesso." });
        } catch (_) {
          finish({ ok: false, errorCode: "INVALID_REPORT_RESPONSE", message: "Não foi possível interpretar o relatório de comissão." });
        }
      };
      const onStatus = (event) => {
        try {
          const status = JSON.parse(event.detail);
          if (status.ok) return;
          const mappingRequired = status.code === "MAPPING_REQUIRED" || status.code === "REPORT_PAGE_NOT_INITIALIZED";
          finish({ ok: false, stage: "request", errorCode: mappingRequired ? "REPORT_PAGE_NOT_INITIALIZED" : status.code || "REPORT_REQUEST_FAILED", message: mappingRequired ? "O relatório de comissão ainda não foi executado no Codxis. Abra o relatório uma vez para habilitar a reconciliação oficial." : status.message || "Não foi possível atualizar o relatório de comissão." });
        } catch (_) {}
      };
      window.addEventListener("avante:seller-report", onReport);
      window.addEventListener("avante:seller-report-status", onStatus);
      window.addEventListener("avante:seller-report-diagnostic", onDiagnostic);
      const timeout = window.setTimeout(() => finish({ ok: false, errorCode: "REPORT_TIMEOUT", message: "O Codxis não respondeu à atualização do relatório de comissão." }), 30000);
      if (!force && scanVisibleSellerReport()) return;
      window.dispatchEvent(new CustomEvent("avante:request-seller-report", { detail: JSON.stringify({ source: reason, force: force === true, refreshRequestedAt }) }));
    });
    try { return await activeSellerReportRefresh; }
    finally { activeSellerReportRefresh = null; }
  }

  globalThis.AvanteRefreshSellerReport = refreshSellerReport;

  async function getPageContext() {
    const pathname = location.pathname.replace(/\/+$/, "").replace(/\.xhtml$/, "");
    const isCodxis = location.hostname === "web.codxis.api.br";
    const isHome = isCodxis && pathname === "/sistema/pages/privado/index";
    let stored = {};
    try {
      stored = await globalThis.AvanteStorage.get([
        globalThis.AvanteStorage.KEYS.goalsPanelClosed,
        globalThis.AvanteStorage.KEYS.goalsPanelCollapsed,
        globalThis.AvanteStorage.KEYS.collapsed
      ]);
    } catch (_) {}
    const panel = document.getElementById("avante-dashboard");
    return {
      isCodxis,
      isHome,
      urlMatched: isHome,
      domMatched: detectCodxisHome().domMatched,
      pathname,
      dashboardMounted: Boolean(panel),
      administrativeAccessDenied,
      accessMode: activeIdentity.role,
      accessCode: activeIdentity.code,
      role: activeIdentity.role,
      panelClosed: Boolean(dashboard?.closed || panel?.classList.contains("is-closed") || stored[globalThis.AvanteStorage.KEYS.goalsPanelClosed]),
      panelCollapsed: Boolean(dashboard?.collapsed || panel?.classList.contains("is-collapsed") || stored[globalThis.AvanteStorage.KEYS.goalsPanelCollapsed] || stored[globalThis.AvanteStorage.KEYS.collapsed]),
      detectedAt: new Date().toISOString()
    };
  }

  async function publishPageContextChanged() {
    const context = await getPageContext();
    const signature = JSON.stringify([context.isHome, context.pathname, context.dashboardMounted, context.panelClosed, context.panelCollapsed]);
    if (signature === lastContextSignature) return;
    lastContextSignature = signature;
    try {
      const pending = chrome.runtime.sendMessage({ type: "AVANTE_PAGE_CONTEXT_CHANGED", context });
      pending?.catch?.(() => {});
    } catch (_) {}
  }

  const findHost = () => {
    for (const selector of config.mount.homeContainers) {
      try {
        const element = document.querySelector(selector);
        if (element) return element;
      } catch (error) {
        if (diagnosticsEnabled()) {
          console.warn("[CODXIS WEB] Seletor de montagem inválido", selector, error);
        }
      }
    }
    return null;
  };

  const normalizeLocalAdminHost = (host) => {
    if (!host) return null;
    // As rows do Codxis usam margens negativas e podem cortar o painel. O
    // alinhamento seguro com a sidebar é calculado pelo próprio dashboard.
    return host.matches?.("main .row") ? host.closest("main") || host : host;
  };

  const mountDashboard = async () => {
    if (!started || !dashboard || document.getElementById("avante-dashboard")) return;
    const foundHost = findHost();
    const host = localAdminEnabled ? normalizeLocalAdminHost(foundHost) : foundHost;
    await dashboard.mount(host || document.body, !host);
    dashboard.root?.addEventListener("avante:manual-refresh", () =>
      collector ? collector.refresh("manual") : dashboard.refresh()
    );
    if (localAdminEnabled) {
      dashboard.root?.addEventListener("click", (event) => {
        if (event.target.closest?.('[data-action="refresh"]')) collector?.refresh("panel");
      });
    }
  };

  const removeDashboard = () => {
    if (dashboard?.unmount) dashboard.unmount();
    else {
      const element = document.getElementById("avante-dashboard");
      if (element) element.remove();
      if (dashboard) dashboard.root = null;
    }
  };

  async function syncDashboardVisibility() {
    if (!started) return;
    if (shouldShowDashboard()) {
      await mountDashboard();
    } else {
      // Remover do DOM garante ausência de margem, altura e sobreposição.
      removeDashboard();
    }
    await publishPageContextChanged();
  }

  const queueVisibilitySync = () => {
    if (visibilityQueued) return;
    visibilityQueued = true;
    window.setTimeout(() => {
      visibilityQueued = false;
      syncDashboardVisibility();
    }, 100);
  };

  const onRouteChange = () => {
    // A rota mudou: remove imediatamente antes mesmo da nova tela renderizar.
    removeDashboard();
    collector?.refresh("route-change");
    publishPageContextChanged();
    window.setTimeout(queueVisibilitySync, 100);
  };

  const start = async () => {
    if (started || !isAllowedApp()) return;
    const demoRepository = new globalThis.AvanteDemoData.DemoRepository(globalThis.AvanteStorage);
    const demoState = await demoRepository.load();
    activeDemo = demoState.enabled || config.demoMode === true;
    const securityValues = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.identityBindings]);
    const storedBindings = Array.isArray(securityValues[globalThis.AvanteStorage.KEYS.identityBindings]) ? securityValues[globalThis.AvanteStorage.KEYS.identityBindings] : [];
    activeIdentity = globalThis.AvanteSessionAccess.resolveIdentity({ login: globalThis.AvanteSessionAccess.currentSessionLogin(document, storedBindings), companyScopeKey: globalThis.AvanteSessionAccess.currentCompanyScopeKey(document), companyEvidence: globalThis.AvanteSessionAccess.currentCompanyEvidence(document), bindings: storedBindings });
    activeScope = globalThis.AvanteSessionAccess.authorizedScope(activeIdentity, globalThis.AvanteSellerReport.currentMonthPeriod().month);
    sellerMode = activeIdentity.role === "seller";
    localAdminEnabled = activeIdentity.role === "administrator";
    administrativeAccessDenied = activeIdentity.role === "unknown";
    started = true;
    await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.activeSession]: activeIdentity.role === "unknown" ? null : { ...activeIdentity, evidence: undefined } });
    try {
      const values = await globalThis.AvanteStorage.get([
        globalThis.AvanteStorage.KEYS.diagnostics
      ]);
      globalThis.__AVANTE_DIAGNOSTICS__ = Boolean(
        values[globalThis.AvanteStorage.KEYS.diagnostics]
      );
    } catch (_) {
      globalThis.__AVANTE_DIAGNOSTICS__ = false;
    }
    if (demoEnabled()) {
      dashboard = new globalThis.AvanteRoleDashboard({
        provider: globalThis.AvanteDemoMode.createProvider(demoState),
        demoRepository
      });
    } else if (sellerMode) {
      dashboard = new globalThis.AvanteLocalSellerDashboard({ identity: activeIdentity });
    } else if (administrativeAccessDenied) {
      dashboard = new globalThis.AvanteLocalSellerDashboard({ identity: activeIdentity });
    } else if (localAdminEnabled) {
      if (!saleListenerAttached) { window.addEventListener("avante:sale-completed", onConfirmedSale); saleListenerAttached = true; }
      if (!reportListenerAttached) { window.addEventListener("avante:seller-report", persistCapturedSellerReport); reportListenerAttached = true; }
      window.dispatchEvent(new CustomEvent("avante:activate-bridge"));
      dashboard = new globalThis.AvanteLocalAdminDashboard();
    } else {
      window.dispatchEvent(new CustomEvent("avante:activate-bridge"));
      dashboard = new globalThis.AvanteDashboard();
    }

    if (!demoEnabled()) {
      if (sellerMode) {
        window.addEventListener("focus", syncSellerAutomatically);
        document.addEventListener("visibilitychange", syncSellerAutomatically);
        window.addEventListener("avante:route-change", onRouteChange);
        window.addEventListener("pageshow", onRouteChange);
        // Monta primeiro usando o cache individual validado. A API local pode
        // estar desligada ou lenta e nunca deve impedir o painel de aparecer.
        await syncDashboardVisibility();
        startSellerSyncLoop();
        syncSellerAutomatically().catch(() => {});
        return;
      }
      if (administrativeAccessDenied) {
        window.addEventListener("avante:route-change", onRouteChange);
        window.addEventListener("pageshow", onRouteChange);
        await syncDashboardVisibility();
        return;
      }
      collector = new globalThis.AvanteDataCollector();
      collector.addEventListener("data", (event) => {
        if (localAdminEnabled) {
          if (isHomePage()) dashboard.updateCompanySales?.(event.detail);
        } else dashboard.updateSnapshot(event.detail);
      });
      collector.addEventListener("status", (event) => {
        if (!localAdminEnabled) dashboard.setCaptureStatus(event.detail);
      });
      collector.start();
    }

    if (localAdminEnabled) {
      const companyScopeKey = String(document.getElementById("formTopBar:empresas_input")?.value || "").trim();
      try {
        await globalThis.AvanteSaleLedger.restoreCurrentSnapshot(globalThis.AvanteStorage, companyScopeKey);
      } catch (error) {
        if (diagnosticsEnabled()) console.warn("[CODXIS WEB] Vendas locais anteriores não puderam ser restauradas", { code: "SALE_SNAPSHOT_RESTORE_FAILED" });
      }
      await republishIndividualScopesFromStoredReport();
    }

    window.addEventListener("avante:route-change", onRouteChange);
    window.addEventListener("pageshow", onRouteChange);
    window.addEventListener("focus", () =>
      collector ? collector.refresh("focus") : dashboard.refresh()
    );
    await syncDashboardVisibility();
    queueVisibleSellerReportScan();
  };

  async function getSanitizedViewModel() {
    if (activeIdentity.role === "unknown") return null;
    if (activeIdentity.role === "seller") return dashboard?.loadSanitizedModel?.() || null;
    const model = dashboard?.currentModel;
    return { role: "administrator", companyScopeKey: activeIdentity.companyScopeKey, month: activeScope?.month || null, companyGoal: model?.companyGoal?.amount ?? model?.companyGoal ?? null, companyTotal: model?.totalRealized ?? model?.companySales ?? null, capturedAt: model?.capturedAt || null };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "AVANTE_GET_PAGE_CONTEXT") {
      getPageContext().then(sendResponse);
      return true;
    }

    if (message?.type === "AVANTE_GET_SESSION_EVIDENCE") {
      sendResponse({ login: globalThis.AvanteSessionAccess.currentSessionLogin(document), companyEvidence: globalThis.AvanteSessionAccess.currentCompanyEvidence(document), resolvedRole: activeIdentity.role, accessCode: activeIdentity.code, resolvedUserId: activeIdentity.userId, resolvedSellerId: activeIdentity.sellerId });
      return;
    }

    if (message?.type === "AVANTE_GET_SANITIZED_VIEW_MODEL") {
      getSanitizedViewModel().then((model) => sendResponse({ ok: Boolean(model), role: activeIdentity.role, code: activeIdentity.code, model }));
      return true;
    }

    if (message?.type === "AVANTE_GET_ADMIN_SELLER_CANDIDATES") {
      if (activeIdentity.role !== "administrator") { sendResponse({ ok: false, errorCode: "ADMIN_REQUIRED", candidates: [] }); return; }
      currentAdminSellerRows().then((rows) => sendResponse({ ok: true, candidates: rows.map((row) => ({ localSellerKey: row.localSellerKey, sellerName: row.sellerName, goal: row.goal.amount, realized: row.realized, progress: row.metrics?.progress ?? null })) })).catch((error) => sendResponse({ ok: false, errorCode: error?.message || "ADMIN_CANDIDATES_FAILED", candidates: [] }));
      return true;
    }

    if (message?.type === "AVANTE_REPUBLISH_SELLER_DTOS") {
      if (activeIdentity.role !== "administrator") { sendResponse({ ok: false, errorCode: "ADMIN_REQUIRED" }); return; }
      const publication = message.target ? publishSelectedAdminSeller(message.target) : Promise.resolve(dashboard?.render?.()).then(republishIndividualScopesFromStoredReport);
      publication.then((result) => sendResponse({ ok: result.remotePublished > 0, ...result })).catch((error) => sendResponse({ ok: false, errorCode: error?.message || "REPUBLISH_FAILED" }));
      return true;
    }

    if (message?.type === "AVANTE_REFRESH") {
      if (sellerMode) {
        (async () => { try { const sync = await syncSellerAutomatically(); const model = await getSanitizedViewModel(); const pending = sync?.pending === true; sendResponse({ ok: Boolean(sync?.ok && (model || pending)), role: "seller", model, pending, errorCode: sync?.ok ? null : sync?.errorCode || "SELLER_SYNC_FAILED", message: pending ? "Conta vinculada. Aguardando a meta individual deste mês." : sync?.ok ? null : `Sincronização individual falhou: ${sync?.errorCode || "erro desconhecido"}.` }); } catch (error) { sendResponse({ ok: false, role: "seller", errorCode: error?.code || "SELLER_REFRESH_FAILED", message: `Atualização individual interrompida: ${error?.code || error?.message || "erro desconhecido"}.` }); } })();
        return true;
      }
      if (administrativeAccessDenied) {
        sendResponse({ ok: false, errorCode: "ADMIN_SESSION_MISMATCH", message: "Painel bloqueado: este login não é o administrador autorizado." });
        return;
      }
      if (!started || (!collector && !demoEnabled() && !localAdminEnabled)) {
        sendResponse({
          ok: false,
          message: "A página atual não foi reconhecida como Codxis."
        });
        return;
      }
      if (localAdminEnabled) {
        refreshSellerReport({ reason: message.reason || "popup-manual", force: true }).then(sendResponse).catch(() => sendResponse({ ok: false, refreshStarted: true, reportResponseReceived: false, reportUpdateIdFound: false, sellersParsed: 0, previousCapturedAt: null, newCapturedAt: null, errorCode: "REFRESH_ERROR", message: "Não foi possível iniciar a atualização do relatório de comissão." }));
        return true;
      }
      else if (collector) collector.refresh("popup");
      else dashboard.refresh();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "AVANTE_OPEN_GOALS_PANEL" || message?.type === "AVANTE_REVEAL") {
      if (administrativeAccessDenied) {
        sendResponse({ ok: false, errorCode: "ADMIN_SESSION_MISMATCH", message: "Este é um login de vendedor. O painel administrativo está bloqueado para evitar acesso aos dados da equipe." });
        return;
      }
      if (!started || !shouldShowDashboard()) {
        sendResponse({
          ok: false,
          message: "O painel ainda não está disponível para abertura nesta página."
        });
        return;
      }
      globalThis.AvanteStorage.set({
        [globalThis.AvanteStorage.KEYS.goalsPanelClosed]: false,
        [globalThis.AvanteStorage.KEYS.goalsPanelCollapsed]: false,
        [globalThis.AvanteStorage.KEYS.collapsed]: false
      }).then(() => syncDashboardVisibility()).then(() => {
        const reveal = async () => {
          if (dashboard?.openPanel) await dashboard.openPanel();
          else dashboard?.revealDashboard?.();
          if (dashboard?.collapsed === true && dashboard?.toggleCollapsed) await dashboard.toggleCollapsed();
          if (dashboard?.state?.collapsed === true && dashboard?.toggleCollapsed) dashboard.toggleCollapsed();
          if (!document.getElementById("avante-dashboard")) await mountDashboard();
          const panel = document.getElementById("avante-dashboard");
          panel?.scrollIntoView({ behavior: "smooth", block: "start" });
          const context = await getPageContext();
          await publishPageContextChanged();
          sendResponse({ ok: Boolean(panel), ...context, dashboardMounted: Boolean(panel), panelClosed: false });
        };
        reveal();
      }).catch((error) => sendResponse({ ok: false, message: error.message }));
      return true;
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    const key = globalThis.AvanteStorage.KEYS.diagnostics;
    if (areaName === "local" && changes[key]) {
      globalThis.__AVANTE_DIAGNOSTICS__ = Boolean(changes[key].newValue);
    }
    if (areaName === "local" && changes[globalThis.AvanteDemoData.KEYS.profile] && activeDemo) {
      dashboard?.refresh();
    }
    if (areaName === "local" && changes[globalThis.AvanteStorage.KEYS.localSellerGoals] && activeIdentity.role === "administrator") {
      Promise.resolve(dashboard?.render?.()).then(republishIndividualScopesFromStoredReport).catch((error) => {
        if (diagnosticsEnabled()) console.warn("[CODXIS WEB] DTO individual não pôde ser republicado", { code: "SELLER_SCOPE_REPUBLISH_FAILED", message: error?.message });
      });
    }
    if (areaName === "local" && sellerMode && activeScope) {
      const sellerKey = globalThis.AvanteSessionAccess.scopeKey(activeScope);
      if (changes[sellerKey]) dashboard?.refresh();
    }
    if (areaName === "local" && [
      globalThis.AvanteStorage.KEYS.goalsPanelClosed,
      globalThis.AvanteStorage.KEYS.goalsPanelCollapsed,
      globalThis.AvanteStorage.KEYS.collapsed
    ].some((changedKey) => changes[changedKey])) publishPageContextChanged();
  });

  const startSafely = () => start().catch((error) => {
    if (globalThis.AvanteStorage?.isContextInvalidated?.(error)) return;
    console.error("[CODXIS WEB] Falha ao iniciar a extensão", error);
  });

  startSafely();

  let identityAuditQueued = false;
  const auditIdentityChange = () => {
    if (identityAuditQueued || !started) return;
    identityAuditQueued = true;
    window.setTimeout(async () => {
      identityAuditQueued = false;
      const values = await globalThis.AvanteStorage.get([globalThis.AvanteStorage.KEYS.identityBindings]);
      const auditBindings = Array.isArray(values[globalThis.AvanteStorage.KEYS.identityBindings]) ? values[globalThis.AvanteStorage.KEYS.identityBindings] : [];
      const next = globalThis.AvanteSessionAccess.resolveIdentity({ login: globalThis.AvanteSessionAccess.currentSessionLogin(document, auditBindings), companyScopeKey: globalThis.AvanteSessionAccess.currentCompanyScopeKey(document), companyEvidence: globalThis.AvanteSessionAccess.currentCompanyEvidence(document), bindings: auditBindings });
      if (next.sessionFingerprint === activeIdentity.sessionFingerprint && next.code === activeIdentity.code) return;
      // Troca de empresa/usuário: limpa o snapshot antigo para evitar que dados
      // da empresa anterior apareçam no painel da nova empresa.
      await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.sellerReportSnapshot]: null });
      // Session boundary: synchronously remove the previous DOM/model, then
      // detach privileged listeners and only afterwards resolve the new scope.
      removeDashboard();
      collector?.stop?.(); collector = null;
      if (saleListenerAttached) window.removeEventListener("avante:sale-completed", onConfirmedSale);
      if (reportListenerAttached) window.removeEventListener("avante:seller-report", persistCapturedSellerReport);
      saleListenerAttached = false; reportListenerAttached = false;
      window.clearTimeout(saleRefreshTimer); saleRefreshTimer = null; activeSellerReportRefresh = null;
      window.clearInterval(sellerSyncTimer); sellerSyncTimer = null;
      sellerSyncInFlight = null;
      window.removeEventListener("focus", syncSellerAutomatically);
      document.removeEventListener("visibilitychange", syncSellerAutomatically);
      window.dispatchEvent(new CustomEvent("avante:deactivate-bridge"));
      dashboard = null; activeScope = null; activeIdentity = globalThis.AvanteSessionAccess.unknown("SESSION_CHANGED");
      started = false; localAdminEnabled = false; sellerMode = false; administrativeAccessDenied = true;
      await globalThis.AvanteStorage.set({ [globalThis.AvanteStorage.KEYS.activeSession]: null });
      await start();
    }, 0);
  };

  // Observa tanto a inicialização tardia quanto retornos à home em aplicações SPA.
  const appObserver = new MutationObserver((mutations) => {
    const externalChange = mutations.some((mutation) => {
      const element =
        mutation.target instanceof Element
          ? mutation.target
          : mutation.target.parentElement;
      return !element?.closest("#avante-dashboard");
    });
    if (!externalChange) return;
    auditIdentityChange();
    queueVisibleSellerReportScan();
    if (!started) startSafely();
    else queueVisibilitySync();
  });
  appObserver.observe(document.documentElement, { childList: true, characterData: true, attributes: true, attributeFilter: ["value", "selected"], subtree: true });
})();
