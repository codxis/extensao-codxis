"use strict";

const session = require("./session");
const company = require("./company");
const seller = require("./seller");
const sales = require("./sales");
const reports = require("./reports");
const policy = require("./access-policy");
const contracts = require("./contracts");
const errors = require("./errors");
const storage = require("./scoped-storage");

async function getDashboardModel() {
  throw new errors.CodxisMappingError(
    "O modelo autorizado do dashboard depende de identidade e relatórios ainda não mapeados."
  );
}

module.exports = Object.freeze({
  ...session,
  ...company,
  ...seller,
  ...sales,
  ...reports,
  getDashboardModel,
  policy,
  contracts,
  errors,
  storage
});

